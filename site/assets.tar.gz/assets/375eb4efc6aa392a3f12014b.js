(function($, window, document) {
	'use strict';

	var controls = window.GalleriaSlickControls || {};
	var observer = null;
	var nextFrame = window.requestAnimationFrame || function(callback) {
		return window.setTimeout(callback, 16);
	};

	function reducedMotion() {
		return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	}

	function normaliseOptions(options) {
		if (typeof options === 'boolean') {
			options = { alwaysCounter: options };
		}

		return $.extend({
			alwaysCounter: false,
			counterThreshold: 5,
			maxVisibleDots: 5,
			relayoutMediaBoxes: false
		}, options || {});
	}

	function scheduleMediaBoxesLayout($slider) {
		var $grid = $slider.closest('.media-boxes-container');

		if (!$grid.length || !$grid.data('mediaBoxes')) {
			return;
		}

		window.clearTimeout($grid.data('galleriaMediaLayoutTimer'));
		$grid.data('galleriaMediaLayoutTimer', window.setTimeout(function() {
			nextFrame(function() {
				try {
					$grid.mediaBoxes('resize');
				} catch (error) {
					// The grid may have been replaced while an AJAX response was settling.
				}
			});
		}, 80));
	}

	function updateControls($slider, slick, currentSlide) {
		var options = normaliseOptions($slider.data('galleriaSlickControls'));
		var total = slick && slick.slideCount ? slick.slideCount : $slider.children('.slide').length;
		var currentIndex = typeof currentSlide === 'number' ? currentSlide : (slick && slick.currentSlide ? slick.currentSlide : 0);
		var current = currentIndex + 1;
		var visibleCount = Math.min(total, options.maxVisibleDots);
		var firstVisible = Math.max(0, Math.min(currentIndex - Math.floor(visibleCount / 2), total - visibleCount));
		var lastVisible = firstVisible + visibleCount - 1;
		var $dots = $slider.find('.slick-dots li');
		var shouldCount = total > 1 && (options.alwaysCounter || total > options.counterThreshold);

		$slider.toggleClass('galleria-media-counted', shouldCount);
		$dots.removeClass('is-dot-visible is-dot-edge-start is-dot-edge-end')
			.attr('aria-hidden', 'true')
			.find('button').attr('tabindex', '-1').removeAttr('aria-current');

		$dots.slice(firstVisible, firstVisible + visibleCount)
			.addClass('is-dot-visible')
			.removeAttr('aria-hidden')
			.find('button').removeAttr('tabindex');

		if (firstVisible > 0) {
			$dots.eq(firstVisible).addClass('is-dot-edge-start');
		}

		if (lastVisible < total - 1) {
			$dots.eq(lastVisible).addClass('is-dot-edge-end');
		}

		$dots.each(function(index) {
			var $button = $(this).find('button');
			$button.attr('aria-label', 'Go to slide ' + (index + 1) + ' of ' + total);
			if (index === currentIndex) {
				$button.attr('aria-current', 'true');
			}
		});

		if (!shouldCount) {
			$slider.children('.galleria-slide-count').remove();
			return;
		}

		var $counter = $slider.children('.galleria-slide-count');
		if (!$counter.length) {
			$counter = $('<span class="galleria-slide-count" aria-live="polite" aria-atomic="true"></span>')
				.appendTo($slider);
		}

		$counter.text(current + ' / ' + total);
	}

	function watchMedia($slider, shouldRelayout) {
		$slider.find('img, video').each(function() {
			var $media = $(this);

			if ($media.data('galleriaMediaWatched')) {
				return;
			}

			$media.data('galleriaMediaWatched', true).one('load.galleriaMediaControls loadedmetadata.galleriaMediaControls error.galleriaMediaControls', function() {
				$slider.addClass('is-media-ready');
				if (shouldRelayout) {
					scheduleMediaBoxesLayout($slider);
				}
			});

			if ((this.tagName === 'IMG' && this.complete) || (this.tagName === 'VIDEO' && this.readyState > 0)) {
				$slider.addClass('is-media-ready');
			}
		});
	}

	controls.prepare = function($slider, options) {
		options = normaliseOptions(options);
		$slider = $($slider);

		$slider.addClass('galleria-instagram-controls').data('galleriaSlickControls', options);
		$slider.off('.galleriaMediaControls').on(
			'init.galleriaMediaControls reInit.galleriaMediaControls afterChange.galleriaMediaControls',
			function(event, slick, currentSlide) {
				var $currentSlider = $(this);
				$currentSlider.addClass('is-slick-ready');
				updateControls($currentSlider, slick, currentSlide);
				watchMedia($currentSlider, options.relayoutMediaBoxes);

				if (options.relayoutMediaBoxes && event.type !== 'reInit') {
					scheduleMediaBoxesLayout($currentSlider);
				}
			}
		).on('lazyLoaded.galleriaMediaControls', function() {
			$(this).addClass('is-media-ready');
			if (options.relayoutMediaBoxes) {
				scheduleMediaBoxesLayout($(this));
			}
		});

		watchMedia($slider, options.relayoutMediaBoxes);
		return $slider;
	};

	controls.initMedia = function(context) {
		var $context = $(context || document);
		var selector = '.media-boxes-container .featured-thumbs, .post-grid .featured-thumbs, #related-grid .featured-thumbs, .related-grid .featured-thumbs';
		var isGridContext = $context.is('.media-boxes-container, .post-grid, #related-grid, .related-grid');
		var $sliders = $context.is('.featured-thumbs') ? $context : $context.find(isGridContext ? '.featured-thumbs' : selector);

		$sliders.filter(':visible').not('.slick-initialized').each(function() {
			var $gallery = $(this);
			var slideCount = $gallery.children('.slide').length;
			var isWideGallery = $gallery.closest('.post-grid.gallery').length > 0;

			if (!slideCount) {
				return;
			}

			$gallery.addClass('galleria-media-frame');
			if (isWideGallery) {
				$gallery.addClass('galleria-wide-gallery');
			}

			controls.prepare($gallery, {
				alwaysCounter: isWideGallery,
				counterThreshold: 5,
				relayoutMediaBoxes: true
			});

			$gallery.slick($.extend({
				infinite: false,
				adaptiveHeight: false,
				dots: slideCount > 1,
				arrows: slideCount > 1,
				prevArrow: '<i class="fa fa-chevron-circle-left" aria-hidden="true"></i>',
				nextArrow: '<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>'
			}, isWideGallery ? {
				slidesToScroll: 1,
				slidesToShow: 2,
				centerPadding: '50px',
				variableWidth: true,
				centerMode: false,
				speed: reducedMotion() ? 0 : 600,
				cssEase: 'cubic-bezier(0.87, 0.03, 0.41, 0.9)'
			} : {
				slidesToShow: 1,
				slidesToScroll: 1,
				speed: reducedMotion() ? 0 : 500
			}));

			if (isWideGallery) {
				$gallery.on('init.galleriaVideo reInit.galleriaVideo afterChange.galleriaVideo', function(event, slick) {
					slick.$slides.find('video').each(function() {
						if (this.readyState === 0) {
							this.load();
						}
					});
				});
			}
		});
	};

	controls.scheduleMediaBoxesLayout = scheduleMediaBoxesLayout;
	controls.reducedMotion = reducedMotion;
	window.GalleriaSlickControls = controls;

	// Backwards-compatible entry point used by dynamically inserted store deals.
	window.galleriaPrepareMediaSlick = function($slider, withCounter) {
		return controls.prepare($slider, {
			alwaysCounter: !!withCounter,
			counterThreshold: 5,
			relayoutMediaBoxes: true
		});
	};

	$(document).on('layoutComplete.galleriaMediaSlick', '.media-boxes-container, .post-grid, #related-grid', function() {
		controls.initMedia(this);
	});

	$(function() {
		controls.initMedia(document);

		if ('MutationObserver' in window) {
			observer = new MutationObserver(function(mutations) {
				var needsScan = mutations.some(function(mutation) {
					return Array.prototype.some.call(mutation.addedNodes || [], function(node) {
						if (node.nodeType !== 1) {
							return false;
						}

						var $node = $(node);
						return $node.is('.featured-thumbs, .media-box, .media-boxes-container') || $node.find('.featured-thumbs').length > 0;
					});
				});

				if (needsScan) {
					window.setTimeout(function() {
						controls.initMedia(document);
					}, 0);
				}
			});

			observer.observe(document.body, { childList: true, subtree: true });
		}
	});
})(jQuery, window, document);
