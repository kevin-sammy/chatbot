(function () {
	'use strict';

	function initSlider(root) {
		if (root.dataset.ghsReady === '1') return;
		root.dataset.ghsReady = '1';

		var slides = Array.prototype.slice.call(root.querySelectorAll('[data-ghs-slide]'));
		var dots = Array.prototype.slice.call(root.querySelectorAll('[data-ghs-goto]'));
		var currentLabel = root.querySelector('[data-ghs-current]');
		var previous = root.querySelector('[data-ghs-prev]');
		var next = root.querySelector('[data-ghs-next]');
		var pause = root.querySelector('[data-ghs-pause]');
		var pauseIcon = root.querySelector('[data-ghs-pause-icon]');
		var previousPreview = root.querySelector('[data-ghs-prev-preview]');
		var nextPreview = root.querySelector('[data-ghs-next-preview]');
		var preloader = root.querySelector('[data-ghs-preloader]');
		var current = 0;
		var timer = null;
		var visible = true;
		var userPaused = false;
		var hoverPaused = false;
		var gesture = null;
		var dragged = false;
		var wheelLocked = false;
		var heightFrame = null;
		var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		var autoplay = root.dataset.autoplay === '1' && !reducedMotion;
		var interval = Math.max(3000, parseInt(root.dataset.interval || '8000', 10));

		if (!slides.length) return;

		function measureMobileHeight() {
			heightFrame = null;
			if (window.matchMedia('(min-width: 768px)').matches || root.classList.contains('ghs-placement-splash')) {
				root.style.removeProperty('--ghs-mobile-height');
				return;
			}

			var slide = slides[current];
			if (!slide) return;
			var target = 0;
			if (slide.classList.contains('ghs-layout-logo_bands')) {
				var topBand = slide.querySelector('.ghs-logo-band-top');
				var bottomBand = slide.querySelector('.ghs-logo-band-bottom');
				var logoCopy = slide.querySelector('.ghs-logo-band-copy');
				target = 90 + (topBand ? topBand.offsetHeight : 0) + (bottomBand ? bottomBand.offsetHeight : 0) + (logoCopy ? logoCopy.scrollHeight : 225);
			} else {
				var content = slide.querySelector('.ghs-mobile-render .ghs-inner') || slide.querySelector(':scope > .ghs-inner');
				if (content) target = content.scrollHeight;
			}

			if (!target) target = slide.classList.contains('ghs-mobile-landscape') ? 500 : 560;
			/* Keep a compact baseline, but never cap genuine content and clip its CTA. */
			target = Math.max(500, Math.ceil(target + 12));
			root.style.setProperty('--ghs-mobile-height', target + 'px');
		}

		function scheduleMobileHeight() {
			if (heightFrame) window.cancelAnimationFrame(heightFrame);
			heightFrame = window.requestAnimationFrame(function () {
				window.requestAnimationFrame(measureMobileHeight);
			});
		}

		function revealSlider() {
			root.classList.add('is-ready');
			root.classList.remove('ghs-is-loading');
			if (preloader) {
				window.setTimeout(function () { preloader.hidden = true; }, 500);
			}
		}

		function waitForImage(image) {
			if (!image || (image.complete && image.naturalWidth > 0)) return Promise.resolve();
			return new Promise(function (resolve) {
				image.addEventListener('load', resolve, { once: true });
				image.addEventListener('error', resolve, { once: true });
			});
		}

		function prepareFirstSlide() {
			if (!preloader) {
				revealSlider();
				return;
			}

			var mobile = window.matchMedia('(max-width: 767px)').matches;
			var preferredRender = slides[0].querySelector(mobile ? '.ghs-mobile-render' : '.ghs-desktop-render');
			var criticalImage = (preferredRender || slides[0]).querySelector('img.ghs-image');
			var imageReady = waitForImage(criticalImage);
			var fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready.catch(function () {}) : Promise.resolve();
			var failsafe = new Promise(function (resolve) { window.setTimeout(resolve, 1500); });

			Promise.race([Promise.all([imageReady, fontsReady]), failsafe]).then(revealSlider);
		}

		function normalise(index) {
			if (index < 0) return slides.length - 1;
			if (index >= slides.length) return 0;
			return index;
		}

		function stopTimer() {
			if (timer) window.clearTimeout(timer);
			timer = null;
		}

		function startTimer() {
			stopTimer();
			if (!autoplay || userPaused || hoverPaused || !visible || document.hidden || slides.length < 2) return;
			timer = window.setTimeout(function () {
				show(current + 1, false);
			}, interval);
		}

		function syncExpansionVideos() {
			var desktop = window.matchMedia('(min-width: 768px)').matches;
			var rootRect = root.getBoundingClientRect();
			var onScreen = rootRect.bottom > 0 && rootRect.top < window.innerHeight;
			slides.forEach(function (slide, slideIndex) {
				slide.querySelectorAll('[data-ghs-expansion-video]').forEach(function (video) {
					var item = video.closest('[data-ghs-triptych-item]');
					var panel = video.closest('[data-ghs-triptych-panel]');
					var mobilePanelActive = desktop || !panel || panel.classList.contains('is-mobile-active');
					var shouldPlay = desktop && !reducedMotion && !userPaused && !hoverPaused && visible && onScreen && !document.hidden && slideIndex === current && mobilePanelActive && ( !item || item.classList.contains('is-active') );
					if (!shouldPlay) {
						video.pause();
						return;
					}
					if (video.dataset.loaded !== '1') {
						var source = video.querySelector('source[data-src]');
						if (source) source.src = source.dataset.src;
						video.dataset.loaded = '1';
						video.load();
					}
					var playAttempt = video.play();
					if (playAttempt && typeof playAttempt.catch === 'function') playAttempt.catch(function () {});
				});
			});
		}

		function loadTriptychItem(item) {
			if (!item) return null;
			var image = item.querySelector('[data-ghs-lazy-image]');
			if (image) {
				if (image.dataset.src) image.src = image.dataset.src;
				if (image.dataset.srcset) image.srcset = image.dataset.srcset;
				image.removeAttribute('data-src');
				image.removeAttribute('data-srcset');
				image.removeAttribute('data-ghs-lazy-image');
			}
			return image || item.querySelector('img.ghs-image');
		}

		function stopTriptychs() {
			root.querySelectorAll('[data-ghs-triptych-panel]').forEach(function (panel) {
				if (panel.ghsTriptychTimer) window.clearTimeout(panel.ghsTriptychTimer);
				panel.ghsTriptychTimer = null;
			});
		}

		function activateTriptychItem(panel, index) {
			var items = Array.prototype.slice.call(panel.querySelectorAll('[data-ghs-triptych-item]'));
			if (!items.length) return;
			var activeIndex = ((index % items.length) + items.length) % items.length;
			var activeItem = items[activeIndex];
			loadTriptychItem(activeItem);
			items.forEach(function (item, itemIndex) {
				var active = itemIndex === activeIndex;
				item.classList.toggle('is-active', active);
				item.setAttribute('aria-hidden', active ? 'false' : 'true');
				if (!active) {
					var video = item.querySelector('video');
					if (video) video.pause();
				}
			});
			panel.dataset.ghsTriptychCurrent = String(activeIndex);
			/* Fetch the following frame during the current frame's display time. */
			if (items.length > 1) loadTriptychItem(items[(activeIndex + 1) % items.length]);
			var link = panel.querySelector('[data-ghs-triptych-link]');
			var url = activeItem.dataset.url || '';
			if (link && url) link.href = url;
			var label = panel.querySelector('[data-ghs-triptych-label]');
			if (label) {
				var newLabel = activeItem.dataset.label || '';
				if (label.textContent !== newLabel && panel.dataset.ghsTriptychInitialised === '1') {
					if (label.ghsLabelTimer) window.clearTimeout(label.ghsLabelTimer);
					label.classList.add('is-changing');
					label.ghsLabelTimer = window.setTimeout(function () {
						label.textContent = newLabel;
						label.classList.remove('is-changing');
					}, 180);
				} else {
					label.textContent = newLabel;
				}
			}
			panel.dataset.ghsTriptychInitialised = '1';
			syncExpansionVideos();
		}

		function syncTriptychs() {
			stopTriptychs();
			var activeSlide = slides[current];
			if (!activeSlide || !activeSlide.querySelector('[data-ghs-triptych]') || reducedMotion || userPaused || hoverPaused || !visible || document.hidden) return;
			var desktop = window.matchMedia('(min-width: 768px)').matches;
			if (!desktop) return;
			activeSlide.querySelectorAll('[data-ghs-triptych-panel]').forEach(function (panel, panelIndex) {
				var items = panel.querySelectorAll('[data-ghs-triptych-item]');
				if (items.length < 2) return;
				function advance() {
					var nextIndex = parseInt(panel.dataset.ghsTriptychCurrent || '0', 10) + 1;
					activateTriptychItem(panel, nextIndex);
					panel.ghsTriptychTimer = window.setTimeout(advance, 5200);
				}
				panel.ghsTriptychTimer = window.setTimeout(advance, 3600 + (panelIndex * 900));
			});
		}

		function refreshMobileTriptych(slide) {
			if (window.matchMedia('(min-width: 768px)').matches) return;
			var triptych = slide ? slide.querySelector('[data-ghs-triptych]') : null;
			if (!triptych) return;
			if (triptych.dataset.ghsTriptychVisited === '1') {
				triptych.querySelectorAll('[data-ghs-triptych-panel]').forEach(function (panel) {
					var currentItem = parseInt(panel.dataset.ghsTriptychCurrent || '0', 10);
					activateTriptychItem(panel, currentItem + 1);
				});
			} else {
				triptych.dataset.ghsTriptychVisited = '1';
			}
		}

		function show(index, initiatedByUser) {
			var previousCurrent = current;
			current = normalise(index);
			slides.forEach(function (slide, slideIndex) {
				var active = slideIndex === current;
				slide.classList.toggle('is-active', active);
				slide.setAttribute('aria-hidden', active ? 'false' : 'true');
				slide.inert = !active;
			});
			dots.forEach(function (dot, dotIndex) {
				var active = dotIndex === current;
				dot.classList.toggle('is-active', active);
				if (active) dot.setAttribute('aria-current', 'true');
				else dot.removeAttribute('aria-current');
			});
			if (currentLabel) currentLabel.textContent = String(current + 1).padStart(2, '0');
			updateArrowPreviews();
			if (current !== previousCurrent || !slides[current].dataset.ghsShown) {
				refreshMobileTriptych(slides[current]);
				slides[current].dataset.ghsShown = '1';
			}
			syncExpansionVideos();
			syncTriptychs();
			scheduleMobileHeight();
			if (initiatedByUser) root.dataset.ghsUserMoved = '1';
			startTimer();
		}

		function updatePreview(image, targetIndex) {
			if (!image) return;
			var target = slides[normalise(targetIndex)];
			var targetImage = target.querySelector('img.ghs-image');
			var src = targetImage ? (targetImage.currentSrc || targetImage.getAttribute('src') || '') : '';
			image.src = src;
			image.alt = '';
			image.closest('.ghs-arrow-preview').classList.toggle('has-image', !!src);
		}

		function updateArrowPreviews() {
			updatePreview(previousPreview, current - 1);
			updatePreview(nextPreview, current + 1);
		}

		function setPaused(paused) {
			userPaused = paused;
			if (pause) {
				pause.setAttribute('aria-pressed', paused ? 'true' : 'false');
				pause.setAttribute('aria-label', paused ? 'Resume automatic slides' : 'Pause automatic slides');
			}
			if (pauseIcon) pauseIcon.textContent = paused ? '▶' : '❚❚';
			startTimer();
			syncExpansionVideos();
			syncTriptychs();
		}

		root.querySelectorAll('[data-ghs-triptych]').forEach(function (triptych) {
			var tabs = Array.prototype.slice.call(triptych.querySelectorAll('[data-ghs-triptych-tab]'));
			var panels = Array.prototype.slice.call(triptych.querySelectorAll('[data-ghs-triptych-panel]'));
			tabs.forEach(function (tab) {
				tab.addEventListener('click', function () {
					var selected = parseInt(tab.dataset.ghsTriptychTab || '0', 10);
					tabs.forEach(function (candidate, index) {
						var active = index === selected;
						candidate.classList.toggle('is-active', active);
						candidate.setAttribute('aria-selected', active ? 'true' : 'false');
					});
					panels.forEach(function (panel, index) {
						panel.classList.toggle('is-mobile-active', index === selected);
					});
					if (panels[selected]) activateTriptychItem(panels[selected], parseInt(panels[selected].dataset.ghsTriptychCurrent || '0', 10));
					syncTriptychs();
					scheduleMobileHeight();
					if (!window.matchMedia('(hover: hover)').matches) tab.blur();
				});
			});
			panels.forEach(function (panel) { activateTriptychItem(panel, 0); });
		});

		dots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				show(parseInt(dot.dataset.ghsGoto, 10), true);
			});
		});

		if (previous) previous.addEventListener('click', function () { show(current - 1, true); });
		if (next) next.addEventListener('click', function () { show(current + 1, true); });
		if (pause) pause.addEventListener('click', function () { setPaused(!userPaused); });

		root.querySelectorAll('[data-ghs-gallery]').forEach(function (gallery) {
			var items = Array.prototype.slice.call(gallery.querySelectorAll('[data-ghs-gallery-item]'));
			var previousImage = gallery.querySelector('[data-ghs-gallery-prev]');
			var nextImage = gallery.querySelector('[data-ghs-gallery-next]');
			var galleryDots = Array.prototype.slice.call(gallery.querySelectorAll('[data-ghs-gallery-goto]'));
			var galleryCurrent = 0;

			function showGalleryImage(index) {
				if (!items.length) return;
				galleryCurrent = Math.max(0, Math.min(items.length - 1, index));
				items.forEach(function (item, itemIndex) {
					var active = itemIndex === galleryCurrent;
					item.classList.toggle('is-active', active);
					item.setAttribute('aria-hidden', active ? 'false' : 'true');
				});
				galleryDots.forEach(function (dot, dotIndex) {
					var active = dotIndex === galleryCurrent;
					dot.classList.toggle('is-active', active);
					if (active) dot.setAttribute('aria-current', 'true');
					else dot.removeAttribute('aria-current');
				});
				if (previousImage) previousImage.hidden = galleryCurrent === 0;
				if (nextImage) nextImage.hidden = galleryCurrent === items.length - 1;
			}

			if (previousImage) previousImage.addEventListener('click', function (event) {
				event.preventDefault();
				event.stopPropagation();
				showGalleryImage(galleryCurrent - 1);
			});
			if (nextImage) nextImage.addEventListener('click', function (event) {
				event.preventDefault();
				event.stopPropagation();
				showGalleryImage(galleryCurrent + 1);
			});
			galleryDots.forEach(function (dot) {
				dot.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					showGalleryImage(parseInt(dot.dataset.ghsGalleryGoto, 10));
				});
			});
			showGalleryImage(0);
		});

		root.addEventListener('keydown', function (event) {
			if (event.key === 'ArrowLeft') {
				event.preventDefault();
				show(current - 1, true);
			}
			if (event.key === 'ArrowRight') {
				event.preventDefault();
				show(current + 1, true);
			}
			if (event.key === 'Home') {
				event.preventDefault();
				show(0, true);
			}
			if (event.key === 'End') {
				event.preventDefault();
				show(slides.length - 1, true);
			}
		});

		/* Horizontal trackpad gestures, or Shift + mouse wheel, change slides. */
		root.addEventListener('wheel', function (event) {
			var movement = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : (event.shiftKey ? event.deltaY : 0);
			if (!movement || wheelLocked) return;
			event.preventDefault();
			wheelLocked = true;
			show(movement > 0 ? current + 1 : current - 1, true);
			window.setTimeout(function () { wheelLocked = false; }, 650);
		}, { passive: false });

		root.addEventListener('mouseenter', function () {
			hoverPaused = true;
			stopTimer();
			stopTriptychs();
			syncExpansionVideos();
		});
		root.addEventListener('mouseleave', function () {
			hoverPaused = false;
			root.style.setProperty('--ghs-px', '0');
			root.style.setProperty('--ghs-py', '0');
			startTimer();
			syncExpansionVideos();
			syncTriptychs();
		});
		root.addEventListener('focusin', function () {
			hoverPaused = true;
			stopTimer();
			stopTriptychs();
			syncExpansionVideos();
		});
		root.addEventListener('focusout', function (event) {
			if (!root.contains(event.relatedTarget)) {
				hoverPaused = false;
				startTimer();
				syncExpansionVideos();
				syncTriptychs();
			}
		});

		root.addEventListener('pointerdown', function (event) {
			if (!event.isPrimary || event.button > 0) return;
			if (event.target.closest('button, input, textarea, select, [contenteditable="true"], [data-ghs-gallery], .ghs-triptych-tabs')) return;
			gesture = { id: event.pointerId, x: event.clientX, y: event.clientY, time: Date.now(), horizontal: false };
			dragged = false;
		});
		root.addEventListener('pointermove', function (event) {
			if (!gesture || gesture.id !== event.pointerId) return;
			var moveX = event.clientX - gesture.x;
			var moveY = event.clientY - gesture.y;
			if (!gesture.horizontal && Math.abs(moveX) > 10 && Math.abs(moveX) > Math.abs(moveY) * 1.15) gesture.horizontal = true;
			if (gesture.horizontal) event.preventDefault();
		}, { passive: false });
		root.addEventListener('pointerup', function (event) {
			if (!gesture || gesture.id !== event.pointerId) return;
			var distanceX = event.clientX - gesture.x;
			var distanceY = event.clientY - gesture.y;
			var elapsed = Math.max(1, Date.now() - gesture.time);
			var fastSwipe = Math.abs(distanceX) > 26 && Math.abs(distanceX) / elapsed > 0.42;
			if ((Math.abs(distanceX) > 45 || fastSwipe) && Math.abs(distanceX) > Math.abs(distanceY) * 1.15) {
				dragged = true;
				show(distanceX > 0 ? current - 1 : current + 1, true);
				window.setTimeout(function () { dragged = false; }, 450);
			}
			gesture = null;
		});
		root.addEventListener('pointercancel', function () { gesture = null; });
		root.addEventListener('click', function (event) {
			if (dragged) {
				event.preventDefault();
				dragged = false;
			}
		}, true);

		if (window.matchMedia('(hover: hover) and (pointer: fine)').matches && !reducedMotion) {
			root.addEventListener('pointermove', function (event) {
				var rect = root.getBoundingClientRect();
				var x = ((event.clientX - rect.left) / rect.width - 0.5) * -5;
				var y = ((event.clientY - rect.top) / rect.height - 0.5) * -4;
				root.style.setProperty('--ghs-px', x.toFixed(2));
				root.style.setProperty('--ghs-py', y.toFixed(2));
			});
		}

		if ('IntersectionObserver' in window) {
			new IntersectionObserver(function (entries) {
				visible = entries[0].isIntersecting;
				syncExpansionVideos();
				syncTriptychs();
				startTimer();
			}, { threshold: 0.2 }).observe(root);
		}

		document.addEventListener('visibilitychange', function () {
			syncExpansionVideos();
			syncTriptychs();
			startTimer();
		});
		window.addEventListener('resize', function () {
			syncExpansionVideos();
			syncTriptychs();
			scheduleMobileHeight();
		});
		root.addEventListener('load', scheduleMobileHeight, true);
		if (document.fonts && document.fonts.ready) document.fonts.ready.then(scheduleMobileHeight).catch(function () {});
		show(0, false);
		prepareFirstSlide();
	}

	function boot() {
		document.querySelectorAll('[data-ghs-slider]').forEach(initSlider);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
}());
