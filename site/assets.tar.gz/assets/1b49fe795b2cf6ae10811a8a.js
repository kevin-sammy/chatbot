(function () {
    'use strict';

    function setupCarousel(root) {
        if (root.dataset.gqv2Ready === '1') return;
        root.dataset.gqv2Ready = '1';

        var track = root.querySelector('[data-gqv2-track]');
        var slides = Array.prototype.slice.call(root.querySelectorAll('[data-gqv2-slide]'));
        var dots = Array.prototype.slice.call(root.querySelectorAll('[data-gqv2-dot]'));
        var prev = root.querySelector('[data-gqv2-prev]');
        var next = root.querySelector('[data-gqv2-next]');
        var currentCounter = root.querySelector('[data-gqv2-current]');
        var adaptiveFrame = root.classList.contains('gqv2-media-shell--adaptive') ? root.querySelector('.gqv2-media') : null;
        var adaptiveIndex = -1;
        if (!track || slides.length < 2) return;

        function updateAdaptiveHeight(index, force) {
            if (!adaptiveFrame || (!force && adaptiveIndex === index)) return;
            var visual = slides[index] ? slides[index].querySelector('img, video') : null;
            if (!visual) return;
            var mediaWidth = adaptiveFrame.getBoundingClientRect().width;
            if (!mediaWidth) return;
            var visualWidth = parseFloat(visual.getAttribute('width')) || visual.videoWidth || visual.naturalWidth || 4;
            var visualHeight = parseFloat(visual.getAttribute('height')) || visual.videoHeight || visual.naturalHeight || 3;
            var ratio = visualWidth > 0 && visualHeight > 0 ? visualWidth / visualHeight : 4 / 3;
            // Keep very tall and very wide artwork usable without imposing one
            // universal crop on every poster or photograph.
            ratio = Math.max(3 / 4, Math.min(16 / 9, ratio));
            adaptiveFrame.style.height = Math.round(mediaWidth / ratio) + 'px';
            adaptiveIndex = index;
        }

        function nearestIndex() {
            var left = track.scrollLeft;
            var best = 0;
            var distance = Infinity;
            slides.forEach(function (slide, index) {
                var current = Math.abs(slide.offsetLeft - left);
                if (current < distance) {
                    distance = current;
                    best = index;
                }
            });
            return best;
        }

        function updateLimitedDots(activeIndex) {
            if (dots.length <= 5) return;
            var start = Math.max(0, Math.min(activeIndex - 2, dots.length - 5));
            dots.forEach(function (dot, index) {
                var visible = index >= start && index < start + 5;
                dot.classList.toggle('is-window-visible', visible);
                dot.classList.toggle('is-window-edge', visible && (index === start || index === start + 4));
            });
        }

        function update() {
            var index = nearestIndex();
            dots.forEach(function (dot, dotIndex) {
                dot.classList.toggle('is-active', dotIndex === index);
            });
            updateLimitedDots(index);
            if (currentCounter) currentCounter.textContent = String(index + 1);
            if (prev) prev.disabled = index === 0;
            if (next) next.disabled = index === slides.length - 1;
            updateAdaptiveHeight(index, false);
        }

        function go(index) {
            index = Math.max(0, Math.min(slides.length - 1, index));
            track.scrollTo({ left: slides[index].offsetLeft, behavior: 'smooth' });
        }

        if (prev) prev.addEventListener('click', function () { go(nearestIndex() - 1); });
        if (next) next.addEventListener('click', function () { go(nearestIndex() + 1); });
        dots.forEach(function (dot, index) { dot.addEventListener('click', function () { go(index); }); });
        track.addEventListener('scroll', function () { window.requestAnimationFrame(update); }, { passive: true });
        window.addEventListener('resize', function () {
            adaptiveIndex = -1;
            update();
        }, { passive: true });
        slides.forEach(function (slide) {
            var visual = slide.querySelector('img, video');
            if (visual) visual.addEventListener('load', function () { adaptiveIndex = -1; update(); }, { once: true });
            if (visual && visual.tagName === 'VIDEO') visual.addEventListener('loadedmetadata', function () { adaptiveIndex = -1; update(); }, { once: true });
        });
        update();

        var autoplay = parseInt(root.getAttribute('data-gqv2-autoplay') || '0', 10);
        if (autoplay > 0) {
            var timer = window.setInterval(function () {
                var current = nearestIndex();
                go(current >= slides.length - 1 ? 0 : current + 1);
            }, autoplay);
            root.addEventListener('mouseenter', function () { window.clearInterval(timer); }, { once: true });
        }
    }

    function cardMatchesFilter(card, wrap, filter) {
        var statuses = (card.getAttribute('data-gqv2-status') || '').split(/\s+/).filter(Boolean);
        if (filter === 'all') {
            if (wrap.getAttribute('data-gqv2-exclude-featured') === '1' && card.getAttribute('data-gqv2-featured-selection') === '1') return false;
            if (card.getAttribute('data-gqv2-filter-only')) return false;
            return true;
        }
        if (filter.indexOf('tax-') === 0) {
            var termId = filter.slice(4);
            var terms = (card.getAttribute('data-gqv2-tax-terms') || '').split(/\s+/).filter(Boolean);
            return terms.indexOf(termId) !== -1;
        }
        return statuses.indexOf(filter) !== -1;
    }

    function filterCards(wrap, filter, suppressEmpty) {
        var cards = Array.prototype.slice.call(wrap.querySelectorAll('[data-gqv2-filter-grid] .gqv2-card'));
        var empty = wrap.querySelector('[data-gqv2-filter-empty]');
        var visibleCount = 0;

        cards.forEach(function (card) {
            var matches = cardMatchesFilter(card, wrap, filter);
            if (matches) visibleCount += 1;

            if (matches) {
                card.hidden = false;
                window.requestAnimationFrame(function () {
                    card.classList.remove('is-filtered-out');
                    card.classList.add('is-filtered-in');
                });
            } else {
                card.classList.remove('is-filtered-in');
                card.classList.add('is-filtered-out');
                window.setTimeout(function () {
                    if (card.classList.contains('is-filtered-out')) card.hidden = true;
                }, 260);
            }
        });

        if (empty) {
            var showEmpty = !suppressEmpty && visibleCount === 0;
            empty.hidden = !showEmpty;
            empty.classList.toggle('is-visible', showEmpty);
        }
        return visibleCount;
    }

    function ajaxLoadedIds(wrap, filter) {
        return Array.prototype.slice.call(wrap.querySelectorAll('[data-gqv2-filter-grid] .gqv2-card')).filter(function (card) {
            // Filter-specific cards are intentionally not part of the default All
            // stream until All itself reaches them through Load More.
            return filter !== 'all' || !card.getAttribute('data-gqv2-filter-only');
        }).map(function (card) {
            return parseInt(card.getAttribute('data-gqv2-post-id') || '0', 10);
        }).filter(Boolean);
    }

    function setLoadMoreVisibility(wrap, filter, hasMore) {
        var button = wrap.querySelector('[data-gqv2-load-more]');
        if (!button) return;
        if ((wrap.getAttribute('data-gqv2-loading-mode') || '') !== 'load-more') {
            button.hidden = true;
            return;
        }
        if (filter === 'all' && typeof hasMore === 'undefined') {
            button.hidden = wrap.getAttribute('data-gqv2-all-has-more') !== '1';
            return;
        }
        button.hidden = hasMore === false;
    }

    function getMultiSelections(wrap) {
        var selections = {};
        wrap.querySelectorAll('[data-gqv2-filter-select]').forEach(function (group) {
            var taxonomy = group.getAttribute('data-gqv2-taxonomy') || '';
            if (!taxonomy) return;
            var ids = Array.prototype.slice.call(group.querySelectorAll('[data-gqv2-term-checkbox]:checked')).map(function (input) {
                return parseInt(input.value || '0', 10);
            }).filter(Boolean);
            if (ids.length) selections[taxonomy] = ids;
        });
        return selections;
    }

    function hasMultiSelections(wrap) {
        return Object.keys(getMultiSelections(wrap)).length > 0;
    }

    function getQuickSelections(wrap) {
        var selections = {};
        wrap.querySelectorAll('[data-gqv2-quick-group]').forEach(function (group) {
            var id = group.getAttribute('data-gqv2-quick-group') || '';
            var select = group.querySelector('[data-gqv2-quick-select]');
            var active = group.querySelector('[data-gqv2-filter].is-active');
            if (id) selections[id] = select ? (select.value || 'all') : (active ? (active.getAttribute('data-gqv2-filter') || 'all') : 'all');
        });
        return selections;
    }

    function updateEmptyMessage(wrap, filter, quickSelections) {
        var empty = wrap.querySelector('[data-gqv2-filter-empty]');
        if (!empty) return;
        var selectedType = quickSelections && quickSelections['content-type'] ? quickSelections['content-type'] : '';
        if (!selectedType || selectedType === 'all') selectedType = filter && filter.indexOf('type-') === 0 ? filter : '';
        var type = selectedType.indexOf('type-') === 0 ? selectedType.slice(5) : '';
        var message = type ? empty.getAttribute('data-gqv2-empty-' + type) : '';
        empty.textContent = message || empty.getAttribute('data-gqv2-empty-default') || empty.textContent;
    }

    function uiLabel(wrap, name, fallback) {
        var labels = wrap.querySelector('[data-gqv2-ui-labels]');
        return labels ? (labels.getAttribute('data-gqv2-' + name + '-label') || fallback) : fallback;
    }

    function selectedContentType(quickSelections) {
        var selected = quickSelections && quickSelections['content-type'] ? quickSelections['content-type'] : 'all';
        return selected.indexOf('type-') === 0 ? selected.slice(5) : '';
    }

    function moreAvailableLabel(quickSelections) {
        var type = selectedContentType(quickSelections);
        if (type === 'events') return 'More events are available.';
        if (type === 'deals') return 'More deals are available.';
        return 'More happenings are available.';
    }

    function homepageContinuationLabel(quickSelections) {
        var type = selectedContentType(quickSelections);
        if (type === 'events') return 'Explore more events in the full listing.';
        if (type === 'deals') return 'Explore more deals in the full listing.';
        return 'Explore more happenings in the full listing.';
    }

    function updateOnwardState(wrap, hasMore, terminalState, quickSelections) {
        var link = wrap.querySelector('[data-gqv2-onward]');
        if (!link) return;
        var isHome = wrap.classList.contains('gqv2-preset-home');
        var terminal = terminalState === 'capped' || terminalState === 'exhausted';
        var type = selectedContentType(quickSelections || getQuickSelections(wrap));
        var contextualLabel = type ? link.getAttribute('data-gqv2-' + type + '-label') : '';
        var contextualUrl = type ? link.getAttribute('data-gqv2-' + type + '-url') : '';
        link.hidden = !isHome && !terminal;
        link.textContent = contextualLabel || (terminal
            ? (link.getAttribute('data-gqv2-terminal-label') || link.textContent)
            : (link.getAttribute('data-gqv2-permanent-label') || link.textContent));
        link.href = contextualUrl || link.getAttribute('data-gqv2-mixed-url') || link.href;
        if (hasMore && !isHome) link.hidden = true;
    }

    function getDetailedFilters(wrap) {
        if (wrap.getAttribute('data-gqv2-detailed') !== '1') return {};
        var values = {};
        wrap.querySelectorAll('[data-gqv2-detail-group]').forEach(function (group) {
            var id = group.getAttribute('data-gqv2-detail-group') || '';
            var kind = group.getAttribute('data-gqv2-detail-kind') || '';
            var control = group.getAttribute('data-gqv2-detail-control') || '';
            if (!id) return;
            if (control === 'checkbox' || control === 'multiselect') {
                var checked = Array.prototype.slice.call(group.querySelectorAll('[data-gqv2-detail-input]:checked')).map(function (input) { return input.value; }).filter(Boolean);
                if (checked.length) values[id] = checked;
                return;
            }
            if (control === 'radio') {
                var radio = group.querySelector('[data-gqv2-detail-input]:checked');
                if (radio && radio.value) values[id] = radio.value;
                return;
            }
            var input = group.querySelector('[data-gqv2-detail-input]');
            if (!input) return;
            var value = String(input.value || '').trim();
            if (kind === 'sort') {
                var direction = group.querySelector('[data-gqv2-sort-direction]');
                values[id] = (value || input.getAttribute('data-gqv2-detail-default') || 'recommended') + '_' + (direction ? direction.getAttribute('data-direction') || 'asc' : 'asc');
                return;
            }
            if (value || kind === 'sort') values[id] = value || input.getAttribute('data-gqv2-detail-default') || 'recommended';
        });
        return values;
    }

    function hasDetailedFilters(wrap) {
        return Array.prototype.slice.call(wrap.querySelectorAll('[data-gqv2-detail-group]')).some(function (group) {
            var control = group.getAttribute('data-gqv2-detail-control') || '';
            var kind = group.getAttribute('data-gqv2-detail-kind') || '';
            if (control === 'checkbox' || control === 'multiselect') return !!group.querySelector('[data-gqv2-detail-input]:checked');
            if (control === 'radio') {
                var radio = group.querySelector('[data-gqv2-detail-input]:checked');
                return !!(radio && radio.value);
            }
            var input = group.querySelector('[data-gqv2-detail-input]');
            if (!input) return false;
            var value = String(input.value || '').trim();
            if (kind === 'sort') {
                var direction = group.querySelector('[data-gqv2-sort-direction]');
                var current = value + '_' + (direction ? direction.getAttribute('data-direction') || 'asc' : 'asc');
                var initial = (input.getAttribute('data-gqv2-detail-default') || 'recommended') + '_' + (direction ? direction.getAttribute('data-default-direction') || 'asc' : 'asc');
                return current !== initial;
            }
            return !!value;
        });
    }

    function applyFilterAvailability(wrap, availability) {
        availability = availability || {};
        var quick = availability.quick || {};
        wrap.querySelectorAll('[data-gqv2-quick-group]').forEach(function (group) {
            var id = group.getAttribute('data-gqv2-quick-group') || '';
            var counts = quick[id] || {};
            var keepEmptyOptions = group.getAttribute('data-gqv2-keep-empty-options') === '1';
            var visibleOptions = 0;
            group.querySelectorAll('[data-gqv2-quick-select] option').forEach(function (option) {
                if (option.value === 'all') return;
                var available = parseInt(counts[option.value] || '0', 10) > 0;
                option.disabled = !keepEmptyOptions && !available && !option.selected;
                if (keepEmptyOptions || available || option.selected) visibleOptions += 1;
            });
            group.querySelectorAll('[data-gqv2-filter]').forEach(function (button) {
                var value = button.getAttribute('data-gqv2-filter') || 'all';
                if (value === 'all') return;
                var available = parseInt(counts[value] || '0', 10) > 0;
                var active = button.classList.contains('is-active');
                button.hidden = !keepEmptyOptions && !available && !active;
                button.disabled = !keepEmptyOptions && !available && !active;
                button.classList.toggle('is-unavailable', !available);
                if (keepEmptyOptions || available || active) visibleOptions += 1;
            });
            group.hidden = !keepEmptyOptions && visibleOptions === 0;
        });

        var detailed = availability.detailed || {};
        wrap.querySelectorAll('[data-gqv2-detail-group]').forEach(function (group) {
            var id = group.getAttribute('data-gqv2-detail-group') || '';
            if (!Object.prototype.hasOwnProperty.call(detailed, id)) return;
            var available = detailed[id] || [];
            group.querySelectorAll('[data-gqv2-detail-input]').forEach(function (input) {
                if (input.tagName === 'SELECT') return;
                var value = String(input.value || '');
                if (!value) return;
                var selected = input.tagName === 'OPTION' ? input.selected : (input.matches('input') ? input.checked : false);
                var enabled = available.indexOf(value) !== -1;
                input.disabled = !enabled && !selected;
                var option = input.closest('[data-gqv2-detail-option]');
                if (option) option.classList.toggle('is-unavailable', !enabled && !selected);
            });
            group.querySelectorAll('select[data-gqv2-detail-input] option').forEach(function (option) {
                if (!option.value) return;
                var enabled = available.indexOf(String(option.value)) !== -1;
                option.disabled = !enabled && !option.selected;
            });
        });
        var detailedBar = wrap.querySelector('[data-gqv2-detailed-filters]');
        if (detailedBar && typeof detailedBar._gqv2PositionOpenPanel === 'function') {
            window.requestAnimationFrame(detailedBar._gqv2PositionOpenPanel);
        }
    }

    function getDealFilters(wrap) {
        if (wrap.getAttribute('data-gqv2-deal-advanced') !== '1') return {};
        var search = wrap.querySelector('[data-gqv2-deal-search]');
        var store = wrap.querySelector('[data-gqv2-deal-store]');
        var category = wrap.querySelector('[data-gqv2-deal-category]');
        var sort = wrap.querySelector('[data-gqv2-deal-sort]');
        return {
            search: search ? String(search.value || '').trim() : '',
            store: store ? parseInt(store.value || '0', 10) : 0,
            category: category ? parseInt(category.value || '0', 10) : 0,
            sort: sort ? (sort.value || 'recommended') : 'recommended'
        };
    }

    function hasDealFilters(wrap) {
        var filters = getDealFilters(wrap);
        return !!(filters.search || filters.store || filters.category || (filters.sort && filters.sort !== 'recommended'));
    }

    function updateAjaxPagination(wrap, totalPages, currentPage) {
        var nav = wrap.querySelector('[data-gqv2-pagination]');
        if (!nav) return;
        totalPages = Math.max(1, parseInt(totalPages || '1', 10));
        currentPage = Math.max(1, parseInt(currentPage || '1', 10));
        if (totalPages <= 1) {
            nav.hidden = true;
            nav.innerHTML = '';
            return;
        }
        nav.hidden = false;
        var pages = [];
        function addPage(page) {
            if (pages.indexOf(page) === -1 && page >= 1 && page <= totalPages) pages.push(page);
        }
        addPage(1); addPage(2); addPage(currentPage - 1); addPage(currentPage); addPage(currentPage + 1); addPage(totalPages - 1); addPage(totalPages);
        pages.sort(function (a, b) { return a - b; });
        var ul = document.createElement('ul');
        if (currentPage > 1) {
            var prevLi = document.createElement('li');
            var prev = document.createElement('a'); prev.href = '#'; prev.textContent = 'Previous'; prev.dataset.gqv2AjaxPage = String(currentPage - 1); prevLi.appendChild(prev); ul.appendChild(prevLi);
        }
        var last = 0;
        pages.forEach(function (page) {
            if (last && page - last > 1) {
                var dotsLi = document.createElement('li'); var dots = document.createElement('span'); dots.className = 'page-numbers dots'; dots.textContent = '…'; dotsLi.appendChild(dots); ul.appendChild(dotsLi);
            }
            var li = document.createElement('li');
            if (page === currentPage) {
                var span = document.createElement('span'); span.className = 'page-numbers current'; span.textContent = String(page); li.appendChild(span);
            } else {
                var a = document.createElement('a'); a.href = '#'; a.className = 'page-numbers'; a.textContent = String(page); a.dataset.gqv2AjaxPage = String(page); li.appendChild(a);
            }
            ul.appendChild(li); last = page;
        });
        if (currentPage < totalPages) {
            var nextLi = document.createElement('li');
            var next = document.createElement('a'); next.href = '#'; next.textContent = 'Next »'; next.dataset.gqv2AjaxPage = String(currentPage + 1); nextLi.appendChild(next); ul.appendChild(nextLi);
        }
        nav.innerHTML = ''; nav.appendChild(ul);
        nav.querySelectorAll('[data-gqv2-ajax-page]').forEach(function (link) {
            link.addEventListener('click', function (event) {
                event.preventDefault();
                var page = parseInt(link.dataset.gqv2AjaxPage || '1', 10);
                refreshFromServer(wrap, page);
            });
        });
    }

    function refreshFromServer(wrap, page, options) {
        options = options || {};
        var mode = wrap.getAttribute('data-gqv2-display-mode') || 'grid';
        var limit = mode === 'grid' ? parseInt(wrap.getAttribute('data-gqv2-posts-per-page') || '6', 10) : parseInt(wrap.getAttribute('data-gqv2-max-posts') || '8', 10);
        var active = wrap.dataset.gqv2ActiveFilter || 'all';
        return requestBatch(wrap, active, limit, false, { replace: true, page: page || 1, selections: getMultiSelections(wrap), detailedFilters: getDetailedFilters(wrap), quickSelections: getQuickSelections(wrap), forceFresh: !!options.forceFresh, silent: !!options.silent });
    }

    function requestBatch(wrap, filter, limit, isLoadMore, options) {
        options = options || {};
        if (!window.GQV2) return Promise.resolve(null);
        var grid = wrap.querySelector('[data-gqv2-filter-grid]');
        var status = wrap.querySelector('[data-gqv2-load-status]');
        var button = wrap.querySelector('[data-gqv2-load-more]');
        if (!grid) return Promise.resolve(null);
        var replace = !!options.replace;
        var silent = !!options.silent;
        var requestedPage = parseInt(options.page || '0', 10);
        var selections = options.selections || getMultiSelections(wrap);
        var detailedFilters = options.detailedFilters || getDetailedFilters(wrap);
        var quickSelections = options.quickSelections || getQuickSelections(wrap);
        updateEmptyMessage(wrap, filter, quickSelections);
		var previousState = wrap.dataset.gqv2State || 'idle';

        if (wrap.dataset.gqv2RequestPending === '1') {
            if (!replace) return Promise.resolve(null);
            if (wrap._gqv2RequestController) wrap._gqv2RequestController.abort();
        }
        var requestId = (wrap._gqv2RequestId || 0) + 1;
        wrap._gqv2RequestId = requestId;

        wrap.dataset.gqv2RequestPending = '1';
		if (!silent) wrap.dataset.gqv2State = 'loading';
        var empty = wrap.querySelector('[data-gqv2-filter-empty]');
        if (!silent && empty) {
            empty.hidden = true;
            empty.classList.remove('is-visible');
        }
        if (!silent) {
            var currentGridHeight = Math.ceil(grid.getBoundingClientRect().height);
            if (currentGridHeight > 0) {
                wrap.style.setProperty('--gqv2-loading-grid-height', currentGridHeight + 'px');
            }
            wrap.classList.add('is-gqv2-loading');
            if (button) {
                button.disabled = true;
                button.classList.add('is-loading');
            }
            if (status) status.textContent = isLoadMore ? uiLabel(wrap, 'loading', 'Loading more…') : 'Checking for more…';
        }

        var loadedIds = replace ? [] : ajaxLoadedIds(wrap, filter);
        var data = new URLSearchParams();
        data.append('action', 'gqv2_load_more');
        data.append('nonce', window.GQV2.nonce || '');
        data.append('filter', filter);
        data.append('limit', String(Math.max(1, limit || 1)));
        data.append('attributes', wrap.getAttribute('data-gqv2-attributes') || '{}');
        data.append('filterSelections', JSON.stringify(selections || {}));
        data.append('detailedFilters', JSON.stringify(detailedFilters || {}));
        data.append('quickSelections', JSON.stringify(quickSelections || {}));
        data.append('includeAvailability', replace ? '1' : '0');
        if (requestedPage > 0) data.append('page', String(requestedPage));
        loadedIds.forEach(function (id) { data.append('loadedIds[]', String(id)); });

        var cacheKey = replace ? data.toString() : '';
        var cache = wrap._gqv2ResponseCache || new Map();
        var cached = !options.forceFresh && cacheKey ? cache.get(cacheKey) : null;
        var cacheIsFresh = cached && Date.now() - cached.time < 20000;
        if (!cacheIsFresh && cached) cache.delete(cacheKey);
        wrap._gqv2ResponseCache = cache;

        var controller = !cacheIsFresh && window.AbortController ? new AbortController() : null;
        wrap._gqv2RequestController = controller;
        var request = cacheIsFresh ? Promise.resolve(cached.payload) : fetch(window.GQV2.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: data.toString(),
            signal: controller ? controller.signal : undefined
        }).then(function (response) { return response.json(); }).then(function (payload) {
            if (cacheKey && payload && payload.success) {
                cache.set(cacheKey, { time: Date.now(), payload: payload });
                while (cache.size > 20) cache.delete(cache.keys().next().value);
            }
            return payload;
        });

        return request.then(function (payload) {
            if (requestId !== wrap._gqv2RequestId) return null;
            if (!payload || !payload.success) throw new Error('load_failed');
            var holder = document.createElement('div');
            holder.innerHTML = payload.data.html || '';
            var nodes = Array.prototype.slice.call(holder.children);

            if (replace) grid.innerHTML = '';
            nodes.forEach(function (node) {
                var postId = node.getAttribute('data-gqv2-post-id');
                var existing = postId ? grid.querySelector('.gqv2-card[data-gqv2-post-id="' + postId + '"]') : null;
                if (existing) {
                    if (filter === 'all') existing.removeAttribute('data-gqv2-filter-only');
                    return;
                }
                if (!replace && filter !== 'all') node.setAttribute('data-gqv2-filter-only', filter);
                if (!cacheIsFresh) node.classList.add('is-new-card');
                grid.appendChild(node);
            });

            init(grid);
            setupDealStatusSync(wrap);
            window.requestAnimationFrame(function () {
                grid.querySelectorAll('.is-new-card').forEach(function (node) { node.classList.remove('is-new-card'); });
            });

            var active = wrap.dataset.gqv2ActiveFilter || 'all';
            if (replace) {
                var empty = wrap.querySelector('[data-gqv2-filter-empty]');
                if (empty) {
                    empty.hidden = nodes.length > 0;
                    empty.classList.toggle('is-visible', nodes.length === 0);
                }
                if ((wrap.getAttribute('data-gqv2-loading-mode') || '') === 'pagination') {
                    updateAjaxPagination(wrap, payload.data.totalPages || 1, payload.data.page || 1);
                }
                setupContentStrips(wrap);
            } else {
                filterCards(wrap, active, false);
            }
            if (payload.data.filterAvailability) applyFilterAvailability(wrap, payload.data.filterAvailability);
            setLoadMoreVisibility(wrap, active, !!payload.data.hasMore);
            updateOnwardState(wrap, !!payload.data.hasMore, payload.data.terminalState || (payload.data.hasMore ? 'more' : 'exhausted'), quickSelections);
			if (!silent) {
				if (replace && parseInt(payload.data.totalMatches || '0', 10) === 0) wrap.dataset.gqv2State = 'initial-empty';
				else if (payload.data.terminalState === 'capped') wrap.dataset.gqv2State = 'homepage-cap-reached';
				else if (payload.data.terminalState === 'exhausted') wrap.dataset.gqv2State = 'true-exhausted';
				else wrap.dataset.gqv2State = 'more-results-available';
			}
            if (status && !silent) {
                if (payload.data.terminalState === 'capped') status.textContent = homepageContinuationLabel(quickSelections);
                else if (replace) status.textContent = '';
                else if (!payload.data.hasMore && payload.data.terminalState === 'exhausted') status.textContent = uiLabel(wrap, 'exhausted', 'No more items.');
                else if (nodes.length && payload.data.hasMore) status.textContent = moreAvailableLabel(quickSelections);
                else if (nodes.length) status.textContent = nodes.length + (nodes.length === 1 ? ' more item loaded.' : ' more items loaded.');
                else status.textContent = '';
            }
            wrap._gqv2Exhausted = wrap._gqv2Exhausted || {};
            wrap._gqv2Exhausted[filter] = !payload.data.hasMore;
            return payload.data;
        }).catch(function (error) {
            if ((error && error.name === 'AbortError') || requestId !== wrap._gqv2RequestId) return null;
            if (status && !silent) status.textContent = 'Could not load more posts. Please try again.';
			if (!silent) wrap.dataset.gqv2State = previousState;
            return null;
        }).finally(function () {
            if (requestId !== wrap._gqv2RequestId) return;
            wrap.dataset.gqv2RequestPending = '0';
            wrap._gqv2RequestController = null;
            if (!silent) {
                wrap.classList.remove('is-gqv2-loading');
                window.requestAnimationFrame(function () {
                    wrap.style.removeProperty('--gqv2-loading-grid-height');
                });
                if (button) {
                    button.disabled = false;
                    button.classList.remove('is-loading');
                }
            }
        });
    }

    function ensureFilterQuota(wrap, filter) {
        if (filter === 'all' || !window.GQV2) return;
        var perPage = parseInt(wrap.getAttribute('data-gqv2-posts-per-page') || '6', 10);
        var visible = filterCards(wrap, filter, true);
        wrap._gqv2Exhausted = wrap._gqv2Exhausted || {};
        if (visible >= perPage || wrap._gqv2Exhausted[filter]) {
            filterCards(wrap, filter, false);
            setLoadMoreVisibility(wrap, filter, visible >= perPage ? undefined : false);
            return;
        }
        requestBatch(wrap, filter, perPage - visible, false).then(function (data) {
            if (!data) filterCards(wrap, filter, false);
        });
    }

    function setupFilters(root) {
        if (root.dataset.gqv2FilterReady === '1') return;
        root.dataset.gqv2FilterReady = '1';
        var wrap = root.closest('.gqv2-wrap');
        if (!wrap) return;
        var isQuickGroup = root.hasAttribute('data-gqv2-quick-group');
        var buttons = Array.prototype.slice.call(root.querySelectorAll('[data-gqv2-filter]'));
        var quickSelect = root.querySelector('[data-gqv2-quick-select]');
        if (quickSelect) quickSelect.addEventListener('change', function () {
            wrap.dataset.gqv2ActiveFilter = 'all';
            refreshFromServer(wrap, 1);
        });
        buttons.forEach(function (button) {
            button.addEventListener('click', function () {
                var filter = button.getAttribute('data-gqv2-filter') || 'all';
                wrap.dataset.gqv2ActiveFilter = isQuickGroup ? 'all' : filter;
                root.querySelectorAll('[data-gqv2-filter]').forEach(function (item) {
                    var selected = item === button;
                    item.classList.toggle('is-active', selected);
                    item.setAttribute('aria-pressed', selected ? 'true' : 'false');
                });
                if (isQuickGroup || wrap.getAttribute('data-gqv2-detailed') === '1') {
                    refreshFromServer(wrap, 1);
                } else if (hasMultiSelections(wrap)) {
                    refreshFromServer(wrap, 1);
                } else if (filter === 'all') {
                    filterCards(wrap, filter, false);
                    setLoadMoreVisibility(wrap, 'all');
                } else {
                    ensureFilterQuota(wrap, filter);
                }
            });
        });

        var active = root.querySelector('[data-gqv2-filter].is-active');
        if (active && active.getAttribute('data-gqv2-filter') !== 'all' && !root.querySelector('[data-gqv2-filter="all"]')) {
            var initialFilter = active.getAttribute('data-gqv2-filter');
            wrap.dataset.gqv2ActiveFilter = initialFilter;
            ensureFilterQuota(wrap, initialFilter);
        }
    }

    function setupLoadMore(button) {
        if (button.dataset.gqv2LoadReady === '1') return;
        button.dataset.gqv2LoadReady = '1';
        var wrap = button.closest('.gqv2-wrap');
        if (!wrap || !window.GQV2) return;
        if (button.hidden && wrap.querySelector('[data-gqv2-onward]')) {
            var status = wrap.querySelector('[data-gqv2-load-status]');
            if (status) status.textContent = homepageContinuationLabel(getQuickSelections(wrap));
        }
        button.addEventListener('click', function () {
            if (button.disabled) return;
            var active = wrap.dataset.gqv2ActiveFilter || 'all';
            var perPage = parseInt(wrap.getAttribute('data-gqv2-posts-per-page') || '6', 10);
            requestBatch(wrap, active, perPage, true);
        });
    }


    function renderTermOptions(group, terms) {
        var holder = group.querySelector('[data-gqv2-term-options]');
        var hint = group.querySelector('[data-gqv2-term-hint]');
        if (!holder) return;
        var selected = {};
        group.querySelectorAll('[data-gqv2-term-checkbox]:checked').forEach(function (input) {
            var label = input.closest('[data-gqv2-term-option]');
            selected[String(input.value)] = label ? label.textContent.trim() : String(input.value);
        });
        var merged = [];
        Object.keys(selected).forEach(function (id) { merged.push({ id: parseInt(id, 10), name: selected[id], selected: true }); });
        (terms || []).forEach(function (term) {
            if (!selected[String(term.id)]) merged.push(term);
        });
        holder.innerHTML = '';
        merged.forEach(function (term) {
            var label = document.createElement('label');
            label.className = 'gqv2-filter-option';
            label.setAttribute('data-gqv2-term-option', '');
            label.setAttribute('data-gqv2-term-name', String(term.name || '').toLowerCase());
            var input = document.createElement('input');
            input.type = 'checkbox'; input.value = String(term.id); input.setAttribute('data-gqv2-term-checkbox', ''); input.checked = !!selected[String(term.id)];
            var span = document.createElement('span'); span.textContent = term.name || '';
            label.appendChild(input); label.appendChild(document.createTextNode(' ')); label.appendChild(span); holder.appendChild(label);
        });
        if (hint) hint.hidden = !!(terms && terms.length);
    }

    function updateMultiFilterCounts(wrap) {
        var any = false;
        wrap.querySelectorAll('[data-gqv2-filter-select]').forEach(function (group) {
            var count = group.querySelectorAll('[data-gqv2-term-checkbox]:checked').length;
            var badge = group.querySelector('[data-gqv2-filter-count]');
            if (badge) { badge.hidden = count === 0; badge.textContent = count ? String(count) : ''; }
            if (count) any = true;
        });
        var clearAll = wrap.querySelector('[data-gqv2-clear-all]');
        if (clearAll) clearAll.hidden = !any;
    }

    function setupMultiFilters(root) {
        var wrap = root.classList && root.classList.contains('gqv2-wrap') ? root : root.closest && root.closest('.gqv2-wrap');
        if (!wrap) return;
        var bar = wrap.querySelector('[data-gqv2-multi-filters]');
        if (!bar || bar.dataset.gqv2MultiReady === '1') return;
        bar.dataset.gqv2MultiReady = '1';
        var searchTimers = {};
        var refreshTimer = null;
        function queueRefresh() {
            window.clearTimeout(refreshTimer);
            refreshTimer = window.setTimeout(function () { refreshFromServer(wrap, 1); }, 180);
        }

        function closeOthers(except) {
            bar.querySelectorAll('[data-gqv2-filter-select]').forEach(function (group) {
                if (group === except) return;
                var panel = group.querySelector('[data-gqv2-filter-panel]');
                var toggle = group.querySelector('[data-gqv2-filter-toggle]');
                if (panel) panel.hidden = true;
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
            });
        }

        bar.querySelectorAll('[data-gqv2-filter-select]').forEach(function (group) {
            var taxonomy = group.getAttribute('data-gqv2-taxonomy') || '';
            var curated = group.getAttribute('data-gqv2-curated') === '1';
            var toggle = group.querySelector('[data-gqv2-filter-toggle]');
            var panel = group.querySelector('[data-gqv2-filter-panel]');
            var search = group.querySelector('[data-gqv2-term-search]');
            var clear = group.querySelector('[data-gqv2-filter-clear]');
            if (toggle && panel) toggle.addEventListener('click', function () {
                var opening = panel.hidden;
                closeOthers(group); panel.hidden = !opening; toggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
                if (opening && search) search.focus();
            });
            group.addEventListener('change', function (event) {
                if (!event.target.matches('[data-gqv2-term-checkbox]')) return;
                updateMultiFilterCounts(wrap); queueRefresh();
            });
            if (clear) clear.addEventListener('click', function () {
                group.querySelectorAll('[data-gqv2-term-checkbox]:checked').forEach(function (input) { input.checked = false; });
                updateMultiFilterCounts(wrap); queueRefresh();
            });
            if (search) search.addEventListener('input', function () {
                var value = String(search.value || '').trim().toLowerCase();
                if (curated) {
                    group.querySelectorAll('[data-gqv2-term-option]').forEach(function (option) {
                        option.hidden = value.length > 0 && (option.getAttribute('data-gqv2-term-name') || '').indexOf(value) === -1;
                    });
                    return;
                }
                window.clearTimeout(searchTimers[taxonomy]);
                if (value.length < 2) return;
                searchTimers[taxonomy] = window.setTimeout(function () {
                    var data = new URLSearchParams();
                    data.append('action', 'gqv2_search_terms'); data.append('nonce', window.GQV2.nonce || ''); data.append('taxonomy', taxonomy); data.append('search', value); data.append('attributes', wrap.getAttribute('data-gqv2-attributes') || '{}');
                    fetch(window.GQV2.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: data.toString() })
                        .then(function (r) { return r.json(); }).then(function (payload) { if (payload && payload.success) renderTermOptions(group, payload.data.terms || []); });
                }, 280);
            });
        });
        var clearAll = bar.querySelector('[data-gqv2-clear-all]');
        if (clearAll) clearAll.addEventListener('click', function () {
            bar.querySelectorAll('[data-gqv2-term-checkbox]:checked').forEach(function (input) { input.checked = false; });
            updateMultiFilterCounts(wrap); queueRefresh();
        });
        document.addEventListener('click', function (event) { if (!bar.contains(event.target)) closeOthers(null); });
        updateMultiFilterCounts(wrap);
    }

    function setupDetailedFilters(root) {
        var wrap = root.classList && root.classList.contains('gqv2-wrap') ? root : root.closest && root.closest('.gqv2-wrap');
        if (!wrap || wrap.getAttribute('data-gqv2-detailed') !== '1') return;
        var bar = wrap.querySelector('[data-gqv2-detailed-filters]');
        if (!bar || bar.dataset.gqv2DetailedReady === '1') return;
        bar.dataset.gqv2DetailedReady = '1';
        var timer = null;
        var resizeTimer = null;
        var clearAll = bar.querySelector('[data-gqv2-detailed-clear]');

        function positionOpenPanel() {
            var open = bar.querySelector('[data-gqv2-detail-multiselect].is-open');
            var panel = open ? open.querySelector('[data-gqv2-detail-panel]') : null;
            if (!open || !panel || panel.hidden) {
                bar.classList.remove('has-open-panel');
                bar.style.removeProperty('--gqv2-detail-panel-top');
                bar.style.removeProperty('--gqv2-detail-panel-space');
                return;
            }
            var barRect = bar.getBoundingClientRect();
            var controls = Array.prototype.slice.call(bar.querySelectorAll('[data-gqv2-detail-group], [data-gqv2-detailed-clear]')).filter(function (control) {
                return !control.hidden;
            });
            var bottom = controls.reduce(function (maximum, control) {
                return Math.max(maximum, control.getBoundingClientRect().bottom - barRect.top);
            }, 40);
            bar.style.setProperty('--gqv2-detail-panel-top', Math.ceil(bottom + 10) + 'px');
            bar.style.setProperty('--gqv2-detail-panel-space', Math.ceil(panel.offsetHeight + 10) + 'px');
            bar.classList.add('has-open-panel');
        }
        bar._gqv2PositionOpenPanel = positionOpenPanel;

        function updateState() {
            bar.querySelectorAll('[data-gqv2-detail-multiselect]').forEach(function (select) {
                var count = select.querySelectorAll('[data-gqv2-detail-input]:checked').length;
                var badge = select.querySelector('[data-gqv2-detail-count]');
                if (badge) { badge.hidden = !count; badge.textContent = count ? String(count) : ''; }
                select.classList.toggle('has-selection', count > 0);
                var group = select.closest('[data-gqv2-detail-group]');
                if (group) group.classList.toggle('has-selection', count > 0);
            });
            if (clearAll) {
                var filtersActive = hasDetailedFilters(wrap);
                clearAll.hidden = false;
                clearAll.disabled = !filtersActive;
                clearAll.classList.toggle('is-inactive', !filtersActive);
                clearAll.setAttribute('aria-hidden', filtersActive ? 'false' : 'true');
            }
            if (bar.classList.contains('has-open-panel')) window.requestAnimationFrame(positionOpenPanel);
        }
        function refresh(delay) {
            window.clearTimeout(timer);
            timer = window.setTimeout(function () { updateState(); refreshFromServer(wrap, 1); }, delay || 0);
        }
        function closePanels(except) {
            bar.querySelectorAll('[data-gqv2-detail-multiselect]').forEach(function (select) {
                if (select === except) return;
                var panel = select.querySelector('[data-gqv2-detail-panel]');
                var toggle = select.querySelector('[data-gqv2-detail-toggle]');
                if (panel) panel.hidden = true;
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
                select.classList.remove('is-open');
            });
            if (!except) positionOpenPanel();
        }

        bar.querySelectorAll('[data-gqv2-detail-multiselect]').forEach(function (select) {
            var toggle = select.querySelector('[data-gqv2-detail-toggle]');
            var panel = select.querySelector('[data-gqv2-detail-panel]');
            var search = select.querySelector('[data-gqv2-detail-search]');
            var clear = select.querySelector('[data-gqv2-detail-clear]');
            if (toggle && panel) toggle.addEventListener('click', function () {
                var opening = panel.hidden;
                closePanels(select);
                panel.hidden = !opening;
                select.classList.toggle('is-open', opening);
                toggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
                if (opening) {
                    window.requestAnimationFrame(function () {
                        positionOpenPanel();
                        if (search) search.focus({ preventScroll: true });
                    });
                } else {
                    positionOpenPanel();
                }
            });
            if (search) search.addEventListener('input', function () {
                var value = String(search.value || '').trim().toLowerCase();
                select.querySelectorAll('[data-gqv2-detail-option]').forEach(function (option) {
                    option.hidden = !!value && (option.getAttribute('data-gqv2-term-name') || '').indexOf(value) === -1;
                });
            });
            if (clear) clear.addEventListener('click', function () {
                select.querySelectorAll('[data-gqv2-detail-input]:checked').forEach(function (input) { input.checked = false; });
                refresh(0);
            });
        });

        bar.addEventListener('change', function (event) {
            if (!event.target.matches('[data-gqv2-detail-input]')) return;
            var group = event.target.closest('[data-gqv2-detail-group]');
            var control = group ? (group.getAttribute('data-gqv2-detail-control') || '') : '';
            if (group && group.getAttribute('data-gqv2-detail-kind') === 'sort') {
                var direction = group.querySelector('[data-gqv2-sort-direction]');
                var naturalDirection = event.target.value === 'newest' ? 'desc' : 'asc';
                if (direction) setSortDirection(direction, naturalDirection);
            }
            updateState();
            refresh(control === 'checkbox' || control === 'multiselect' ? 240 : 0);
        });
        function setSortDirection(button, direction) {
            direction = direction === 'desc' ? 'desc' : 'asc';
            var label = direction === 'asc' ? 'Sort ascending' : 'Sort descending';
            button.setAttribute('data-direction', direction);
            button.setAttribute('aria-label', label);
            button.setAttribute('title', label);
            var icon = button.querySelector('[aria-hidden="true"]');
            if (icon) icon.textContent = direction === 'asc' ? '↑' : '↓';
        }
        bar.querySelectorAll('[data-gqv2-sort-direction]').forEach(function (button) {
            button.addEventListener('click', function () {
                setSortDirection(button, button.getAttribute('data-direction') === 'asc' ? 'desc' : 'asc');
                updateState();
                refresh(0);
            });
        });
        bar.querySelectorAll('input[type="search"][data-gqv2-detail-input]').forEach(function (search) {
            search.addEventListener('input', function () { refresh(320); });
        });
        if (clearAll) clearAll.addEventListener('click', function () {
            bar.querySelectorAll('[data-gqv2-detail-group]').forEach(function (group) {
                var control = group.getAttribute('data-gqv2-detail-control') || '';
                if (control === 'checkbox' || control === 'multiselect') group.querySelectorAll('[data-gqv2-detail-input]').forEach(function (input) { input.checked = false; });
                else if (control === 'radio') {
                    var empty = group.querySelector('[data-gqv2-detail-input][value=""]');
                    if (empty) empty.checked = true;
                } else {
                    var input = group.querySelector('[data-gqv2-detail-input]');
                    if (input) input.value = input.getAttribute('data-gqv2-detail-default') || '';
                    var direction = group.querySelector('[data-gqv2-sort-direction]');
                    if (direction) setSortDirection(direction, direction.getAttribute('data-default-direction') || 'asc');
                }
            });
            refresh(0);
        });
        document.addEventListener('click', function (event) { if (!bar.contains(event.target)) closePanels(null); });
        window.addEventListener('resize', function () {
            window.clearTimeout(resizeTimer);
            resizeTimer = window.setTimeout(positionOpenPanel, 100);
        }, { passive: true });
        updateState();
    }

    function setupDealFilters(root) {
        var wrap = root.classList && root.classList.contains('gqv2-wrap') ? root : root.closest && root.closest('.gqv2-wrap');
        if (!wrap || wrap.getAttribute('data-gqv2-deal-advanced') !== '1') return;
        var bar = wrap.querySelector('[data-gqv2-deal-filters]');
        if (!bar || bar.dataset.gqv2DealReady === '1') return;
        bar.dataset.gqv2DealReady = '1';
        var search = bar.querySelector('[data-gqv2-deal-search]');
        var clear = bar.querySelector('[data-gqv2-deal-clear]');
        var timer = null;

        function updateClear() {
            if (clear) clear.hidden = !hasDealFilters(wrap);
        }
        function refresh(delay) {
            window.clearTimeout(timer);
            timer = window.setTimeout(function () {
                updateClear();
                refreshFromServer(wrap, 1);
            }, delay || 0);
        }

        bar.querySelectorAll('select').forEach(function (select) {
            select.addEventListener('change', function () { refresh(0); });
        });
        if (search) search.addEventListener('input', function () { refresh(320); });
        if (clear) clear.addEventListener('click', function () {
            if (search) search.value = '';
            bar.querySelectorAll('select').forEach(function (select) { select.selectedIndex = 0; });
            refresh(0);
        });
        updateClear();
    }

    function applyDealState(card, state) {
        if (!card || !state) return false;
        var previous = card.getAttribute('data-gqv2-live-status') || '';
        var status = state.status || 'available';
        card.setAttribute('data-gqv2-live-status', status);
        var lifecycleStatuses = ['ongoing', 'today', 'soon', 'starting_soon', 'starting-soon', 'upcoming', 'available', 'ended', 'expired', 'removed'];
        var statuses = (card.getAttribute('data-gqv2-status') || '').split(/\s+/).filter(Boolean).filter(function (value) {
            return lifecycleStatuses.indexOf(value) === -1;
        });
        statuses.push(status);
        // Keep the established `soon` filter compatible with Core's canonical
        // future Event states during silent lifecycle reconciliation.
        if (status === 'upcoming' || status === 'starting_soon') statuses.push('soon');
        if (state.isToday && status !== 'today') statuses.push('today');
        card.setAttribute('data-gqv2-status', statuses.join(' '));
        lifecycleStatuses.forEach(function (value) {
            var active = value === status || (value === 'starting-soon' && status === 'starting_soon') || (value === 'soon' && status === 'starting_soon');
            card.classList.toggle('is-' + value.replace('_', '-'), active);
        });

        var media = card.querySelector('.gqv2-card__media-wrap');
        var banner = card.querySelector('.gqv2-card__status-banner');
        if (state.bannerLabel) {
            if (!banner && media) {
                banner = document.createElement('span');
                media.insertBefore(banner, media.firstChild);
            }
            if (banner) {
                banner.className = 'gqv2-card__status-banner gqv2-card__status-banner--' + (state.bannerKey || status);
                banner.textContent = state.bannerLabel;
            }
        } else if (banner) {
            banner.remove();
        }
        return previous && previous !== status;
    }

    function syncDealStatuses(wrap, refreshFiltered) {
        if (!window.GQV2 || wrap.getAttribute('data-gqv2-live-deals') !== '1' || wrap.dataset.gqv2StatusPending === '1') return;
        var cards = Array.prototype.slice.call(wrap.querySelectorAll('[data-gqv2-filter-grid] :is(.gqv2-card--deals,.gqv2-card--events)[data-gqv2-post-id]'));
        if (!cards.length && wrap.getAttribute('data-gqv2-detailed') !== '1' && !wrap.querySelector('[data-gqv2-quick-group]')) return;
        wrap.dataset.gqv2StatusPending = '1';
        var data = new URLSearchParams();
        data.append('action', 'gqv2_deal_status');
        data.append('_ts', String(Date.now()));
        data.append('attributes', wrap.getAttribute('data-gqv2-attributes') || '{}');
        cards.slice(0, 50).forEach(function (card) { data.append('ids[]', card.getAttribute('data-gqv2-post-id')); });
        fetch(window.GQV2.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Cache-Control': 'no-cache' },
            body: data.toString()
        }).then(function (response) { return response.json(); }).then(function (payload) {
            if (!payload || !payload.success) return;
            var changed = false;
            var items = payload.data.items || {};
            cards.forEach(function (card) {
                var id = card.getAttribute('data-gqv2-post-id');
                if (items[id]) changed = applyDealState(card, items[id]) || changed;
            });
            window.clearTimeout(wrap._gqv2StatusTimer);
            var serverTime = parseInt(payload.data.serverTime || '0', 10);
            var nextCheck = parseInt(payload.data.nextCheck || '0', 10);
            var delay = serverTime && nextCheck ? Math.max(2000, Math.min(300000, (nextCheck - serverTime + 2) * 1000)) : 300000;
            wrap._gqv2StatusTimer = window.setTimeout(function () { syncDealStatuses(wrap, true); }, delay);
            var expired = cards.some(function (card) { return ['expired', 'removed'].indexOf(card.getAttribute('data-gqv2-live-status')) !== -1; });
            if (changed && expired) {
                refreshFromServer(wrap, 1, { forceFresh: true, silent: true });
            } else if (wrap.getAttribute('data-gqv2-detailed') === '1' || wrap.querySelector('[data-gqv2-quick-group]')) {
                var active = wrap.dataset.gqv2ActiveFilter || 'all';
                var quickActive = Object.keys(getQuickSelections(wrap)).some(function (key) { return getQuickSelections(wrap)[key] !== 'all'; });
                if (changed && (active !== 'all' || quickActive || hasDetailedFilters(wrap))) refreshFromServer(wrap, 1, { forceFresh: true, silent: true });
            }
        }).catch(function () {
            window.clearTimeout(wrap._gqv2StatusTimer);
            wrap._gqv2StatusTimer = window.setTimeout(function () { syncDealStatuses(wrap, true); }, 300000);
        }).finally(function () {
            wrap.dataset.gqv2StatusPending = '0';
        });
    }

    function setupDealStatusSync(wrap) {
        if (wrap.getAttribute('data-gqv2-live-deals') !== '1') return;
        if (wrap.dataset.gqv2StatusReady !== '1') {
            wrap.dataset.gqv2StatusReady = '1';
            document.addEventListener('visibilitychange', function () {
                if (!document.hidden) syncDealStatuses(wrap, true);
            });
            window.addEventListener('focus', function () { syncDealStatuses(wrap, true); }, { passive: true });
        }
        syncDealStatuses(wrap, false);
    }

    function setupContentStrip(root) {
        if (root.dataset.gqv2StripReady === '1') { if (typeof root._gqv2StripUpdate === 'function') root._gqv2StripUpdate(); return; }
        root.dataset.gqv2StripReady = '1';
        var track = root.querySelector('[data-gqv2-strip-track]');
        var prev = root.querySelector('[data-gqv2-strip-prev]');
        var next = root.querySelector('[data-gqv2-strip-next]');
        var dotsHolder = root.querySelector('[data-gqv2-strip-dots]');
        if (!track) return;
        function cards() { return Array.prototype.slice.call(track.querySelectorAll('.gqv2-card')); }
        function stepWidth() { var list = cards(); return list.length > 1 ? Math.max(1, list[1].offsetLeft - list[0].offsetLeft) : Math.max(1, track.clientWidth * .85); }
        function update() {
            var max = Math.max(0, track.scrollWidth - track.clientWidth - 2);
            if (prev) prev.disabled = track.scrollLeft <= 2;
            if (next) next.disabled = track.scrollLeft >= max;
            if (dotsHolder) {
                var count = Math.max(1, Math.ceil(cards().length / Math.max(1, parseInt(root.getAttribute('data-gqv2-strip-visible') || '3', 10))));
                if (dotsHolder.children.length !== count) {
                    dotsHolder.innerHTML = '';
                    for (var i = 0; i < count; i++) { var dot = document.createElement('button'); dot.type = 'button'; dot.setAttribute('aria-label', 'Go to group ' + (i + 1)); (function (index) { dot.addEventListener('click', function () { track.scrollTo({ left: index * track.clientWidth, behavior: 'smooth' }); }); })(i); dotsHolder.appendChild(dot); }
                }
                var active = Math.min(count - 1, Math.round(track.scrollLeft / Math.max(1, track.clientWidth)));
                Array.prototype.slice.call(dotsHolder.children).forEach(function (dot, i) { dot.classList.toggle('is-active', i === active); });
            }
        }
        root._gqv2StripUpdate = update;
        if (prev) prev.addEventListener('click', function () { track.scrollBy({ left: -stepWidth(), behavior: 'smooth' }); });
        if (next) next.addEventListener('click', function () { track.scrollBy({ left: stepWidth(), behavior: 'smooth' }); });
        track.addEventListener('scroll', function () { window.requestAnimationFrame(update); }, { passive: true });
        window.addEventListener('resize', update, { passive: true });
        update();
        var autoplay = parseInt(root.getAttribute('data-gqv2-strip-autoplay') || '0', 10);
        if (autoplay > 0) {
            var timer = window.setInterval(function () { var max = Math.max(0, track.scrollWidth - track.clientWidth - 2); if (track.scrollLeft >= max) track.scrollTo({ left: 0, behavior: 'smooth' }); else track.scrollBy({ left: stepWidth(), behavior: 'smooth' }); }, autoplay);
            root.addEventListener('mouseenter', function () { window.clearInterval(timer); }, { once: true });
        }
    }

    function setupContentStrips(scope) {
        var root = scope || document;
        if (root.matches && root.matches('[data-gqv2-content-strip]')) setupContentStrip(root);
        root.querySelectorAll && root.querySelectorAll('[data-gqv2-content-strip]').forEach(setupContentStrip);
    }

    function setupLightbox(scope) {
        var links = Array.prototype.slice.call((scope || document).querySelectorAll('[data-gqv2-lightbox]'));
        if (!links.length) return;

        var box = document.querySelector('[data-gqv2-lightbox-modal]');
        if (!box) {
            box = document.createElement('div');
            box.className = 'gqv2-lightbox';
            box.setAttribute('data-gqv2-lightbox-modal', '');
            box.setAttribute('role', 'dialog');
            box.setAttribute('aria-modal', 'true');
            box.setAttribute('aria-label', 'Image lightbox');
            box.innerHTML = '<button type="button" class="gqv2-lightbox__close" aria-label="Close image">×</button>' +
                '<button type="button" class="gqv2-lightbox__prev" aria-label="Previous image">‹</button>' +
                '<figure class="gqv2-lightbox__figure"><img class="gqv2-lightbox__image" alt=""><figcaption class="gqv2-lightbox__caption"></figcaption></figure>' +
                '<button type="button" class="gqv2-lightbox__next" aria-label="Next image">›</button>';
            document.body.appendChild(box);
        }

        var image = box.querySelector('.gqv2-lightbox__image');
        var caption = box.querySelector('.gqv2-lightbox__caption');
        var close = box.querySelector('.gqv2-lightbox__close');
        var prev = box.querySelector('.gqv2-lightbox__prev');
        var next = box.querySelector('.gqv2-lightbox__next');
        var group = [];
        var index = 0;
        var lastFocus = null;

        function render() {
            var link = group[index];
            if (!link) return;
            image.src = link.href;
            image.alt = link.getAttribute('data-gqv2-lightbox-title') || '';
            caption.textContent = link.getAttribute('data-gqv2-lightbox-title') || '';
            var multiple = group.length > 1;
            prev.hidden = !multiple;
            next.hidden = !multiple;
        }
        function open(link) {
            var key = link.getAttribute('data-gqv2-lightbox-group') || '';
            group = Array.prototype.slice.call(document.querySelectorAll('[data-gqv2-lightbox-group="' + CSS.escape(key) + '"]'));
            index = Math.max(0, group.indexOf(link));
            lastFocus = document.activeElement;
            render();
            box.classList.add('is-open');
            document.body.classList.add('gqv2-lightbox-open');
            close.focus();
        }
        function hide() {
            box.classList.remove('is-open');
            document.body.classList.remove('gqv2-lightbox-open');
            image.removeAttribute('src');
            if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
        }
        function move(step) {
            if (!group.length) return;
            index = (index + step + group.length) % group.length;
            render();
        }

        links.forEach(function (link) {
            if (link.dataset.gqv2LightboxReady === '1') return;
            link.dataset.gqv2LightboxReady = '1';
            link.addEventListener('click', function (event) {
                event.preventDefault();
                open(link);
            });
        });
        if (box.dataset.gqv2LightboxReady !== '1') {
            box.dataset.gqv2LightboxReady = '1';
            close.addEventListener('click', hide);
            prev.addEventListener('click', function () { move(-1); });
            next.addEventListener('click', function () { move(1); });
            box.addEventListener('click', function (event) { if (event.target === box) hide(); });
            document.addEventListener('keydown', function (event) {
                if (!box.classList.contains('is-open')) return;
                if (event.key === 'Escape') hide();
                if (event.key === 'ArrowLeft') move(-1);
                if (event.key === 'ArrowRight') move(1);
            });
        }
    }

    function init(scope) {
        var root = scope || document;
        root.querySelectorAll('[data-gqv2-carousel]').forEach(setupCarousel);
        root.querySelectorAll('[data-gqv2-filters]').forEach(setupFilters);
        root.querySelectorAll('[data-gqv2-load-more]').forEach(setupLoadMore);
        root.querySelectorAll('[data-gqv2-multi-filters]').forEach(function (bar) { setupMultiFilters(bar.closest('.gqv2-wrap') || bar); });
        root.querySelectorAll('[data-gqv2-detailed-filters]').forEach(function (bar) { setupDetailedFilters(bar.closest('.gqv2-wrap') || bar); });
        root.querySelectorAll('[data-gqv2-deal-filters]').forEach(function (bar) { setupDealFilters(bar.closest('.gqv2-wrap') || bar); });
        setupContentStrips(root);
        setupLightbox(root);
        root.querySelectorAll('.gqv2-wrap').forEach(function (wrap) {
			if (!wrap.dataset.gqv2State) {
				var initialEmpty = wrap.querySelector('[data-gqv2-filter-empty].is-visible');
				var loadMore = wrap.querySelector('[data-gqv2-load-more]');
				wrap.dataset.gqv2State = initialEmpty ? 'initial-empty' : (loadMore && !loadMore.hidden ? 'more-results-available' : (wrap.classList.contains('gqv2-preset-home') ? 'homepage-cap-reached' : 'idle'));
			}
			wrap.classList.add('gqv2-is-ready'); setupDealStatusSync(wrap);
		});
        if (root.classList && root.classList.contains('gqv2-wrap')) { root.classList.add('gqv2-is-ready'); setupDealStatusSync(root); }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { init(document); });
    } else {
        init(document);
    }

    if ('MutationObserver' in window) {
        new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) init(node);
                });
            });
        }).observe(document.documentElement, { childList: true, subtree: true });
    }
})();
