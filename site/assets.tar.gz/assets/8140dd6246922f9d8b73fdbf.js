jQuery(function($){
	
	var canBeLoaded = true, // this param allows to initiate the AJAX call only if necessary
	 data = {
		'action': 'load_deals',
	};
		
	var FeatTumbsresize = function() { 
		$('.media-box.deals .featured-thumbs .slide').attr('style', 'max-height:' + ($(".stores-list .eqheight").height() - 30) + 'px !important');
	}	
	var loadDeals = function() { 
		$.ajax({
			url : store_deals_params.ajaxUrl,
			data:data,
			type:'POST',
			beforeSend: function( xhr ){
				canBeLoaded = false; 
				if($('.ajax-load-more').length == 0) {
					$('<div class="media-boxes-load-more ajax-load-more media-boxes-load-more-button"></div>').insertAfter($('#stores-grid'));
				}
				$('.ajax-load-more').html('Loading Deals...');
				$('.ajax-load-more').removeClass('media-boxes-load-more media-boxes-no-more-entries');
				$('.ajax-load-more').addClass('media-boxes-loading');
			},
			success:function(data){
				if( data ) {
					$('.deals-filter').addClass('deals-shown');
					
					$('#stores-grid').mediaBoxes( 'insert', data , function(){
						if ($(window).width() > 992){
							FeatTumbsresize();
							$('.media-box.deals .read-more_btn').addClass('stick_btm');
							$('.media-box.deals .media-box-image div[data-width][data-height]').height($(".stores-list .eqheight").height() - 30);
						} 
						
						$('#stores-grid').off('layoutComplete.galleriaStoreDeals').on('layoutComplete.galleriaStoreDeals',
						  function() {
							/*console.log( 'Isotope layout completed on ' +
							  laidOutItems.length + ' items' );*/
		
								if (window.GalleriaSlickControls) {
									window.GalleriaSlickControls.initMedia(this);
								}
						});

						if (window.GalleriaSlickControls) {
							window.GalleriaSlickControls.initMedia($('#stores-grid'));
						}
						
						
					}); 
					$('.ajax-load-more').html('No More Entries');
					$('.ajax-load-more').removeClass('media-boxes-loading');
					$('.ajax-load-more').addClass('media-boxes-no-more-entries');
					
					canBeLoaded = true; // the ajax is completed, now we can run it again
				} else {
					canBeLoaded = false; 
					$('.ajax-load-more').html('No More Entries');
					$('.ajax-load-more').removeClass('media-boxes-loading');
					$('.ajax-load-more').addClass('media-boxes-no-more-entries');
				}
			}
		});
	}
		
		
	$(window).resize(function() {
		FeatTumbsresize();
	});
	
	if(location.href.indexOf("#(stores-grid|has-deals") != -1) {
		if( canBeLoaded == true ){
			loadDeals();
		}
	}
				
	$('.deals-filter').click(function() {
    	if($(this).prop("checked") == true){
			if(!$(this).hasClass('deals-shown')) {
				if( canBeLoaded == true ){
					loadDeals();
				}
			} else {
				$('.media-box.deals .media-box-image div[data-width][data-height]').height($(".stores-list .eqheight").height() - 30);
				$('.media-box.deals').show();
			}
    	} else {
    		$('.media-box.deals').hide();
    	}
    });
    
    $(window).resize(function() {
		$('.media-box.deals .media-box-image div[data-width][data-height]').height($(".stores-list .eqheight").height() - 30);
	});
});
