(function () {
	'use strict';

	function init(root) {
		if (root.dataset.ghsaReady === '1') return;
		root.dataset.ghsaReady = '1';

		var slides = Array.prototype.slice.call(root.querySelectorAll('[data-ghsa-slide]'));
		if (!slides.length) return;

		var viewport = root.querySelector('[data-ghsa-viewport]');
		var previous = root.querySelector('[data-ghsa-prev]');
		var next = root.querySelector('[data-ghsa-next]');
		var thumbs = Array.prototype.slice.call(root.querySelectorAll('[data-ghsa-goto]'));
		var currentText = root.querySelector('[data-ghsa-current]');
		var current = 0;
		var timer = null;
		var hoverPaused = false;
		var focusPaused = false;
		var visible = true;
		var gesture = null;
		var suppressClick = false;
		var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		var autoplay = root.dataset.autoplay === '1' && !reducedMotion;
		var interval = Math.max(3000, parseInt(root.dataset.interval || '7000', 10));

		function normalise(index) {
			if (index < 0) return slides.length - 1;
			if (index >= slides.length) return 0;
			return index;
		}

		function setHeight(slide) {
			if (!viewport || !slide) return;
			var width = parseInt(slide.dataset.width || '1500', 10);
			var height = parseInt(slide.dataset.height || '550', 10);
			if (!width || !height) return;
			viewport.style.height = Math.round(viewport.clientWidth * height / width) + 'px';
		}

		function stopTimer() {
			if (timer) window.clearTimeout(timer);
			timer = null;
		}

		function startTimer() {
			stopTimer();
			if (!autoplay || hoverPaused || focusPaused || !visible || document.hidden || slides.length < 2) return;
			timer = window.setTimeout(function () { show(current + 1); }, interval);
		}

		function show(index) {
			current = normalise(index);
			slides.forEach(function (slide, slideIndex) {
				var active = slideIndex === current;
				slide.classList.toggle('is-active', active);
				slide.setAttribute('aria-hidden', active ? 'false' : 'true');
				slide.inert = !active;
			});
			thumbs.forEach(function (thumb, thumbIndex) {
				var active = thumbIndex === current;
				thumb.classList.toggle('is-active', active);
				if (active) thumb.setAttribute('aria-current', 'true');
				else thumb.removeAttribute('aria-current');
			});
			if (currentText) currentText.textContent = String(current + 1);
			setHeight(slides[current]);
			startTimer();
		}

		if (previous) previous.addEventListener('click', function () { show(current - 1); });
		if (next) next.addEventListener('click', function () { show(current + 1); });
		thumbs.forEach(function (thumb) {
			thumb.addEventListener('click', function () { show(parseInt(thumb.dataset.ghsaGoto, 10)); });
		});

		root.addEventListener('keydown', function (event) {
			if (event.key === 'ArrowLeft') { event.preventDefault(); show(current - 1); }
			if (event.key === 'ArrowRight') { event.preventDefault(); show(current + 1); }
		});

		root.addEventListener('mouseenter', function () { hoverPaused = true; stopTimer(); });
		root.addEventListener('mouseleave', function () { hoverPaused = false; startTimer(); });
		root.addEventListener('focusin', function () { focusPaused = true; stopTimer(); });
		root.addEventListener('focusout', function (event) {
			if (!root.contains(event.relatedTarget)) { focusPaused = false; startTimer(); }
		});

		root.addEventListener('pointerdown', function (event) {
			if (event.pointerType === 'mouse' && event.button !== 0) return;
			gesture = { x: event.clientX, y: event.clientY, time: Date.now() };
		});
		root.addEventListener('pointerup', function (event) {
			if (!gesture) return;
			var dx = event.clientX - gesture.x;
			var dy = event.clientY - gesture.y;
			var elapsed = Date.now() - gesture.time;
			gesture = null;
			if (elapsed < 900 && Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.25) {
				event.preventDefault();
				suppressClick = true;
				show(dx > 0 ? current - 1 : current + 1);
				window.setTimeout(function () { suppressClick = false; }, 350);
			}
		});
		root.addEventListener('pointercancel', function () { gesture = null; });
		root.addEventListener('click', function (event) {
			if (suppressClick) {
				event.preventDefault();
				event.stopPropagation();
			}
		}, true);

		document.addEventListener('visibilitychange', startTimer);
		window.addEventListener('resize', function () { setHeight(slides[current]); });
		if ('ResizeObserver' in window && viewport) {
			new ResizeObserver(function () { setHeight(slides[current]); }).observe(viewport);
		}

		if ('IntersectionObserver' in window) {
			var observer = new IntersectionObserver(function (entries) {
				visible = entries[0] ? entries[0].isIntersecting : true;
				startTimer();
			}, { threshold: 0.15 });
			observer.observe(root);
		}

		slides.forEach(function (slide) {
			var image = slide.querySelector('img');
			if (image && !image.complete) image.addEventListener('load', function () { if (slide.classList.contains('is-active')) setHeight(slide); }, { once: true });
		});

		show(0);
	}

	function boot() {
		document.querySelectorAll('[data-ghsa-slider]').forEach(init);
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
	else boot();
})();
