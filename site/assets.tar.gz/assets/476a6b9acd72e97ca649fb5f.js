var $ = jQuery.noConflict();

jQuery(document).ready(function($) {
	$('.slick-slider').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
		// Pause all videos inside the slider
		$(this).find('video').each(function() {
			this.pause(); // Pause the video
		});
	});
	
	$('.blog-content .main-media').css({'visibility':'visible'});
	  	
	$(".store-hrs").each(function() {
	  $(this).closest(".mapplic-tooltip-title").append(this);
	});
    
    $(function () {
	  $('[data-toggle="tooltip"]').tooltip({
	  	container: 'body'
	  })
	});

	$(".scroll-text").each(function() {
		$(this).mouseover(function() {
			$(this).removeClass("ellipsis");
			var maxscroll = $(this).width();
			var speed = maxscroll * 15;
			$(this).animate({
				scrollLeft: maxscroll
			}, speed, "linear");
			//console.log(maxscroll);
		});
	});
	
	$(".scroll-text").each(function() {
		$(this).mouseout(function() {
			$(this).stop();
			$(this).addClass("ellipsis");
			$(this).animate({
				scrollLeft: 0
			}, 'slow');
		}); 
	}); 
	
	$(".cms-popup-search-form #cms-show-search-form").on('click', function() {
		$(".cms-popup-search-form-content").toggle('slow');
	});

	$(".icon_cart_wrap").on('click', function(e) {
		$(".shopping_cart_dropdown").slideToggle('slow');
		e.stopPropagation();
	});

	$(".icon_search_wrap").on('click', function(e) {
		$(".widget_searchform_content").slideToggle('slow');
		e.stopPropagation();
	});

	$(document).on('click', function(e) {
		if ($(".shopping_cart_dropdown").is(":visible")) {
			$(".shopping_cart_dropdown").slideToggle("slow");
		}
		if ($(".widget_searchform_content").is(":visible") && e.target.parentElement.className != "searchform") {
			$(".widget_searchform_content").slideToggle('slow');
		}
	});
	
	function shuffle(array) {
	  let currentIndex = array.length;

	  // While there remain elements to shuffle...
	  while (currentIndex != 0) {

		// Pick a remaining element...
		let randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex--;

		// And swap it with the current element.
		[array[currentIndex], array[randomIndex]] = [
		  array[randomIndex], array[currentIndex]];
	  }
	}
	
	var colors = ['red', 'yellow', 'blue', 'green', 'purple', 'indigo'];

	$('.events .kids .date-list').each(function() {
		// Shuffle the colors anew for each event's date list
		var shuffledColors = [...colors]; // Create a copy of the original colors array
		shuffle(shuffledColors); // Shuffle the copied array

		console.log(shuffledColors);

		$(this).find('li').each(function() {
			var index = $(this).index();
			if (index < shuffledColors.length) {
				$(this).addClass(shuffledColors[index]);
			} else {
				// Repeat colors if there are more dates than colors
				$(this).addClass(shuffledColors[index % shuffledColors.length]);
			}
		});
	});

	/*var elems = $(".blog-post"),
	wrapper = $('<div class="row blog-row" />');
	for (var i = 0;i < elems.length;i+=2){
		elems.filter(':eq('+i+'),:eq('+(i+1)+')').wrapAll(wrapper);
	};
	
	if ($('.blog-row').find('.blog-post').length == 1 ) {
		$('.blog-post').addClass('col-md-offset-3');
	}*/

    $('.partner-carousel').slick({
	  slidesToShow: 3,
	  slidesToScroll: 3
	});

    var eqPostBox = function() {
		if ($(window).width() > 992){
			$('.blog-row').each(function() {
				$( this ).find('.post-box').addClass('eq-height').equalHeights();
				$( this ).find('.eq-height .text-block').addClass('centered-block');
			});
		}
	}
	
	
	
	var menuOverFlow = function() {
		var isNotBound = function(parent, child) {
		  var parentBox = parent[0].getBoundingClientRect();
		  var childBox = child[0].getBoundingClientRect();

		  if (	childBox.top < parentBox.top || 
				childBox.right > parentBox.right ||
				childBox.bottom > parentBox.bottom || 
				childBox.left < parentBox.left) {
					return true;
		  }
  
		  return false;
  
		}
		
		if ($(window).width() > 992){
			
			var navLiWidth = 0;

			$('.nav-menu.menu-main-menu ul li').each(function() {
			 navLiWidth += $(this).outerWidth();
			});
			
			//var leftShift = navLiWidth - $(".nav-menu.menu-main-menu").outerWidth(true);
			var leftShift = $(".nav-menu.menu-main-menu")[0].scrollWidth - $(".nav-menu.menu-main-menu").outerWidth(true);
				
			console.log('scroll ' + $(".nav-menu.menu-main-menu")[0].scrollWidth);
			console.log('width ' + $(".nav-menu.menu-main-menu").outerWidth(true));
			console.log('Combo li Width ' + navLiWidth);
			
			var showHidden = function () {
				$(".nav-menu.menu-main-menu").stop().animate({ left: '-' + leftShift + 'px' }, 500 );
				$(this).find(".fa").removeClass("fa-plus-square-o").addClass("fa-minus-square-o");
				$(this).addClass("menu-noverflow");
			}
			
			$(".menu-overflow").not("menu-noverflow").mouseover(showHidden);
			
			$(document.body).on('click', '.menu-overflow' ,function(){
				showHidden();
			});
			
			$(document.body).on('click', '.menu-noverflow' ,function(){
				$(".nav-menu.menu-main-menu").stop().animate({ left: '0' }, 500 );
				$(".menu-overflow .fa").removeClass("fa-minus-square-o").addClass("fa-plus-square-o");
				$(this).removeClass("menu-noverflow");
			});
			
			$('.main-navigation > div ul:first-child > li:last-child').each(function() {
				if(isNotBound($(this).parent(), $(this)) == true && leftShift > 50) {
					$('.menu-overflow').removeClass('hidden');
				}
			
				if(isNotBound($(this).parent(), $(this)) != true && leftShift < 50 ) {
					$('.menu-overflow').addClass('hidden');
				}
			});
	 	}
	}
	
	menuOverFlow();
	
	eqPostBox();
	  
	$(window).resize(function() {
		eqPostBox();
		menuOverFlow();
	});
	
	/* pretty photo */
	$("a[data-rel^='prettyPhoto']").prettyPhoto();
	$("a.prettyphoto").prettyPhoto();
	$("a[data-rel^='prettyPhoto']").prettyPhoto({ hook: "data-rel", social_tools: !1, theme: "pp_default", horizontal_padding: 20, opacity: .8, deeplinking: !1 });

	//special carousel
	$(".cms-special-carousel").each(function() {
		var slider = $(this).miSlider({
			slidesOnStage: false,
			pause: 3000000,
			speed: 700,
			navButtons: true,
			navList: false,
			navButtonsShow: false,
			slideWidth: 400,
			slidePosition: 'center',
			stageHeight: false,
			slideScaling: 141
		});
	});
	
	function initCountedSlick($slider, options) {
		$slider.each(function() {
			var $currentSlider = $(this);
			var slideCount = $currentSlider.children().length;
			var slickOptions = $.extend({}, options, {
				dots: slideCount > 1 && options.dots !== false,
				arrows: slideCount > 1 && options.arrows !== false
			});

			$currentSlider.addClass('galleria-counted-slider');
			if (window.GalleriaSlickControls) {
				window.GalleriaSlickControls.prepare($currentSlider, {
					counterThreshold: 5,
					alwaysCounter: false
				});
				if (window.GalleriaSlickControls.reducedMotion()) {
					slickOptions.autoplay = false;
					slickOptions.speed = 0;
				}
			}

			$currentSlider.slick(slickOptions);
		});
	}

	$(".cms-carousel").each(function() {
		var $carousel = $(this);
		var hasMultipleSlides = $carousel.children().length > 1;
		$carousel.slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			infinite: false,
			arrows: hasMultipleSlides,
			dots: hasMultipleSlides,
			autoplay: hasMultipleSlides,
			autoplaySpeed: 5000,
			pauseOnHover: true,
			speed: 1000,
			adaptiveHeight: true,
			prevArrow: '<span class="icon-arrow-left"></span>',
			nextArrow: '<span class="icon-arrow-right"></span>'
		});
	});

$('.facilities .carousel-item .overlay').mouseenter(function() {
	$(this).parent().find('img').addClass('hover');
})
$('.facilities .carousel-item .overlay').mouseleave(function() {
	$(this).parent().find('img').removeClass('hover');
})
	
	if ( $('.facilities').length > 0 ) {
		$('.facilities').slick({
			slidesToShow: 4,
			slidesToScroll: 1,
			infinite: true,
			autoplay: true,
			autoplaySpeed: 5000,
			pauseOnHover: true,
			speed: 1000,
			dots: false,
			prevArrow: '<span class="icon-arrow-left"></span>',
			nextArrow: '<span class="icon-arrow-right"></span>',
			responsive: [
				{ breakpoint: 1000, settings: { slidesToShow: 3 } },
				{ breakpoint: 600, settings: { slidesToShow: 2, arrows: false } }
			]
		});
	}
    
    if ( $('#store-header').length > 0 ) {
		initCountedSlick($('#store-header'), {
            slidesToShow: 1,
            infinite: false,
            autoplay: true,
  			autoplaySpeed: 5000,
            dots: true,
            adaptiveHeight: false,
            //navText: ["<span class=\"icon-arrow-left\"></span>", "<span class=\"icon-arrow-right\"></span>"]
            prevArrow: '<span class=\"icon-arrow-left\"></span>',
			nextArrow: '<span class=\"icon-arrow-right\"></span>'
        });            
    }
    if ( $('.featured-events').length > 0 ) {
		$('.featured-events').slick({
		  adaptiveHeight: true,
		  infinite: false,
		  prevArrow: "<span class=\"icon-arrow-left\"></span>",
		  nextArrow: "<span class=\"icon-arrow-right\"></span>"
		});
	}
    
	if ( $('.logo-carousel').length > 0 ) {
		$('.logo-carousel').each(function() {
			var $carousel = $(this);
			var hasMultipleSlides = $carousel.children().length > 1;
			$carousel.slick({
				slidesToShow: 3,
				slidesToScroll: 1,
				infinite: hasMultipleSlides,
				autoplay: hasMultipleSlides,
				autoplaySpeed: 5000,
				pauseOnHover: true,
				speed: 1000,
				arrows: hasMultipleSlides,
				dots: hasMultipleSlides,
				prevArrow: '<span class="icon-arrow-left"></span>',
				nextArrow: '<span class="icon-arrow-right"></span>',
				responsive: [
					{ breakpoint: 1000, settings: { slidesToShow: 2 } },
					{ breakpoint: 600, settings: { slidesToShow: 1 } }
				]
			});
		});
	}
    
    if ( $('.store-featured').length > 0 ) {
		if ($(this).hasClass("portfolio-caption")) {
    		var prevArrow = $('.prev-arrow');
             var nextArrow = $('.next-arrow');
		} else {
			var prevArrow = '<span class=\"icon-arrow-left\"></span>';
             var nextArrow = '<span class=\"icon-arrow-right\"></span>';
		}
		initCountedSlick($('.store-featured'), {
			  slidesToShow: 1,
			  slidesToScroll: 1,
			  autoplay: true,
			  dots: true,
			  infinite: false,
			  speed: 1000,
			  adaptiveHeight: true,
			  arrows: true,
			 prevArrow: prevArrow,
			 nextArrow: nextArrow
		});
	}

	if ( $('.galleria-promo-slider').length > 0 ) {
		initCountedSlick($('.galleria-promo-slider'), {
			slidesToShow: 1,
			slidesToScroll: 1,
			infinite: true,
			autoplay: true,
			autoplaySpeed: 5000,
			pauseOnHover: true,
			speed: 900,
			dots: true,
			adaptiveHeight: false,
			prevArrow: '<span class="icon-arrow-left"></span>',
			nextArrow: '<span class="icon-arrow-right"></span>'
		});
	}
	
	//ProgressBar
	$('.group-progressbar').each(function() {
		var $this = $(this);
		var waypoint = $this.waypoint({
			handler: function(direction) {
				$this.find('.progressbar').progressbar({ display_text: 'center' });
			},
			offset: "80%"
		});
	});

	//Counter
	if ($('.cms-counter-wraper').length > 0) {
		$('.cms-counter-wraper').each(function(index) {
			var $this = $(this);
			var waypoint = $this.waypoint({
				handler: function(direction) {
					$this.find('.cms-counter-digit:not(.counted)').countTo().addClass('counted');
				},
				offset: "90%"
			});
		});
	}

	if($(".copy-text").length > 0) {
	var copyText = $(".copy-text");

		copyText.find("button").click(function(){
			let input = copyText.find("input.text");
			input.select();
			document.execCommand("copy");
			copyText.addClass("active");
			window.getSelection().removeAllRanges();
			setTimeout(function () {
				copyText.removeClass("active");
			}, 2500);
		});
	}

	//Scrolling Animation
	if ($('.wow').length > 0) Animation();

	//Equal Heights
	if ($('.equalheight').length > 0) $('.equalheight').each(function() {
		  $( this ).equalHeights();
		});
	if ($('.portfolio-grid-same-height').length > 0) $('.portfolio-grid-same-height').equalHeights();
	if ($('.events .event-details').length > 0) $('.events .event-details').each(function() {
		  $( this ).find('.details').equalHeights();
		});
	
	if ($('.deals.post-box').length > 0) $('.deals.post-box').each(function() {
		  $( this ).find('.post-col').equalHeights();
		});	
		
	if ($('.eqHeight').length > 0) $('.eqHeight').each(function() {
	  $( this ).find('.sameheight').equalHeights();
	});

		
	if ($('#googleMap').length > 0) {
		var myCenter = new google.maps.LatLng(38.581572, -121.494400);
		var myMaker = new google.maps.LatLng(38.581572, -121.494400);

		function initialize() {
			var styles = [{ "featureType": "all", "elementType": "labels.text.fill", "stylers": [{ "saturation": 36 }, { "color": "#000000" }, { "lightness": 40 }] }, { "featureType": "all", "elementType": "labels.text.stroke", "stylers": [{ "visibility": "on" }, { "color": "#000000" }, { "lightness": 16 }] }, { "featureType": "all", "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] }, { "featureType": "administrative", "elementType": "geometry.fill", "stylers": [{ "color": "#000000" }, { "lightness": 20 }] }, { "featureType": "administrative", "elementType": "geometry.stroke", "stylers": [{ "color": "#000000" }, { "lightness": 17 }, { "weight": 1.2 }] }, { "featureType": "landscape", "elementType": "geometry", "stylers": [{ "color": "#000000" }, { "lightness": 20 }] }, { "featureType": "poi", "elementType": "geometry", "stylers": [{ "color": "#000000" }, { "lightness": 21 }] }, { "featureType": "road.highway", "elementType": "geometry.fill", "stylers": [{ "color": "#000000" }, { "lightness": 17 }] }, { "featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{ "color": "#000000" }, { "lightness": 29 }, { "weight": 0.2 }] }, { "featureType": "road.arterial", "elementType": "geometry", "stylers": [{ "color": "#000000" }, { "lightness": 18 }] }, { "featureType": "road.local", "elementType": "geometry", "stylers": [{ "color": "#000000" }, { "lightness": 16 }] }, { "featureType": "transit", "elementType": "geometry", "stylers": [{ "color": "#000000" }, { "lightness": 19 }] }, { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#000000" }, { "lightness": 17 }] }];
			var styledMap = new google.maps.StyledMapType(styles, { name: "Styled Map" });
			var mapProp = {
				center: myCenter,
				zoom: 16,
				scrollwheel: false,
				mapTypeControlOptions: {
					mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
				}
			};
			var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
			map.mapTypes.set('map_style', styledMap);
			map.setMapTypeId('map_style');
			var marker = new google.maps.Marker({
				position: myMaker,
				icon: "./images/map-marker.png"
			});
			marker.setMap(map);
		}
		google.maps.event.addDomListener(window, 'load', initialize);
	}

	//Scroll down
	$(".scroll-down").on("click", function() {
		$("html, body").stop().animate({
			scrollTop: $("#about").offset().top
		}, 700, "swing");
	});

	//Revolution Slider
	if ($("#rev_slider_1").length > 0) {
		RevSliderInit();
	}

	if ($("#rev_slider_2").length > 0) {
		RevFullScreenSliderInit();
	}

	if ($("#rev_slider_3").length > 0) {
		RevSmallSliderInit();
	}

	$(window).scroll(function() {
		var _scroll = $(window).scrollTop();
		var offset_top = 0;

		offset_top = $('#cms-masthead').height();
		if (_scroll >= offset_top) {
			if ($("#cms-header").hasClass("active-sticky")) {
				$("#cms-header").addClass("header-fixed");
				$("#cms-header .main-navigation").addClass("pull-right");
			}
			$(".secondary-menu").addClass("header-fixed");
		}
		
		if (_scroll == 0) {
			if ($("#cms-header").hasClass("active-sticky")) {
				$("#cms-header").removeClass("header-fixed");
				$("#cms-header .main-navigation").removeClass("pull-right");
			}
			$(".secondary-menu").removeClass("header-fixed");
		}

		if ($(this).scrollTop() > 500) {
			$('.go-to-top').addClass('on');
		} else {
			$('.go-to-top').removeClass('on');
		}
	});

	/** Initialise the responsive menu without waiting for every image to load. */
	cms_mobile_menu($(window).width());

	$(window).resize(function(event, ui) {
		/** current window width */
		var window_width = $(event.target).width();

		/* check mobile menu */
		cms_mobile_menu(window_width);
	});

	$('body').on('click', '.go-to-top', function() {
		$("html, body").animate({
			scrollTop: 0
		}, 800);
		return false;
	});

	//Fullscreen scrolling
	if ($('.cms-grid-fullpage').length > 0) {
		$('#cms-fullpage-next').on('click', function() {
			$.fn.fullpage.moveSectionDown();
		});


		$('#cms-fullpage-prev').on('click', function() {
			$.fn.fullpage.moveSectionUp();
		});
		var anchors = [];

		$('.cms-grid-fullpage .cms-grid-item-wrapper').each(function(i) {
			if ($(this).attr('id') != undefined) {
				anchors.push($(this).attr('id'));
			}
		})

		$('.cms-grid-fullpage').fullpage({
			sectionSelector: '.cms-grid-item-wrapper',
			autoScrolling: true,
			navigation: false,
			fixedElements: '#cms-fullpage-next, #cms-fullpage-prev'
		});
	}

	//Fitvids
	if ($(".full-screen").length > 0) {
		$(".full-screen").fitVids();
	}

	//Mobile Menu
	$('#cms-menu-mobile').on('click', function() {
		var navigation = $(this).parent().parent().parent().find('#cms-header-navigation');
		if (!navigation.hasClass('collapse')) {
			navigation.addClass('collapse');
		} else {
			navigation.removeClass('collapse');
		}
	});

	if (typeof baguetteBox !== 'undefined' && $('.store-header').length > 0) {
		baguetteBox.run('.store-header', {
			ignoreClass: 'no-lightbox'
		});
	}



/* No more entries */	
 
/*$('body').onemenu({
	openstyle: 'overlay',
	closeoutside: false,
	ctrlalign: 'center',
	animEffect: 'fade'
});
*/
	/* No more entries */
});


/* check mobile screen. */
function cms_mobile_menu(window_width) {
	var menu = jQuery('#cms-header-navigation');

	/* active mobile menu. */
	switch (true) {
		case (window_width >= 993):
			menu.removeClass('phones-nav');
			menu.removeClass('tablets-nav');
			menu.removeClass('collapse');
			break;
		case (window_width <= 992 && window_width >= 768):
			menu.removeClass('phones-nav').addClass('tablets-nav');
			/* */
			cms_mobile_menu_group(menu);
			cms_mobile_social_menu_btn(jQuery('.menu-btn'));
			break;
		case (window_width <= 768):
			menu.removeClass('tablets-nav').addClass('phones-nav');
			break;
		default:
			menu.removeClass('mobile-nav tablets-nav');
			menu.find('li').removeClass('mobile-group');
			break;
	}
}
/* group sub menu. */
function cms_mobile_menu_group(nav) {
	nav.each(function() {
		jQuery(this).find('li').each(function() {
			if (jQuery(this).find('ul:first').length > 0) {
				jQuery(this).addClass('mobile-group');
			}
		});
	});
}

/* social btn group sub menu. */
function cms_mobile_social_menu_btn(btn) {
	btn.each(function() {
		if (jQuery(this).find('ul:first').length > 0) {
			jQuery(this).addClass('mobile-group');
		}
	});
}

function Animation() {
	var wow = new WOW({
		boxClass: 'wow', // default
		animateClass: 'animated', // default
		offset: 0, // default
		mobile: true, // default
		live: true // default
	});
	wow.init();
}

$(function() {
  jQuery('.one-page a[href*=#]').on('click', function(e) {
    e.preventDefault();
    jQuery('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top - 300 }, 500, 'linear');

  });
});

function clock(){

//Save the times in variables

var today = new Date();

today.toLocaleString('en-GB', { timeZone: 'Africa/Nairobi' });

var hours = today.getHours();
var minutes = today.getMinutes();


//Set the AM or PM time

if (hours >= 12){
  meridiem = " PM";
}
else {
  meridiem = " AM";
}


//convert hours to 12 hour format and put 0 in front
if (hours>12){
	hours = hours - 12;
}
else if (hours===0){
	hours = 12;	
}

//Put 0 in front of single digit minutes and seconds

if (minutes<10){
	minutes = "0" + minutes;
}
else {
	minutes = minutes;
}


document.getElementById("clockHours").innerHTML = (hours); 
document.getElementById("clockMin").innerHTML = (minutes + meridiem);

}


setInterval('clock()', 1000);
