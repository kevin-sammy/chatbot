(function () {
	'use strict';

	var config = window.galleriaCoreStatus || {};
	var timer = null;
	var controller = null;

	function nodes() {
		return Array.prototype.slice.call(
			document.querySelectorAll('[data-id][data-opening-hours][data-closing-hours]')
		).filter(function (node) {
			return !node.hasAttribute('data-deal-from') && !node.hasAttribute('data-deal-dates');
		});
	}

	function idsFor(list) {
		return list.map(function (node) {
			return String(node.getAttribute('data-id') || '');
		}).filter(Boolean).filter(function (value, index, all) {
			return all.indexOf(value) === index;
		});
	}

	function formatTime(value) {
		if (!value) return '';
		var parts = value.split(':');
		var hour = parseInt(parts[0], 10);
		var minutes = parts[1] || '00';
		var meridiem = hour >= 12 ? 'pm' : 'am';
		hour = hour % 12 || 12;
		return hour + (minutes === '00' ? '' : ':' + minutes) + ' ' + meridiem;
	}

	function nextText(item) {
		if (!item.next_open_label || !item.next_open_hours || !item.next_open_hours.opening) return '';
		return 'Opens ' + item.next_open_label + ' at ' + formatTime(item.next_open_hours.opening);
	}

	function replaceStatusClasses(node, item) {
		var removable = [
			'store-open', 'store-closed', 'now-open', 'currently-open',
			'closed-today', 'closed-earlier', 'opens-later'
		];
		removable.forEach(function (name) { node.classList.remove(name); });

		if (item.is_open) {
			node.classList.add('store-open', 'now-open', 'currently-open');
		} else {
			node.classList.add('store-closed');
			if (item.status === 'closed_today') node.classList.add('closed-today');
			if (item.status === 'closed_earlier') node.classList.add('closed-earlier');
			if (item.status === 'opens_later') node.classList.add('opens-later');
		}

		node.setAttribute('data-galleria-status', item.status || '');
	}

	function updateText(node, item) {
		var status = node.querySelector('.store-details .open, .store-details .closed');
		var hours = node.querySelector('.store-details .hrs');
		var next = nextText(item);

		if (status) {
			status.textContent = item.is_open ? 'Open' : 'Closed';
			status.classList.toggle('open', !!item.is_open);
			status.classList.toggle('closed', !item.is_open);
		}

		if (hours) {
			if (item.is_open) {
				hours.textContent = formatTime(item.opening_time) + ' - ' + formatTime(item.closing_time);
			} else if (item.status === 'opens_later') {
				hours.textContent = 'Opens at ' + formatTime(item.opening_time);
			} else if (next) {
				hours.textContent = next;
			}
			hours.classList.toggle('open-hrs', !!item.is_open);
			hours.classList.toggle('closed-hrs', !item.is_open);
		}

		var menuStatus = node.querySelector('.mall-open, .mall-closed');
		if (menuStatus) menuStatus.textContent = item.is_open ? 'OPEN' : 'CLOSED';
	}

	function apply(node, item) {
		if (!item) return;
		node.setAttribute('data-opening-hours', item.opening_time || '');
		node.setAttribute('data-closing-hours', item.closing_time || '');
		if (nextText(item)) node.setAttribute('data-next-hours', nextText(item));
		replaceStatusClasses(node, item);
		updateText(node, item);
	}

	function nextDelay(items) {
		var now = Date.now();
		var changes = Object.keys(items).map(function (key) {
			return Date.parse(items[key].next_transition_at || '');
		}).filter(function (value) { return value > now; });
		var boundary = changes.length ? Math.min.apply(Math, changes) - now + 1500 : Infinity;
		var safety = Math.max(30, parseInt(config.refreshSeconds || 60, 10)) * 1000;
		return Math.max(5000, Math.min(boundary, safety));
	}

	function refresh() {
		var list = nodes();
		var ids = idsFor(list);
		if (!config.endpoint || !ids.length) return;

		if (controller && controller.abort) controller.abort();
		controller = window.AbortController ? new AbortController() : null;

		fetch(config.endpoint + '?ids=' + encodeURIComponent(ids.join(',')), {
			credentials: 'same-origin',
			signal: controller ? controller.signal : undefined
		}).then(function (response) {
			if (!response.ok) throw new Error('Status request failed');
			return response.json();
		}).then(function (payload) {
			var items = payload.items || {};
			list.forEach(function (node) {
				apply(node, items[String(node.getAttribute('data-id'))]);
			});
			window.clearTimeout(timer);
			timer = window.setTimeout(refresh, nextDelay(items));
		}).catch(function (error) {
			if (error && error.name === 'AbortError') return;
			window.clearTimeout(timer);
			timer = window.setTimeout(refresh, 60000);
		});
	}

	document.addEventListener('DOMContentLoaded', refresh);
	document.addEventListener('visibilitychange', function () {
		if (!document.hidden) refresh();
	});
	document.addEventListener('galleria:content-loaded', refresh);
}());

