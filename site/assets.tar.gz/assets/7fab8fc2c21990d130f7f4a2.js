(function ($) {
    "use strict";
    $(document).ready(function(){
        var $menu = $('.nav-menu');
        $menu.find('ul.sub-menu > li').each(function(){
            var $submenu = $(this).find('>ul');
            if($submenu.length == 1){
                $(this).on('hover',function(){
                    if($submenu.offset().left + $submenu.width() > $(window).width()){
                        $submenu.addClass('back');
                    }else if($submenu.offset().left < 0){
                        $submenu.addClass('back');
                    }
                }, function(){
                    $submenu.removeClass('back');
                });
            }
        });
        
        $('.menu-btn').find('ul.sub-menu > li').each(function(){
            var $menuSub = $(this).find('>ul');
            if($menuSub.length == 1){
                $(this).on('hover',function(){
                    if($menuSub.offset().left + $menuSub.width() > $(window).width()){
                        $menuSub.addClass('back');
                    }else if($menuSub.offset().left < 0){
                        $menuSub.addClass('back');
                    }
                }, function(){
                    $menuSub.removeClass('back');
                });
            }
        });
        
        /* Menu drop down*/
        $('.nav-menu li.menu-item-has-children').append('<span class="cms-menu-toggle"><i class="fa fa-angle-down"></i></span>');
        $('.menu-btn.menu-item-has-children').append('<span class="cms-menu-toggle"><i class="fa fa-angle-down"></i></span>');
        $('.cms-menu-toggle').on('click',function(){
            $(this).prev().toggleClass('submenu-open');
        });
        /* Page Fixed Menu */
        $('.header-fixed-page').parents('body').addClass('remove-margin-top');
        $('#cshero-header.no-sticky').parents('body').addClass('remove-margin-top');
        /* open header popup */
        $(".cms-open-popup").fullScreenPopup({
            lockDocumentScroll: true,
        });
    });

	/* $('li.menu-item').each(function() {
		if ($(this).find('ul:first').length > 0) {
			$(this).find('ul:first').wrapAll('<span class="wrapper"></span>');
		}
	});*/
  // whenever we hover over a menu item that has a submenu
  /*$('li.menu-item').on('mouseover', function() {
    var $menuItem = $(this),
        $submenuWrapper = $('> .wrapper', $menuItem);
    
    // grab the menu item's position relative to its positioned parent
    var menuItemPos = $menuItem.position();
    
    // place the submenu in the correct position relevant to the menu item
    $submenuWrapper.css({
      top: menuItemPos.top,
      left: menuItemPos.left + Math.round($menuItem.outerWidth() * 0.75)
    });
  });*/
})(jQuery);
