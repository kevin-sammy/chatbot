(function(){
  function qs(el,sel){return el.querySelector(sel)}
  function qsa(el,sel){return Array.from(el.querySelectorAll(sel))}

  function pauseOthers(gallery, except){
    qsa(gallery,'video').forEach(v=>{ if(v!==except) v.pause(); });
  }

  function initCarousel(gallery){
    const track = qs(gallery,'.gmg-track');
    if(!track) return;
    const slides = qsa(track,'.gmg-item');
    const prev = qs(gallery,'.gmg-prev');
    const next = qs(gallery,'.gmg-next');
    const dots = qsa(gallery,'[data-gmg-dot]');
    const thumbs = qsa(gallery,'.gmg-thumbs [data-gmg-thumb-target], .gmg-thumbs .gmg-thumb-button');
    const configuredPerView=Math.max(1,Math.min(3,parseInt(gallery.dataset.gmgPerView || '1',10) || 1));
    const perView=()=>gallery.clientWidth<=700 ? 1 : configuredPerView;

    function currentIndex(){
      if(!slides.length) return 0;
      let best=0, dist=Infinity;
      slides.forEach((s,i)=>{ const d=Math.abs(s.offsetLeft-track.scrollLeft); if(d<dist){dist=d;best=i;} });
      return best;
    }
    function visibleSlides(i){
      const maxStart=Math.max(0,slides.length-perView());
      i=Math.max(0,Math.min(maxStart,i));
      return slides.slice(i,Math.min(slides.length,i+perView()));
    }
    function setCarouselHeight(i){
      if(!slides.length) return;
      const group=visibleSlides(i);
      const apply=()=>{
        const heights=group.map(slide=>Math.ceil(slide.scrollHeight || slide.getBoundingClientRect().height)).filter(Boolean);
        const h=heights.length ? Math.max(...heights) : 0;
        if(h>0) track.style.height=h+'px';
      };
      apply();
      group.forEach(slide=>{
        qsa(slide,'img').forEach(img=>{ if(!img.complete) img.addEventListener('load',apply,{once:true}); });
        qsa(slide,'video').forEach(v=>{ if(v.readyState<1) v.addEventListener('loadedmetadata',apply,{once:true}); });
        qsa(slide,'iframe').forEach(f=>f.addEventListener('load',apply,{once:true}));
      });
    }
    function go(i){
      const maxStart=Math.max(0,slides.length-perView());
      i=Math.max(0,Math.min(maxStart,i));
      slides[i].scrollIntoView({behavior:'smooth',block:'nearest',inline:'start'});
      pauseOthers(gallery);
      update(i);
    }
    function update(i){
      const maxStart=Math.max(0,slides.length-perView());
      i=Math.max(0,Math.min(maxStart,i));
      dots.forEach((d,x)=>d.classList.toggle('is-active',x===i));
      qsa(gallery,'.gmg-thumb').forEach((t,x)=>t.classList.toggle('is-active',x===i));
      qsa(gallery,'.gmg-thumb-number').forEach((t,x)=>t.classList.toggle('is-active',x===i));
      if(prev) prev.hidden = slides.length <= perView() || i <= 0;
      if(next) next.hidden = slides.length <= perView() || i >= maxStart;
      setCarouselHeight(i);
    }
    prev && prev.addEventListener('click',()=>go(currentIndex()-1));
    next && next.addEventListener('click',()=>go(currentIndex()+1));
    dots.forEach((d,i)=>d.addEventListener('click',()=>go(i)));
    thumbs.forEach((b,i)=>b.addEventListener('click',()=>go(Number.isFinite(parseInt(b.dataset.gmgThumbTarget,10)) ? parseInt(b.dataset.gmgThumbTarget,10) : i)));
    let raf=0;
    track.addEventListener('scroll',()=>{ cancelAnimationFrame(raf); raf=requestAnimationFrame(()=>update(currentIndex())); },{passive:true});
    update(0);
    if('ResizeObserver' in window && slides.length){
      const ro=new ResizeObserver(()=>setCarouselHeight(currentIndex()));
      slides.forEach(slide=>ro.observe(slide));
    }
    window.addEventListener('resize',()=>setCarouselHeight(currentIndex()),{passive:true});
  }

  function initHorizontal(gallery){
    const track=qs(gallery,'.gmg-track'); if(!track) return;
    const prev=qs(gallery,'.gmg-prev'), next=qs(gallery,'.gmg-next');
    const amount=()=>Math.max(240,track.clientWidth*.75);
    prev && prev.addEventListener('click',()=>track.scrollBy({left:-amount(),behavior:'smooth'}));
    next && next.addEventListener('click',()=>track.scrollBy({left:amount(),behavior:'smooth'}));
    const updateArrows=()=>{
      const max=Math.max(0,track.scrollWidth-track.clientWidth);
      if(prev) prev.hidden = max <= 2 || track.scrollLeft <= 2;
      if(next) next.hidden = max <= 2 || track.scrollLeft >= max-2;
    };
    let arrowRaf=0;
    track.addEventListener('scroll',()=>{ cancelAnimationFrame(arrowRaf); arrowRaf=requestAnimationFrame(updateArrows); },{passive:true});
    window.addEventListener('resize',updateArrows,{passive:true});
    updateArrows();

    // Match the natural content height of a sibling Gutenberg column. We do
    // not measure our own column because changing the gallery height would then
    // feed back into the measurement. When the Columns block stacks (mobile),
    // or there is no usable sibling, the saved fixed height remains the fallback.
    if(gallery.classList.contains('gmg-horizontal-height-fill')){
      const column=gallery.closest('.wp-block-column');
      const columns=column && column.parentElement && column.parentElement.closest('.wp-block-columns');
      if(column && columns){
        const siblingColumns=Array.from(columns.children).filter(el=>
          el!==column && el.classList && el.classList.contains('wp-block-column')
        );

        const contentHeight=(el)=>{
          const children=Array.from(el.children).filter(child=>{
            const cs=getComputedStyle(child);
            return cs.display!=='none' && cs.position!=='absolute' && cs.position!=='fixed';
          });
          if(!children.length) return 0;
          const top=Math.min(...children.map(child=>child.getBoundingClientRect().top));
          const bottom=Math.max(...children.map(child=>child.getBoundingClientRect().bottom));
          const cs=getComputedStyle(el);
          const padTop=parseFloat(cs.paddingTop)||0;
          const padBottom=parseFloat(cs.paddingBottom)||0;
          return Math.max(0,bottom-top+padTop+padBottom);
        };

        let raf=0;
        const setMatchedHeight=()=>{
          cancelAnimationFrame(raf);
          raf=requestAnimationFrame(()=>{
            // Only match columns that are actually side-by-side. Once Gutenberg
            // stacks them, return to the normal responsive row height.
            const ownRect=column.getBoundingClientRect();
            const sameRow=siblingColumns.filter(sib=>{
              const r=sib.getBoundingClientRect();
              return Math.abs(r.top-ownRect.top)<12 && r.width>0;
            });
            if(!sameRow.length){
              gallery.style.removeProperty('--gmg-scroll-effective-h');
              return;
            }

            const target=Math.max(...sameRow.map(contentHeight),0);
            if(target<180){
              gallery.style.removeProperty('--gmg-scroll-effective-h');
              return;
            }

            // The track keeps a small bottom area for the visible scrollbar, so
            // subtract it from the image row to make the whole gallery align with
            // the sibling column rather than becoming slightly taller than it.
            const scrollbarReserve=18;
            const available=Math.max(160,Math.floor(target-scrollbarReserve));
            gallery.style.setProperty('--gmg-scroll-effective-h',available+'px');
          });
        };

        setMatchedHeight();
        if('ResizeObserver' in window){
          const ro=new ResizeObserver(setMatchedHeight);
          siblingColumns.forEach(sib=>{
            ro.observe(sib);
            Array.from(sib.children).forEach(child=>ro.observe(child));
          });
        }
        // Images/fonts inside the sibling can settle after DOMContentLoaded.
        window.addEventListener('load',setMatchedHeight,{once:true});
        window.addEventListener('resize',setMatchedHeight,{passive:true});
      }
    }
  }

  function initLightbox(gallery){
    const triggers=qsa(gallery,'.gmg-lightbox-trigger');
    if(!triggers.length) return;
    let box=null;
    function close(){
      if(!box) return;
      const closing=box;
      box=null;
      closing.classList.remove('is-open');
      document.body.classList.remove('gmg-lightbox-open');
      window.setTimeout(()=>closing.remove(),230);
    }
    function open(trigger,img){
      if(box){ box.remove(); box=null; }
      box=document.createElement('div');
      box.className='gmg-lightbox';
      box.setAttribute('role','dialog');
      box.setAttribute('aria-modal','true');
      box.innerHTML='<button class="gmg-lightbox-close" type="button" aria-label="Close">×</button><div class="gmg-lightbox-inner"></div>';

      const fullSrc=trigger.dataset.fullSrc || img.currentSrc || img.getAttribute('src');
      const naturalW=parseInt(trigger.dataset.naturalWidth || img.naturalWidth || img.getAttribute('width') || 0,10);
      const naturalH=parseInt(trigger.dataset.naturalHeight || img.naturalHeight || img.getAttribute('height') || 0,10);

      // Build a clean image rather than cloning the page image. This guarantees
      // the lightbox cannot inherit srcset, sizes="auto", lazy-load containment,
      // or theme/plugin sizing attributes from the post image.
      const lightImg=new Image();
      lightImg.className='gmg-lightbox-media';
      lightImg.alt=img.alt || '';
      if(naturalW) {
        lightImg.width=naturalW;
        lightImg.style.maxWidth='min(94vw,'+naturalW+'px)';
      } else {
        lightImg.style.maxWidth='94vw';
      }
      if(naturalH) {
        lightImg.height=naturalH;
        lightImg.style.maxHeight='min(90vh,'+naturalH+'px)';
      } else {
        lightImg.style.maxHeight='90vh';
      }
      lightImg.decoding='async';
      lightImg.addEventListener('load',()=>lightImg.classList.add('is-ready'),{once:true});
      lightImg.src=fullSrc;
      if(lightImg.complete) requestAnimationFrame(()=>lightImg.classList.add('is-ready'));

      qs(box,'.gmg-lightbox-inner').appendChild(lightImg);
      document.body.appendChild(box);
      document.body.classList.add('gmg-lightbox-open');
      requestAnimationFrame(()=>requestAnimationFrame(()=>box && box.classList.add('is-open')));
      qs(box,'.gmg-lightbox-close').focus({preventScroll:true});
      box.addEventListener('click',e=>{if(e.target===box || e.target===qs(box,'.gmg-lightbox-inner')) close();});
      qs(box,'.gmg-lightbox-close').addEventListener('click',close);
    }
    triggers.forEach(t=>t.addEventListener('click',()=>{const img=qs(t,'img'); if(img) open(t,img);}));
    document.addEventListener('keydown',e=>{if(e.key==='Escape') close();});
  }


  function initYouTubeThumbFallback(gallery){
    qsa(gallery,'img[data-gmg-youtube-id]').forEach(img=>{
      const id=img.dataset.gmgYoutubeId;
      if(!id) return;

      const markReady=()=>{
        if(img.naturalWidth>0) img.classList.add('is-ready');
      };
      const fallback=()=>{
        const quality=img.dataset.gmgYoutubeQuality || 'maxresdefault';
        img.classList.remove('is-ready');
        if(quality==='maxresdefault'){
          img.dataset.gmgYoutubeQuality='sddefault';
          img.src='https://i.ytimg.com/vi/'+id+'/sddefault.jpg';
        }else if(quality==='sddefault'){
          img.dataset.gmgYoutubeQuality='hqdefault';
          img.src='https://i.ytimg.com/vi/'+id+'/hqdefault.jpg';
        }
      };

      img.addEventListener('load',markReady);
      img.addEventListener('error',fallback);

      // The image may have completed before the deferred footer script ran.
      if(img.complete){
        if(img.naturalWidth>0) markReady();
        else fallback();
      }
    });
  }

  function markGalleryReady(gallery){
    // Two animation frames let synchronous measurements/styles settle first.
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      gallery.classList.add('gmg-is-ready');
      gallery.dataset.gmgReady='true';
    }));
  }


  document.addEventListener('DOMContentLoaded',function(){
    qsa(document,'.gmg-gallery').forEach(g=>{
      const layout=g.dataset.gmgLayout;
      // Resolve thumbnail candidates before exposing enhanced controls.
      initYouTubeThumbFallback(g);
      if(layout==='carousel' || layout==='carousel-thumbs') initCarousel(g);
      if(layout==='horizontal') initHorizontal(g);
      initLightbox(g);
      qsa(g,'video').forEach(v=>v.addEventListener('play',()=>pauseOthers(g,v)));
      markGalleryReady(g);
    });
  });
})();
