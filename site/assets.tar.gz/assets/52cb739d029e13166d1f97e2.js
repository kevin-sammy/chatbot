var $ = jQuery.noConflict();

jQuery(document).ready(function($) {
(function ($) { 
    $.StoreHours = function () {  
    console.log ('test');       
    };

    $.StoreHours.prototype = {
        getCurrentDay: function(){    
            var weekday = new Array(7);
            weekday[0]=  "sun";
            weekday[1] = "mon";
            weekday[2] = "tue";
            weekday[3] = "wed";
            weekday[4] = "thu";
            weekday[5] = "fri";
            weekday[6] = "sat";
            return weekday[new Date().getDay()]; 
            console.log ('test'+ weekday[new Date().getDay()]);
        }, 
        getCurrentDayMonth:function(){
            var d = new Date(); 
            var mm = (d.getMonth()+1).toString(); 
            var dd  = d.getDate().toString();

            if(mm.length == 1)
                mm = '0' + mm;
            if(dd.length == 1)
                dd = '0' + dd;
            return mm + '/' + dd;
        },
        getDateByHour: function(hour,gmt){                        
            var dateStr = new Date().toString().substr(0,16) + hour + ":00";
            if(gmt != null)
                dateStr += " GMT" + gmt;
            
            return new Date(dateStr); 
        },
        storeHours: function (arguments) {                                         
            $(".sh-" + this.getCurrentDay()).addClass("status-current");
            $(".sh-" + this.getCurrentDay() + " [data-sh-start]")
                    .each(function(){       
                        
                        var currentDayMonth=$.StoreHours.prototype.getCurrentDayMonth();
                        var closedDays=$("[data-sh-closedays]").attr('data-sh-closedays');
                        
                        if(closedDays.indexOf(currentDayMonth) >= 0){                            
                            if(!$(this).parent().hasClass("status-opened"))
                                $(this).parent().addClass("status-closed");
                            return;
                        }
                                                    
                        var gmt = $(this).attr('data-sh-gmt');
                        var dateStart = $.StoreHours.prototype.getDateByHour($(this).attr('data-sh-start'),gmt);
                        var dateEnd = $.StoreHours.prototype.getDateByHour($(this).attr('data-sh-end'),gmt);
                        if(dateEnd < dateStart){
                            dateEnd.setDate(dateEnd.getDate() + 1);                            
                        }
                        var dt = new Date();                                                
                        
                        if(dt >= dateStart && dt <= dateEnd){                           
                           $(this).parent().removeClass("status-closed");
                           $(this).parent().addClass("status-opened");
                       }
                       else{
                           if(!$(this).parent().hasClass("status-opened"))
                            $(this).parent().addClass("status-closed");
                       }
                        
                    });
            $(".sh-" + this.getCurrentDay())
                    .each(function(){  
                        
                        var status = $("[data-sh-status]",this).attr("data-sh-status");                        
                        if(status !== ""){
                            $(this).addClass("status-" + status);
                        }                       
            });
                    
            
            $(".sh-alert-opened").each(function(){
                if($(".sh-" + $.StoreHours.prototype.getCurrentDay()).hasClass("status-opened"))
                    $(this).addClass("status-shown");
                else
                    $(this).addClass("status-hidden");
            });
            
            $(".sh-alert-closed").each(function(){
                if($(".sh-" + $.StoreHours.prototype.getCurrentDay()).hasClass("status-closed"))
                    $(this).addClass("status-shown");
                else
                    $(this).addClass("status-hidden");
            });
            
        }        
    }; 
    
    $.StoreHours.prototype.storeHours(arguments);    

}(jQuery));
});