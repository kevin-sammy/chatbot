/**
     * Copyright 2012, Digital Fusion
     * Licensed under the MIT license.
     * http://teamdf.com/jquery-plugins/license/
     *
     * @author Sam Sehnert
     * @desc A small plugin that checks whether elements are within
     *       the user visible viewport of a web browser.
     *       only accounts for vertical position, not horizontal.
     */

!function(a){ "use strict"; var b=a(window);a.fn.visible=function(c,d,e,f){if(!(this.length<1)){e=e||"both";var g=this.length>1?this.eq(0):this,h=void 0!==f&&null!==f,i=h?a(f):b,j=h?i.position():0,k=g.get(0),l=i.outerWidth(),m=i.outerHeight(),n=!0!==d||k.offsetWidth*k.offsetHeight;if("function"==typeof k.getBoundingClientRect){var o=k.getBoundingClientRect(),p=h?o.top-j.top>=0&&o.top<m+j.top:o.top>=0&&o.top<m,q=h?o.bottom-j.top>0&&o.bottom<=m+j.top:o.bottom>0&&o.bottom<=m,r=h?o.left-j.left>=0&&o.left<l+j.left:o.left>=0&&o.left<l,s=h?o.right-j.left>0&&o.right<l+j.left:o.right>0&&o.right<=l,t=c?p||q:p&&q,u=c?r||s:r&&s,t=o.top<0&&o.bottom>m||t,u=o.left<0&&o.right>l||u;if("both"===e)return n&&t&&u;if("vertical"===e)return n&&t;if("horizontal"===e)return n&&u}else{var v=h?0:j,w=v+m,x=i.scrollLeft(),y=x+l,z=g.position(),A=z.top,B=A+g.height(),C=z.left,D=C+g.width(),E=!0===c?B:A,F=!0===c?A:B,G=!0===c?D:C,H=!0===c?C:D;if("both"===e)return!!n&&F<=w&&E>=v&&H<=y&&G>=x;if("vertical"===e)return!!n&&F<=w&&E>=v;if("horizontal"===e)return!!n&&H<=y&&G>=x}}}}(jQuery);