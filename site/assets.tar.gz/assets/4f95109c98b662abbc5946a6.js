var $ = jQuery.noConflict();

jQuery(document).ready(function($) {
	$('#stores-grid').mediaBoxes({
	    	multipleFilterLogic: 'AND',
            filterContainer: '.filters',
	    	search: '#store-search',
            sortContainer: '#sort',
            searchTarget: '.media-box-title, .media-box-categories',
	    	columns: 2,
	    	getSortData: {
				title: '[data-name]',
			  },
  			sortBy: 'title',
	    	resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 2,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ],
	    	boxesToLoadStart: 8,
	    	boxesToLoad: 8,
	    	horizontalSpaceBetweenBoxes: 15,
        	verticalSpaceBetweenBoxes: 15,
        	lazyLoad : true,
        	isFitWidth: true,
        	noMoreEntriesWord : 'No More Stores',
			minBoxesPerFilter: 999
	    });
	     
	$('.flex-box').mediaBoxes({
	    	columns: 1,
	    	resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 2,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ],
	    	boxesToLoadStart: 8,
	    	boxesToLoad: 8,
	    	horizontalSpaceBetweenBoxes: 15,
        	verticalSpaceBetweenBoxes: 15,
        	lazyLoad : true,
        	isFitWidth: true,
        	noMoreEntriesWord : 'No More Posts',
			minBoxesPerFilter: 999
	    });
	    
	$('#home-happening').mediaBoxes({
		multipleFilterLogic: 'AND',
		filterContainer: '.filters',
		columns: 3,
		sortBy: 'random',
		boxesToLoadStart: 3,
		boxesToLoad: 3,
		waitUntilThumbWithRatioLoads: false,
		horizontalSpaceBetweenBoxes: 15,
		verticalSpaceBetweenBoxes: 15,
		resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 2,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ],
        
		overlayEffect : 'fade',
		animation_on_thumbnail_overlay_hover : [
			{ item : '.fa', animation : 'from-bottom' }
		],
		lazyLoad : false,
		isFitWidth: true,
		minBoxesPerFilter: 3,
		noMoreEntriesWord : 'No More Posts'
	});
	
	$('#related-grid').mediaBoxes({
		columns: 1,
		boxesToLoadStart: 2,
		boxesToLoad: 2,
		waitUntilThumbWithRatioLoads: false,
		horizontalSpaceBetweenBoxes: 5,
		verticalSpaceBetweenBoxes: 5,
		overlayEffect : 'fade',
		animation_on_thumbnail_overlay_hover : [
			{ item : '.fa', animation : 'from-bottom' }
		],
		resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 2,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ],
		lazyLoad : false,
		isFitWidth: false,
		noMoreEntriesWord : 'No More Posts'
	});
	
	$('#post-grid').mediaBoxes({
		filterContainer: '.filters',
		search: '#search',
		searchTarget: '.media-box-title, .media-box-categories, .media-box-footer , .media-box-type',
		sortContainer: '#sort',
		columns: 3,
		boxesToLoadStart: 9,
		boxesToLoad: 6,
		waitUntilThumbWithRatioLoads: false,
		horizontalSpaceBetweenBoxes: 15,
		verticalSpaceBetweenBoxes: 15,
		getSortData: {
		  title: '.media-box-title',
		  categories: '.media-box-categories'
		},
		minBoxesPerFilter: 999,
		overlayEffect : 'fade',
		animation_on_thumbnail_overlay_hover : [
			{ item : '.fa', animation : 'from-bottom' }
		],
		lazyLoad : false,
		noMoreEntriesWord : 'No More Posts',
		resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 2,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ]
	}); 
	
	if ( $('.post-gallery').length > 0 ) {
		var galleryBoxes = 9; 
		
		if (window.location.href.indexOf("store") > -1 || window.location.href.indexOf("about-us") > -1 ) {
			var galleryBoxes = 6; 
		}
	}
	
	$('.post-grid.gallery').mediaBoxes({
		filterContainer: '#filter',
		search: '#search',
		columns: 1,
		boxesToLoadStart: galleryBoxes,
		boxesToLoad: 6,
		lazyLoad : false,
		horizontalSpaceBetweenBoxes: 0,
		verticalSpaceBetweenBoxes:0,
		minBoxesPerFilter: 20,
		deepLinkingOnFilter: false,
		resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ],
		fancybox: {
			thumbs : { autoStart : true },    // Display thumbnails on opening/closing
		},
		animation_on_thumbnail_overlay_hover : [
			{ item : '.media-box-title', animation : 'from-top' },
			{ item : '.media-box-date', animation : 'from-bottom' }
		],
	}); 
	
	//gallery
	if(location.href.indexOf("gallery") != -1) {
	    //$('.post-grid.gallery .media-box-image div').data('height', '.6');
		console.log($('.post-grid.gallery .media-box-image div').data());
	}
	
	$('.post-gallery').mediaBoxes({
		filterContainer: '#filter',
		search: '#search',
		columns: 3,
		boxesToLoadStart: galleryBoxes,
		boxesToLoad: 6,
		lazyLoad : false,
		horizontalSpaceBetweenBoxes: 0,
		verticalSpaceBetweenBoxes:0,
		minBoxesPerFilter: 20,
		deepLinkingOnFilter: false,
		resolutions: [
            {
                maxWidth: 960,
                columnWidth: 'auto',
                columns: 2,
            },
            {
                maxWidth: 650,
                columnWidth: 'auto',
                columns: 1,
            },
            {
                maxWidth: 450,
                columnWidth: 'auto',
                columns: 1,
            },
        ],
		fancybox: {
			thumbs : { autoStart : true },    // Display thumbnails on opening/closing
		},
		animation_on_thumbnail_overlay_hover : [
			{ item : '.media-box-title', animation : 'from-top' },
			{ item : '.media-box-date', animation : 'from-bottom' }
		],
	}); 
	$( ".media-boxes-search input" ).on("input", function(){
	  if($(".media-boxes-clear").hasClass("fa-search")) {
		$(".media-boxes-clear").removeClass("fa-search").addClass("fa-close");
	  }
	});
	
	$(".media-boxes-clear").click(function() {
		if($(".media-boxes-clear").hasClass("fa-close")) {
			$(this).removeClass("fa-close").addClass("fa-search");
	  	}
	});
	
	$('.post-grid').on('layoutComplete', function() {
		if (window.GalleriaSlickControls) {
			window.GalleriaSlickControls.initMedia(this);
		}
	});

	//$('.post-grid').wrapAll('<div style="margin-left:-15px;"></div>');
	var postResize = function() {
				$('.post-grid.gallery .featured-thumb').each().find('.media-box-image').equalHeights();
			}
	
	var singleBox = function() {
		if ($(window).width() > 992){
			var mediaBoxes = $('.post-grid .media-box').length;
			//$('.post-grid.gallery .media-box').addClass('single-box');
			if (mediaBoxes == 1) {
				$('.post-grid .media-box').addClass('single-box');
				$('.post-grid .media-box').data('columns', '2');
				$('.post-grid .media-box .media-box-content').append($('.post-grid .media-box-footer'));
				if($('.post-grid .media-box .p-2').length === 0 ) {
					$('<div class="p-2"></div>').insertBefore('.post-grid .media-box .media-box-footer');
				}
				$('.post-grid').mediaBoxes( 'resize' );
				$('.post-grid').mediaBoxes( 'refresh' ); 
			}
		}
	};
	
	
	singleBox();
	postResize();  
	  
	$(window).resize(function() {
		singleBox();
		postResize();
	});
	
	$('.filters li a').click(function() {
		singleBox();
		$('.media-boxes-sort-order').removeClass('not-clicked');
	});
	
	 $('.time-filter li a, .post-filter li a').click(function() {
	 		if($(this).closest('.filters').hasClass('time-filter')) {
				var timeFilter = $(this).text();
			} else {
				var timeFilter = $('.time-filter li a.selected').text();
			}
		
			if($(this).closest('.filters').hasClass('post-filter')) {
				var postFilter = $(this).text();
			} else {
				var postFilter = $('.post-filter li a.selected').text();
			}
	 	
			if(postFilter == 'All') {
				$('.no-more-entries').find('.post-filter').text('Events or Deals');
				$('.happenings a').not('.all').addClass('hidden');
				$('.happenings .all').removeClass('hidden');
			} else {
				$('.no-more-entries').find('.post-filter').text(postFilter);
				$('.happenings a').not('.'+ postFilter.toLowerCase()).addClass('hidden');
				$('.happenings .'+ postFilter.toLowerCase()).removeClass('hidden');
			}
			
			if(timeFilter == 'All Happenings') {
				$('.no-more-entries').find('.time-filter').text('at Galleria');
				$('.no-more-entries').find('.time-filter').addClass('special');
			} else {
				$('.no-more-entries').find('.time-filter').text(timeFilter);	
			}
			
	 });
	
	var mediaGrid = $(".media-boxes-container")[0];
  
	if(mediaGrid) {
		let resizeObserver = new ResizeObserver(() => {
			if ( $(".visible-media-boxes-by-filter").length < 1 ) { 
				$('.no-more-entries').show();
			} else {
				$('.no-more-entries').hide();
			}
		});
  
		resizeObserver.observe(mediaGrid);
	}

	$( ".media-box-loaded" ).ready(function (){
		$('.storeq_more').addClass('stick_btm');
	});
 
	$('.filters').not('.clear-filter').click(function() {
    	//$('.clear-filter:checked').trigger("click");
    	$('.clear-filter').parent().find('.no-filter').text('Clear Filter');
		$('.clear-filter').parent().find('.no-filter').addClass('clear-filters');
		
		$('.clear-filter').parent().css('visibility' , 'visible');
		
		if($(this).prop("checked") == true){
			console.log("Checkbox is checked.");
			$('.clear-filter').parent().show();
		}
		else if($(this).prop("checked") == false){
			console.log("Checkbox is unchecked.");
			$('.clear-filter').parent().hide();
		}
		
    });

    var store_title = $('.store-title').text();
	
	//stores hash
	if(location.href.indexOf("#(stores-grid|") != -1) {
	    var url = window.location.hash;
	  	var index = url.indexOf("#");
		if (index !== -1)
		{
			var hash = url.substring(index + 1);
			var filter = hash.match(/.[\w\d-]+;/g).map(function(value){return value.substring(1, value.length-1)});
			var i;
			for (i = 0; i < filter.length; ++i) {
				
			
				if($('.store-filter[data-filter=".'+ filter[i] +'"]').length > 0) {
					//console.log(filter[i]);
					$('.store-title').html('Filter: ' + filter[i].charAt(0).toUpperCase() + filter[i].slice(1).toLowerCase().replace(/\-/g, ' '));
					$('.store-title').show();
					$('.clear-filter').parent().find('.no-filter').text('Clear Filter');
					$('.clear-filter').parent().find('.no-filter').addClass('clear-filters');
				} else {
					//console.log(filter[i]);
				}
			}
			
		}
	} 
	
	//happenings hash
	if(location.href.indexOf("#(post-grid|") != -1 || location.href.indexOf("#(home-happening|") != -1) {
	    var url = window.location.hash;
	  	var index = url.indexOf("#");
		if (index !== -1)
		{
			var hash = url.substring(index + 1);
			var filter = hash.match(/.[\w\d-]+;/g).map(function(value){return value.substring(1, value.length-1)});
			var i;
			for (i = 0; i < filter.length; ++i) {
				if($('.time-filter li a[data-filter=".'+ filter[i] +'"]').length > 0) {
					$('.no-more-entries').find('.time-filter').text(filter[i]);
					if($('.no-more-entries').find('.post-filter').text().length <= 1) {
						$('.no-more-entries').find('.post-filter').text('Events or Deals');
					}
				} 
				
				if($('.post-filter li a[data-filter=".'+ filter[i] +'"]').length > 0) {
					$('.no-more-entries').find('.post-filter').text(filter[i]);
					$('.happenings a').not('.'+ filter[i]).addClass('hidden');
					$('.happenings .' + filter[i]).removeClass('hidden');
				} 
			} 
			
		}
	}
	
    $('.store-filter').click(function() {
    	$('.store-filter:checked').not(this).trigger("click");
    	
    	var filter_title = $(this).map(function(){
			return this.previousSibling.nodeValue
		});
		
		var filter_btn = $(this).closest('.column-filter').find('.filter-header');
		var filterbtn_title = filter_btn.text();
		
		//console.log(filterbtn_title);
		if(filterbtn_title == 'Store Categories:') {
			var filter = 'Store Category: '; 
			var store_filter = $(".store-filters[data-target='#storeCategoryFilter']");
			var store_filterBtn = store_filter.find('.filter-title');
		} else if(filterbtn_title == 'Store Types:') {
			var filter = 'Store Type: ';
			var store_filter = $(".store-filters[data-target='#storeTypeFilter']");
			var store_filterBtn = store_filter.find('.filter-title');
		}
		
		if (this.checked) {
			$('.store-title').html(filter + filter_title[0]);
			store_filterBtn.text(filter_title[0]);
			$('.store-title').show();
			store_filter.find('.fa').removeClass('fa-caret-up fa-caret-down').addClass('fa-times');
			if(!$('.clear-filter').parent().find('.no-filter').hasClass('clear-filters')) {
				$(this).text('Clear Filter');
				$(this).addClass('clear-filters');
			}
			
			$('.clear-filter').parent().css('visibility' , 'visible');
			$('.clear-filter').parent().show();
		} else {
			store_filterBtn.text(filterbtn_title.replace(":", ""));
			store_filter.find('.fa').removeClass('fa-times').addClass('fa-caret-down');
			$('.store-title').hide();
			$('.store-title').html(store_title);
			$('.clear-filter').parent().hide();
		}
    });
    
    /*
 * Store location filters
 *
 * Floor/location filters behave like radio buttons,
 * except New Wing can be combined with one other location.
 */
$('.locations-filter').click(function() {

    var $this = $(this);
    var isNewWing = $this.data('id') === 'new-wing';

    /*
     * New Wing is allowed to coexist with a floor/location,
     * so clicking it should not clear anything else.
     */
    if (isNewWing) {
        return;
    }

    /*
     * For every other location:
     * uncheck other selected locations,
     * but leave New Wing selected.
     */
    $('.locations-filter:checked')
        .not(this)
        .not('[data-id="new-wing"]')
        .each(function() {
            $(this).trigger('click');
        });

});

/*
 * Store launch status
 *
 * Open and Coming Soon are mutually exclusive.
 */
$('.status-filter').click(function() {

    $('.status-filter:checked')
        .not(this)
        .each(function() {
            $(this).trigger('click');
        });

});
    
     $('.clear-filter:not(:checked)').click(function() {
    	$('.filters:checked').not(this).trigger("click");
    	$('.stores-list .deals').addClass('hidden');	
    	 setTimeout(function () {
    	 	$('.clear-filter:checked').trigger("click");
    	 	$('.clear-filter').parent().hide();
    	 	setTimeout(function () {
				$('.stores-list .deals').removeClass('hidden');
			 }, 500);	
    	 }, 1000);	 
    	 
    });
    
    $('.media-boxes-sort-order').click(function() {
    	if ( $(this).hasClass('not-clicked') ) {
    		if( $(".filters:checked").length == 0) {
    			$('.clear-filter').trigger("click");
    			$(this).removeClass('not-clicked');
    		}
		}
		$('.media-boxes-drop-down-menu').find('a').not('.selected').trigger('click');
	});
    $('.collapse-btn').click(function(){
		$(this).find('.fa').toggleClass('fa-caret-down fa-caret-up');
	});
	$(document).click(function () {
     if($(".column-filter").hasClass("in")){
       $('.column-filter').collapse('hide');
     }
  });
	
	// Handle Media Box Footer
	$(".media-box-footer").each(function () {
		const mediaBoxFooter = $(this);
		const stores = mediaBoxFooter.find(".media-box-stores");
		const moreButton = mediaBoxFooter.find("#more-button");

		// Check if there are more than 2 items and show the "More" button
		if (stores.length > 2) {
			stores.each((index, store) => {
				if (index >= 2) {
					$(store).hide(); // Hide items beyond the second
				}
			});

			moreButton.show(); // Show the "View More" button

			// Add click event for toggling
			moreButton.on("click", function () {
				const isExpanded = $(this).hasClass("no-icon");

				if (isExpanded) {
					// Hide extra items
					stores.each((index, store) => {
						if (index >= 2) {
							$(store).slideUp();
						}
					});
					$(this).text("View More").removeClass("no-icon").addClass("plus-icon");
				} else {
					// Show all items
					stores.each((index, store) => {
						$(store).slideDown();
					});
					$(this).text("View Less").removeClass("plus-icon").addClass("no-icon");
				}

				// Resize the grid
				$("#post-grid").mediaBoxes("resize");
			});
		}
	});	

	// Handle CMS Custom Heading Title (H5 Links)
	$(".cms-custom-heading-title").each(function () {
		const heading = $(this);
		const linkGroups = heading.find(".link-group");
		const moreButton = heading.find("#more-btn");

		// The first Store is the summary; More represents every additional Store.
		if (linkGroups.length > 1) {
			linkGroups.each((index, linkGroup) => {
				if (index >= 1) {
					$(linkGroup).hide();
				}
			});

			moreButton.show(); // Show the "More" button

			// Toggle visibility on click
			moreButton.on("click", function () {
				const isExpanded = $(this).hasClass("no-icon");

				if (isExpanded) {
					// Collapse: Hide extra items
					linkGroups.each((index, linkGroup) => {
						if (index >= 1) {
							$(linkGroup).slideUp();
						}
					});
					$(this)
						.html('<small><i class="fa fa-plus"></i> More</small>')
						.attr("aria-expanded", "false")
						.removeClass("no-icon")
						.addClass("plus-icon");
				} else {
					// Expand: Show all items
					linkGroups.each((index, linkGroup) => {
						$(linkGroup).slideDown();
					});
					$(this)
						.html('<small><i class="fa fa-minus"></i> Less</small>')
						.attr("aria-expanded", "true")
						.removeClass("plus-icon")
						.addClass("no-icon");
				}

				// Trigger Owl Carousel resize
			});
		} else {
			moreButton.hide();
		}
	});
});

document.addEventListener("DOMContentLoaded", function() {
  let video = document.querySelector(".post-gallery .video video");

  if (video) {
    video.addEventListener("mouseenter", function () {
      video.play();
    });

    video.addEventListener("mouseleave", function () {
      video.pause();
      video.currentTime = 0; // Reset to start
    });
  }
});
