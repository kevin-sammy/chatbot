/* Presentation and Deal filtering are provided by Galleria Query Block V2. */
