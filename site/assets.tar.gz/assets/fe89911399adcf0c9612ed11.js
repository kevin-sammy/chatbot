jQuery(document).ready(function ($) {  
	//console.log(ajax_hours_params.homeurl);
	$("#ajaxsearchpro4_1").click(function(){
	  	console.log("clicked");
	  	setTimeout(function(){
	  		console.log($("#ajaxsearchpro4_1").data('asp-compact'));
		 
	  		if ($("#ajaxsearchpro4_1").data('asp-compact') == 'closed') {
				console.log("search page");
				window.open(ajax_hours_params.homeurl + '/?s=', '_self');
			}
		}, 1000);
	});
	
	
	$("#ajaxsearchpro1_1").find(".promagnifier").click(function(){
	  	console.log("search clicked");
	  	setTimeout(function(){
	  		if($("#ajaxsearchpro1_1").find(".proloading").is(":hidden") && 
	  		$("#ajaxsearchpro1_1").find(".proclose").is(":hidden")) {
	  			console.log("search page go");
				window.open(ajax_hours_params.homeurl + '/?s=' + $("#ajaxsearchpro1_1").find(".proinput input").val(), '_self');
	  		}
		}, 1000);
	});
	var timeNow = function() {
		return new Intl.DateTimeFormat('en-GB', {
			timeZone: 'Africa/Nairobi',
			hour: '2-digit',
			minute: '2-digit',
			hourCycle: 'h23'
		}).format(new Date()).replace('.', ':');
	}
	
	timeNow();
	
	function time12hr(time){

	//Save the times in variables

	var hours = time.substring(0, time.indexOf(':'));
	var minutes = time.substring(time.indexOf(':') + 1);

	hours = parseInt(hours, 10);
	//Set the AM or PM time

	var meridiem;
	if (hours >= 12){
	  meridiem = " pm";
	}
	else {
	  meridiem = " am";
	}


	//convert hours to 12 hour format and put 0 in front
	if (hours > 12){
		hours = hours - 12;
	}
	else if (hours === 0){
		hours = 12;	
	}

	return hours + ':' + minutes + meridiem;

	}
	
	var todayDate = function() {
		var parts = new Intl.DateTimeFormat('en-CA', {
			timeZone: 'Africa/Nairobi',
			year: 'numeric',
			month: '2-digit',
			day: '2-digit'
		}).formatToParts(new Date());
		var values = {};
		parts.forEach(function(part) {
			values[part.type] = part.value;
		});
		return values.year + values.month + values.day;
	}
		
	var weekday = new Array(7);
		weekday[0]=  "Sunday";
		weekday[1] = "Monday";
		weekday[2] = "Tuesday";
		weekday[3] = "Wednesday";
		weekday[4] = "Thursday";
		weekday[5] = "Friday";
		weekday[6] = "Saturday";
		
	function getStringBetween(str, start, end) {
		const result = str.match(new RegExp(start + "(.*)" + end));

		return result[1];
	}
	
	function days() {
		
	 	var today = new Date();
		//today.toLocaleString('en-GB', { timeZone: 'Africa/Nairobi' });
		
		var todayDay = today.toLocaleDateString('en-GB', {timeZone: 'Africa/Nairobi', weekday:'long' });
		
		var tomorrow = new Date(today);
		tomorrow.setDate(tomorrow.getDate() + 1);
		
		var tomorrowDay = new Date(tomorrow).toLocaleDateString('en-GB', {timeZone: 'Africa/Nairobi', weekday:'long' });
		
		var yesterday = new Date(today);
		yesterday.setDate(yesterday.getDate() - 1);
		
		var yesterdayDay = new Date(yesterday).toLocaleDateString('en-GB', {timeZone: 'Africa/Nairobi', weekday:'long' });
		
		//console.log(today);
		var days = {  
                today: today, 
               todayDay: todayDay, 
               tomorrow: tomorrow,
               tomorrowDay : tomorrowDay,
               yesterday : yesterday,
			   yesterdayDay : yesterdayDay
                }

	  	return days;
	}

	//console.log(days().todayDay);
	
	var dealRunStatus = function dealRunStatus($this){
		var dealStatus = '';
		
		if (!$this.hasClass(shortDay(days().todayDay)) ) {
			ajaxDeals.push($this.data('id'));
		}
		
		if($this.data('deal-from') !== '' && $this.data('deal-till') !== '' ) {
			if (!$this.hasClass('today') && (todayDate() >= $this.data('deal-from') && todayDate() <= $this.data('deal-till'))) {
				$this.addClass('today');
			} else if ($this.hasClass('today') && (todayDate() < $this.data('deal-from') || todayDate() > $this.data('deal-till'))){
				$this.removeClass('today');
			}
			
			if (!$this.hasClass('soon') && (todayDate() < $this.data('deal-from') || todayDate() < $this.data('deal-till'))) {
				$this.addClass('soon');
			} else if ($this.hasClass('soon') && (todayDate() >= $this.data('deal-till'))) {
				$this.removeClass('soon');
			}
		}
		
		if($this.data('deal-dates') !== '') {
			var dealDates = $this.data('deal-dates');
			if (String(dealDates).indexOf(", ") > 0) {
				dealDates = dealDates.split(", ");
			} else if (String(dealDates).indexOf(",") > 0 && String(dealDates).indexOf(", ") < 1 ) {
				dealDates = dealDates.split(",");
			} else {
				dealDates = [dealDates];
			}
			
			//console.log(dealDates);
			
			if (!$this.hasClass('today') && $.inArray(todayDate(), dealDates) !== -1 ) {
				$this.addClass('today');
			} else if ($this.hasClass('today') && $.inArray(todayDate(), dealDates) === -1 ) {
				$this.removeClass('today');
			}
			
			var upcommingDeal = 0;
			$.each( dealDates, function( index, date ){
				if (todayDate() < date ) {
					upcommingDeal++;
				} 
			});
			
			if(!$this.hasClass('soon') && upcommingDeal > 0 ) {
				$this.addClass('soon');
			} else if($this.hasClass('soon') && upcommingDeal == 0 ) {
				$this.removeClass('soon');
			}
		}
		
		if($this.data('deal-days') !== '') {
			var dealDays = $this.data('deal-days');
			
			//console.log(dealDays);
			if (dealDays && dealDays != "") {
				if(dealDays.indexOf(", ") > 0) {
					dealDays = dealDays.split(", ");
				} else if (dealDays.indexOf(",") > 0 && dealDays.indexOf(", ") < 1 ) {
					dealDays = dealDays.split(",");
				}
			}	else {
				dealDays = [dealDays];
			}
			
			//console.log(dealDays);
			
			if (!$this.hasClass('today') && $.inArray(days().todayDay, dealDays) !== -1 ) {
				$this.addClass('today');
			} else if ($this.hasClass('today') && $.inArray(days().todayDay, dealDays) === -1 ) {
				$this.removeClass('today');
			}
			
			var upcommingDeal = 0;
			$.each( dealDays, function( index, day ){
				if (days().todayDay < day && $this.data('deal-till') !== '' && todayDate() <= $this.data('deal-till')) {
					upcommingDeal++;
				} 
			});
			
			if(!$this.hasClass('soon') && upcommingDeal > 0 ) {
				$this.addClass('soon');
			} else if($this.hasClass('soon') && upcommingDeal == 0 ) {
				$this.removeClass('soon');
			}
		}

	 
		 
		 /*if(!$this.hasClass('soon')) {
		 	if($this.data('deal-dates').length > 0) {
				var dealDates = $this.data('deal-dates').toArray();
			
				if ($.inArray(todayDate(), dealDates) !== -1 ) {
					$this.addClass('today');
				} else {
					$this.removeClass('today');
				}
			}
			
			if($this.data('deal-from').length > 0 && $this.data('deal-till').length > 0 ) {
				
			}
		}*/
		
		$.each( weekday, function( i, day ) {
		//console.log('ths ' + days().todayDay);
		//console.log('shrt ' + day);
			if (day === days().todayDay ){
				$this.each(function() {
					if ($this.hasClass(shortDay(days().todayDay)) && $this.hasClass('today')) {
							//console.log('this ' + $this.data('id'));
							if ( $this.data('opening-hours') > $this.data('closing-hours') ) {
								if(dealStatus  != 'Open' && timeNow() < $this.data('closing-hours') ) {
									dealStatus = 'Open';
								}
						 
								if(dealStatus  != 'Closed' && timeNow() >= $this.data('closing-hours') && timeNow() < $this.data('opening-hours') ) {
									dealStatus = 'Closed';
								}
						
								 if(dealStatus  != 'Open' && timeNow() >= $this.data('opening-hours')) {
									dealStatus = 'Open';
								}

							} else {
							
								if(dealStatus  != 'Closed' && timeNow() < $this.data('opening-hours') ) {
										dealStatus = 'Closed';

								}
							
								if (dealStatus  != 'Open' && timeNow() >= $this.data('opening-hours') && timeNow() < $this.data('closing-hours')) {
									dealStatus = 'Open';
								} 
			
								if (dealStatus  != 'Closed' && timeNow() >= $this.data('closing-hours') ) {
									dealStatus = 'Closed';
		
								} 
			 
							}
						}	
				});
			}
		});
		
		
		if(timeNow() === '00:00') {
			
			
			if(!$this.hasClass(shortDay(days().todayDay))) {
				$this.addClass(shortDay(days().todayDay));
			} 
			
			$this.removeClass(shortDay(days().yesterdayDay)); 
			
			if ( $this.data('opening-hours') < $this.data('closing-hours') ) {
				if (dealStatus != null) {
					dealStatus = null;
				}
				ajaxDeals.push($this.data('id'));
			} else  {
				var timeToClose = ($this.data('closing-hours') - timeNow()) * 60000;
				
				setTimeout(function(){ 
						if (dealStatus != null) {
							dealStatus = null;
						}
						ajaxDeals.push($this.data('id'));
						
					}, timeToClose);
					
				}
			}
		
		return dealStatus; 
		
	}
	
	var shortDay = function(day) { 
	
		var shortDay = day.substring(0,3).toLowerCase();	
		
		return shortDay;
	}
	
	var storeHours;
	var dealHours;
	
	var ajaxStores = [];
	var ajaxDeals = [];
	
	var AjaxActive = 1;
	
	var oldNextOpen_hours = function oldNextOpen_hours(oldTime){
			 if(oldTime != null) {
			 	var openHours = oldTime.substring(
					oldTime.indexOf("at ") + 3, 
					oldTime.lastIndexOf(oldTime.match(/am|pm/)) + 2
				);
			 	return openHours;
			 }
	}

	var LoadStoreHours = function LoadStoreHours(storeHours, storeId) {
		if(storeId != null ){
			$('*[data-id="'+ storeId +'"]').each(function() { 
				if(storeHours[storeId] != null ){
					var nextHours = $(this).data('next-hours');
					
					console.log(storeHours[storeId].name + ' times updated');
					if(storeHours[storeId].openingHours == null && storeHours[storeId].closingHours == null ) {
						$(this).attr('data-opening-hours', '');
						$(this).attr('data-closing-hours', '');
					} else {
						$(this).attr('data-opening-hours', storeHours[storeId].openingHours);
						$(this).attr('data-closing-hours', storeHours[storeId].closingHours);
					}
					var oldHours = oldNextOpen_hours(nextHours);
					var nextOpenDay;
					if(nextHours.indexOf('tomorrow') >= 0) {
						nextOpenDay = 'tomorrow';
					} else if (nextHours.indexOf('day') >= 0) {
						nextOpenDay = nextHours.substring(
						nextHours.indexOf("on "), 
						nextHours.lastIndexOf("day") + 3)
					}
					var updatedNextHours = nextHours.replace(oldHours, time12hr(storeHours[storeId].nextOpeningHours).replace(':00', ''));
					updatedNextHours = updatedNextHours.replace(nextOpenDay, storeHours[storeId].nextOpen);
					$(this).attr('data-next-hours', updatedNextHours);
					
					ajaxStores = $.grep(ajaxStores, function(value) {
					  return value != storeId;
					});
				}
				$(this).removeClass('mon tue wed thu fri sat sun').addClass(shortDay(days().todayDay));
			});
		}
	}
					
	var StoreHoursCall = function StoreHoursCall(stores) {
		if(stores.length != 0) {
			if (storeHours  == null ) {
				 AjaxActive = null;
				$.getJSON(ajax_hours_params.resturl + 'galleria/v1/storeHours', function( data ) {
					storeHours = data;
					console.log(data);
					$.each( stores, function( key, val ) {
						LoadStoreHours(data, val);
					});
					
				}).done(function(){

					AjaxActive = 1;

				});
			} else {
				$.each( stores, function( key, val ) {
					LoadStoreHours(storeHours, val);
				});
			
			}
			
		}
				
	}
	
	var LoadDealHours = function LoadDealHours(dealHours, dealId) {
		if(dealId != null){
			$('*[data-id="'+ dealId +'"]').each(function() { 
				if(dealHours[dealId] != null  && $(this).hasClass('soon')){
					
					console.log(dealHours[dealId] + ' times updated');
					if(dealHours[dealId].openingHours == null && dealHours[dealId].closingHours == null ) {
						$(this).attr('data-opening-hours', '');
						$(this).attr('data-closing-hours', '');
					} else {
						$(this).attr('data-opening-hours', dealHours[dealId].openingHours);
						$(this).attr('data-closing-hours', dealHours[dealId].closingHours);
					}
					
					ajaxDeals = $.grep(ajaxDeals, function(value) {
					  return value != dealId;
					});
				}
				$(this).removeClass('mon tue wed thu fri sat sun').addClass(shortDay(days().todayDay));
			});
		}
	}
					
	var DealHoursCall = function DealHoursCall(deals) {
		if(deals.length != 0) {
			if (dealHours  == null ) {
				 AjaxActive = null;
				$.getJSON(ajax_hours_params.resturl + 'galleria/v1/dealHours', function( data ) {
					dealHours = data;
					console.log(data);
					$.each( deals, function( key, val ) {
						LoadDealHours(data, val);
					});
					
				}).done(function(){

					AjaxActive = 1;

				});
			} else {
				$.each( deals, function( key, val ) {
					LoadDealHours(dealHours, val);
				});
			
			}
			
		}
				
	}
	
	var openStatus = function openStatus($this){
		var storeStatus = '';
		
		if (!$this.hasClass(shortDay(days().todayDay)) ) {
			ajaxStores.push($this.data('id'));
		}
		
		if(timeNow() > '08:00') {
			$this.attr('data-next-hours', function(index, src) {
				if (src && ~src.indexOf(days().tomorrowDay)){
					if($this.is('.closed-today, .closed-temporarily, .opening-soon, .closed-down')) {
						$this.find('.store-details .hrs').text(function () {
							return $(this).text().replace('on ' + days().tomorrowDay, 'tomorrow'); 
						});
						
						$this.find('.open-next').text(function () {
							return $(this).text().replace('on ' + days().tomorrowDay, 'tomorrow'); 
						});
					}
					
					var nextOpen = src.replace('on ' + days().tomorrowDay, 'tomorrow');
					$this.attr('data-next-hours', nextOpen);
					
				} 
			
			});
			//console.log('tomorrow is ' + days().tomorrowDay);
		}
		
		$.each( weekday, function( i, day ) {
			if (day === days().todayDay ){
				$this.each(function() {
					if ($this.hasClass(shortDay(days().todayDay)) ) {
						if ($this.data('opening-hours') === '' && $this.data('closing-hours') === '' && storeStatus  != 'Closed Today' ){
								storeStatus = 'Closed Today';
						} else {
							if ( $this.data('opening-hours') > $this.data('closing-hours') ) {
								if(storeStatus  != 'Now Open' && timeNow() < $(this).data('closing-hours') ) {
									storeStatus = 'Now Open';
								}
						 
								if(storeStatus  != 'Opens Later Today' && timeNow() >= $this.data('closing-hours') && timeNow() < $this.data('opening-hours') ) {
									storeStatus = 'Opens Later Today';
								}
						
								 if(storeStatus  != 'Now Open' && timeNow() >= $this.data('opening-hours')) {
									storeStatus = 'Now Open';
								}

							} else {
							
								if(storeStatus  != 'Opens Later Today' && timeNow() < $this.data('opening-hours') ) {
										storeStatus = 'Opens Later Today';

								}
							
								if (storeStatus  != 'Now Open' && timeNow() >= $this.data('opening-hours') && timeNow() < $this.data('closing-hours')) {
									storeStatus = 'Now Open';
								} 
			
								if (storeStatus  != 'Closed Earlier today' && timeNow() >= $this.data('closing-hours') ) {
									storeStatus = 'Closed Earlier today';
		
								} 
			 
							}
						}
					}	
				});
			}
		});
		
		
		if(timeNow() === '00:00') {
			
			
/*			if(!$this.hasClass(shortDay(days().todayDay))) {
				$this.addClass(shortDay(days().todayDay));
			} 
			
			$this.removeClass(shortDay(days().yesterdayDay)); 
			*/
			if ( $this.data('opening-hours') < $this.data('closing-hours') ) {
				if (storeStatus != null) {
					storeStatus = null;
				}
				ajaxStores.push($this.data('id'));
			} else  {
				var timeToClose = ($this.data('closing-hours') - timeNow()) * 60000;
				
				setTimeout(function(){ 
						if (storeStatus != null) {
							storeStatus = null;
						}
						ajaxStores.push($this.data('id'));
						
					}, timeToClose);
					
				}
			}
		
		return storeStatus; 
		
	}
	
	var hoursTableDay = function() {
		var shortToday = shortDay(days().todayDay);
		$(".sh-" + shortToday).addClass("status-current");
		$(".sh-" + shortToday).siblings(".status-current").removeClass("status-current");
		
		if($(".sh-" + shortToday).siblings(".status-closed").length) {
			$(".sh-" + shortToday).siblings(".status-closed").removeClass("status-closed");
			$(".sh-" + shortToday).addClass("status-closed");
		}
		
		if($(".sh-" + shortToday).siblings(".status-opened").length) {
			$(".sh-" + shortToday).siblings(".status-opened").removeClass("status-opened");
			$(".sh-" + shortToday).addClass("status-opened");
		}
	}
	
	
	$("div[class*='store'], span[class*='store'], a[class*='store']").each(function() {	
		
		if ($(this).data('id') && !$(this).hasClass(shortDay(days().todayDay)) ) {
			ajaxStores.push($(this).data('id'));
		}
		
	});
	
	$("div[class*='deal'], span[class*='deal'], a[class*='deal']").each(function() {	
		
		if ($(this).data('id') && !$(this).hasClass(shortDay(days().todayDay)) ) {
			ajaxDeals.push($(this).data('id'));
		}
		
	});
	
	StoreHoursCall(ajaxStores);
	DealHoursCall(ajaxDeals);
	
	var mediaboxDeals = function mbDeals() { 
		$('.deals.media-box, .alerts.media-box').each(function() {
			var dealStatus = dealRunStatus($(this));
			//console.log('del' +  dealStatus);
			//$(this).find('.media-box-notify').remove();
			if (!$(this).hasClass('now') && dealStatus  == 'Open' ) {
				console.log(dealStatus + ': ' + $(this).data('id'));
				$(this).addClass('now');
				$('<div class="media-box-notify">Ongoing</div>').appendTo($(this).children( ".media-box-container" ));
			}

			if ($(this).hasClass('now') &&  dealStatus  == 'Closed' ) {
				console.log(dealStatus + ': ' + $(this).data('id'));
				$(this).removeClass('now');
				$(this).find('.media-box-notify').remove();
			}
		});
	}
	
	var openClosed = function() { 
		var shortToday = shortDay(days().todayDay);
		
		/*if(ajaxStores != null && AjaxActive != null ) {
				StoreHoursCall(ajaxStores);
			}*/
			
			
		if(ajaxStores != null ) {
				StoreHoursCall(ajaxStores);
			}
			
		if(ajaxDeals != null ) {
				DealHoursCall(ajaxDeals);
			}
		
		//console.log(shortToday);
		if(timeNow() === '00:00') {
			storeHours = false;
			hoursTableDay();
		}
		
		$('.status-current').each(function() {
			//console.log('today' + shortToday);
			if($(this).hasClass("sh-" + shortToday)) {
				//console.log('today');
				$(this).children().each(function(){
					if ( $(this).is('[data-sh-start]')) {
						if($(this).data("sh-start") > $(this).data("sh-end")) {
							if( timeNow() < $(this).data('sh-end') ) {
								console.log('should be open');
								$(this).parent().removeClass('status-closed').addClass('status-opened');
							}
				 
							if(timeNow() > $(this).data('sh-end') && timeNow() < $(this).data('sh-start') ) {
								console.log('should be closed');
								$(this).parent().removeClass('status-opened').addClass('status-closed');
							}
				
							 if(timeNow() > $(this).data('sh-start') ) {
								console.log('should be open');
								$(this).parent().removeClass('status-closed').addClass('status-opened');
							}
						} else {
						
							if ($(this).is('[data-sh-start]') && timeNow() > $(this).data("sh-start") && timeNow() < $(this).data("sh-end") && $(this).parent().hasClass("status-closed")) {
								console.log('should be open');
								$(this).parent().removeClass('status-closed').addClass('status-opened');
							} 
					
							if ($(this).is('[data-sh-end]') && timeNow() > $(this).data("sh-end") && $(this).parent().hasClass("status-opened")) {
								console.log('should be closed');
								$(this).parent().removeClass('status-opened').addClass('status-closed');
							}
						}
					}
				});
			} else {
				hoursTableDay();
			}
			
			var Start = $(this).find('td[data-sh-start="'+  timeNow() +'"]');
			var End = $(this).find('td[data-sh-end="'+  timeNow() +'"]');
			
			Start.parent().removeClass('status-closed').addClass('status-opened');
		
			End.parent().removeClass('status-opened').addClass('status-closed');
		});
	
		//store  archive open/closed
		$('.stores-list .media-box, .stores-tag.post-box, .store-card').not('.deals').each(function() { 
				
			var storeStatus = openStatus($(this));
			
			//$(this).addClass(storeStatus);
			if (storeStatus  == 'Now Open' && !$(this).hasClass('now-open') ) {
				$(this).removeClass('store-closed closed-today closed-earlier opens-later').addClass('store-open now-open');
				$(this).addClass('currently-open');
				$(this).find('.store-details .closed').removeClass('closed').addClass('open');
				$(this).find('.store-details .open').text('Open');
				$(this).find('.store-details .hrs').removeClass('closed-hrs').addClass('open-hrs');
				$(this).find('.store-details .hrs').text(time12hr($(this).data('opening-hours')) + ' - ' + time12hr($(this).data('closing-hours')));
			}
			
			if (storeStatus  == 'Closed Earlier today' && !$(this).hasClass('closed-earlier') ) { 
				$(this).removeClass('store-open closed-today now-open opens-later').addClass('store-closed closed-earlier');
				$(this).removeClass('currently-open');
				$(this).find('.store-details .open').removeClass('open').addClass('closed');
				$(this).find('.store-details .closed').text('Closed');
				$(this).find('.store-details .hrs').removeClass('open-hrs').addClass('closed-hrs');
				$(this).find('.store-details .hrs').text($(this).data('next-hours'));
				$(this).find('.store-details .closed').attr('title', 'Closed at ' +  time12hr($(this).data('closing-hours')).replace(':00', '')).tooltip('fixTitle');
			}
			
			if (storeStatus  == 'Opens Later Today' && !$(this).hasClass('opens-later') ) { 
				$(this).removeClass('store-open closed-today now-open closed-earlier').addClass('store-closed opens-later');
				$(this).removeClass('currently-open');
				$(this).find('.store-details .open').removeClass('open').addClass('closed');
				$(this).find('.store-details .closed').text('Closed');
				$(this).find('.store-details .closing-time').hide();
				$(this).find('.store-details .hrs').removeClass('open-hrs').addClass('closed-hrs');
				$(this).find('.store-details .hrs').text('Opens at ' +  time12hr($(this).data('opening-hours')).replace(':00', ''));
			}
			
			if (storeStatus  == 'Closed Today' && !$(this).is('.closed-today, .closed-temporarily, .opening-soon, .closed-down')) { 
				$(this).removeClass('store-open opens-later now-open closed-earlier').addClass('store-closed closed-today');
				$(this).removeClass('currently-open');
				$(this).find('.store-details .open').removeClass('open').addClass('closed');
				$(this).find('.store-details .closed').text('Closed');
				$(this).find('.store-details .hrs').removeClass('open-hrs').addClass('closed-hrs');
				$(this).find('.store-details .hrs').text($(this).data('next-hours'));
			}
			
		
		});	
		
		
		//single page
		$('.btn-timing').each(function() { 
				
			var storeStatus = openStatus($(this).parent());
			
			if (!$(this).hasClass('now-open') &&  storeStatus  == 'Now Open' ) {
				$(this).removeClass('closed closed-earlier opens-later closed-today').addClass('open now-open');
				$(this).html('<i class="fa fa-clock-o" aria-hidden="true"></i> Open Today');
				$(this).append("<span class='hrs' style='margin-left: 10px;'>" + time12hr($(this).parent().data('opening-hours')) + ' - ' + time12hr($(this).parent().data('closing-hours')) + "</span>");
				$('.open-next').hide();
			}
			
			if (!$(this).hasClass('closed-earlier') &&  storeStatus  == 'Closed Earlier today') {
				$(this).removeClass('opens-later closed-today open now-open').addClass('closed closed-earlier');
				$(this).html('<i class="fa fa-clock-o" aria-hidden="true"></i> Closed today at ');
				$(this).append("<span class='hrs' style='margin-left: 10px;'>" + time12hr($(this).parent().data('closing-hours')).replace(':00', '') + "</span>");
				
				if($('.open-next').length) {
					$('.open-next').html($(this).parent().data('next-hours'));
					$('.open-next').show();
				} else {
					$(this).parent().append('<br /><span class="open-next">' + $(this).parent().data('next-hours') + '</span>')
				}
				
				$('.open-next').css('visibility' , 'visible');
			}
			
			if (!$(this).hasClass('opens-later') &&  storeStatus  == 'Opens Later Today' ) {
				$(this).removeClass('closed-today closed-earlier open now-open').addClass('closed opens-later');
				$(this).html('<i class="fa fa-clock-o" aria-hidden="true"></i> Opens Later Today at ');
				$(this).append("<span class='hrs'>" + time12hr($(this).parent().data('opening-hours')) + "</span>");
				$('.open-next').hide();
			}
			
			if (!$(this).is('.closed-today, .closed-temporarily, .opening-soon, .closed-down') &&  storeStatus  == 'Closed Today' ) {
				$(this).removeClass('closed-earlier open now-open opens-later').addClass('closed closed-today');
				$(this).html('<i class="fa fa-clock-o" aria-hidden="true"></i> Closed today ');
			}
			
		});
		
		//top-bar hrs open/closed 
		$('.top-bar-hrs').each(function() {
			var storeStatus = openStatus($(this));
			var timing = '';
			
			if (!$(this).hasClass('open') && storeStatus  == 'Now Open' ) {
				$(this).find('.closed').text($(this).find('.closed').text().replace('CLOSED','OPEN'));
				$(this).find('.closed').removeClass('closed').addClass('open');
				$(this).removeClass('closed').addClass('open');
			}

			if (!$(this).hasClass('closed') &&  ['Closed Earlier today', 'Opens Later Today', 'Closed Today' ].indexOf(storeStatus) > -1 ) {
				$(this).find('.open').text($(this).find('.open').text().replace('OPEN','CLOSED'));
				$(this).find('.open').removeClass('open').addClass('closed');
				$(this).removeClass('open').addClass('closed');
			}
			
		if(!$(this).hasClass('mall-hrs')) {
			//tooltip and map hrs desc
			if (!$(this).hasClass('now-open') &&  storeStatus  == 'Now Open' ) {
				timing = 'Open today from ' + time12hr($(this).data('opening-hours')).replace(':00', '') + ' to ' + time12hr($(this).data('closing-hours')).replace(':00', '');
				
				$(this).removeClass('opens-later closed-earlier').addClass('now-open');
				$(this).not('.mall-hrs, .menu-hrs, .map-hrs').attr('title', timing).tooltip('fixTitle');	
				
				$(this).find('.day-hrs').attr('class','day-hrs now-open');	
				$(this).find('.day-hrs').text(timing);
			}
			
			if (!$(this).hasClass('closed-earlier') &&  storeStatus  == 'Closed Earlier today') {
				timing = 'Closed today at ' + time12hr($(this).data('closing-hours')).replace(':00', '');
				
				$(this).removeClass('opens-later now-open').addClass('closed-earlier');
				$(this).not('.mall-hrs, .menu-hrs, .map-hrs').attr('title', timing + '. ' + $(this).data('next-hours')).tooltip('fixTitle');	
				
				$(this).find('.day-hrs').attr('class','day-hrs closed-earlier');	
				$(this).find('.day-hrs').html(timing + '. <br />' + $(this).data('next-hours'));
			}
			
			if (!$(this).hasClass('opens-later') &&  storeStatus  == 'Opens Later Today' ) {
				timing = 'Opens later today from ' + time12hr($(this).data('opening-hours')).replace(':00', '') + ' to ' + time12hr($(this).data('closing-hours')).replace(':00', '');
				
				$(this).removeClass('now-open closed-earlier').addClass('opens-later');
				$(this).not('.mall-hrs, .menu-hrs, .map-hrs').attr('title', timing).tooltip('fixTitle');
				
				$(this).find('.day-hrs').attr('class','day-hrs opens-later');	
				$(this).find('.day-hrs').text(timing);	
			}
			
			if (!$(this).is('.closed-today, .closed-temporarily, .opening-soon, .closed-down') &&  storeStatus  == 'Closed Today' ) {
				timing = 'Closed today';
				
				$(this).removeClass('now-open closed-earlier opens-later').addClass('closed-today');
				$(this).not('.mall-hrs, .menu-hrs, .map-hrs').attr('title', timing).tooltip('fixTitle');
				
				$(this).find('.day-hrs').attr('class','day-hrs closed-today');	
				$(this).find('.day-hrs').text(timing);
			}
		}	
			
		});
		
		//menu hrs open/closed wording
		$('.menu-hrs .timing').each(function() {
		
			var storeStatus = openStatus($(this).closest('.menu-hrs'));
			
			if (!$(this).hasClass('now-open') && storeStatus  == 'Now Open' ) {
				$(this).attr('class','timing now-open');
				$(this).text(time12hr($(this).closest('.menu-hrs').data('opening-hours')) + ' - ' + time12hr($(this).closest('.menu-hrs').data('closing-hours')));
			}

			if (!$(this).hasClass('opens-later') &&  storeStatus  == 'Opens Later Today' ) { 
				$(this).attr('class','timing opens-later');
				$(this).text('Opens at ' +  time12hr($(this).closest('.menu-hrs').data('opening-hours')));
			}
			
			if (!$(this).hasClass('closed-earlier') &&  storeStatus  == 'Closed Earlier today'  ) {
				$(this).attr('class','timing closed-earlier');
				$(this).text($(this).closest('.menu-hrs').data('next-hours'));
				$(this).attr('title', 'Closed at ' +  time12hr($(this).closest('.menu-hrs').data('closing-hours')).replace(':00', '')).tooltip('fixTitle');
				
			}
			
			if (!$(this).is('.closed-today, .closed-temporarily, .opening-soon, .closed-down') &&  storeStatus  == 'Closed Today') {
				$(this).attr('class','timing closed-today');
				$(this).text('Closed today');
			}
			
		});
		
		// mall hours section
		$('.mall-hrs').each(function() {
		
			var storeStatus = openStatus($(this));
			
			if (storeStatus  == 'Now Open') {
				if (!$(this).hasClass('now-open') ) {
					$(this).removeClass('opens-later closed-earlier closed-today').addClass('now-open');
				}
				
				if($(this).text().indexOf('Come in, we are')  == -1) {
					$(this).find('h4').text('Come in, we are');
					$(this).find('p').text('From ' + time12hr($(this).data('opening-hours')) + ' to ' + time12hr($(this).data('closing-hours')));
				}
			}

			if ( storeStatus  == 'Closed Earlier today' ) {
				if (!$(this).hasClass('closed-earlier')) {
					$(this).removeClass('opens-later now-open closed-today').addClass('closed-earlier');
				}
				
				if($(this).text().indexOf('Sorry, we are') == -1 || $(this).text().indexOf('We closed at') == -1 ) {
					$(this).find('h4').text('Sorry, we are');
					$(this).find('p').text('We closed at ' +  time12hr($(this).data('closing-hours')) + '. ' + $(this).data('next-hours'));
				}
				
			}
			
			if ( storeStatus  == 'Opens Later Today' ) {
				if (!$(this).hasClass('opens-later')) {
					$(this).removeClass('closed-earlier now-open closed-today').addClass('opens-later');
				}
				
				if($(this).text().indexOf('Sorry, we are')  == -1 || $(this).text().indexOf('We open later today at')  == -1 ) {
					$(this).find('h4').text('Sorry, we are');
					$(this).find('p').text('We open later today at ' +  time12hr($(this).data('opening-hours')));
				}
			}
			
			if ( storeStatus  == 'Closed Today' ) {
				if (!$(this).is('.closed-today, .closed-temporarily, .opening-soon, .closed-down')) {
					$(this).removeClass('closed-earlier now-open opens-later').addClass('closed-today');
				}
				
				if($(this).text().indexOf('Sorry, we are')  == -1 ) {
					$(this).find('h4').text('Sorry, we are');
					$(this).find('p').text('Today');
				}
			}
		});
		
		$('.map-hrs, .storehrs_desc').each(function() {
			if($(this).css("visibility") === "hidden") {
				$(this).css('visibility' , 'visible');
			}
		});
		
		//console.log(timeNow());
		
		/*$('.media-boxes-container').on( 'layoutComplete',
	  		function( event, laidOutItems ) {
				
		});*/
		
		if(document.readyState == 'complete') {
			$('.deals.media-box, .alerts.media-box').each(function() {
				var dealStatus = dealRunStatus($(this));
				//console.log('del' +  dealStatus);
				//$(this).find('.media-box-notify').remove();
				if (!$(this).hasClass('now') && dealStatus  == 'Open' ) {
					console.log(dealStatus + ': ' + $(this).data('id'));
					$(this).addClass('now');
					$('<div class="media-box-notify">Ongoing</div>').appendTo($(this).children( ".media-box-container" ));
				}

				if ($(this).hasClass('now') &&  dealStatus  == 'Closed' ) {
					console.log(dealStatus + ': ' + $(this).data('id'));
					$(this).removeClass('now');
					$(this).find('.media-box-notify').remove();
				}
			});
		}
		
		$('.deals.post-box, .alerts.post-box, .single-deal').each(function() {
			var dealStatus = dealRunStatus($(this));
			//console.log('del' +  dealStatus);
			if($(this).hasClass('now')) {
				$(this).find('.curr-btn').show();
			}
			if (!$(this).hasClass('now') && dealStatus  == 'Open' ) {
				console.log(dealStatus + ': ' + $(this).data('id'));
				$(this).addClass('now');
				//$('<span class="small-btn white m-0 mb-3 curr-btn"> ONGOING </span>').appendTo($(this).children( ".cms-custom-headding-title" ));
				$(this).find( "h5.cms-custom-headding-title" ).append(' <span class="small-btn white m-0 mb-3 curr-btn">ONGOING</span>');
			}

			if ($(this).hasClass('now') &&  dealStatus  == 'Closed' ) {
				console.log(dealStatus + ': ' + $(this).data('id'));
				$(this).removeClass('now');
				$(this).find('.curr-btn').remove();
			}
		});
	
	}
		
	openClosed();

	// Opening states only change on minute boundaries. The previous one-second
	// loop repeated all store/deal calculations unnecessarily.
	setInterval(openClosed, 60000);
	
	$('.btn-timing').css('visibility' , 'visible');
	$('.open-next').css('visibility' , 'visible');
	
	$('.menu-hrs').show();
	$('.mall-hrs').css('visibility' , 'visible');
	$('.store-card').css('visibility' , 'visible');

	

});
