(function () {
  function openModal(id) {
    var modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
  }

  function closeModal(modal) {
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
  }

  document.addEventListener('click', function (event) {
    var openButton = event.target.closest('[data-gh-modal-open]');
    if (openButton) {
      event.preventDefault();
      openModal(openButton.getAttribute('data-gh-modal-open'));
      return;
    }

    var closeButton = event.target.closest('[data-gh-modal-close]');
    if (closeButton) {
      event.preventDefault();
      closeModal(closeButton.closest('.gh-modal'));
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('.gh-modal.is-open').forEach(closeModal);
  });
})();
