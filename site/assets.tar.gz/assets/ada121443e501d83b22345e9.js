(function () {
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function animatePanel(panel) {
    if (!panel || reduceMotion || !panel.animate) return;
    panel.animate(
      [
        { opacity: 0, transform: 'translateY(6px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ],
      { duration: 180, easing: 'cubic-bezier(.2,.7,.2,1)' }
    );
  }

  function initFinder(root) {
    var tabs = Array.prototype.slice.call(root.querySelectorAll('.gsf__tab'));
    var panels = Array.prototype.slice.call(root.querySelectorAll('.gsf__panel'));
    if (!tabs.length || !panels.length) return;

    function activate(tab, focus) {
      var key = tab.getAttribute('data-gsf-tab');
      tabs.forEach(function (t) {
        var active = t === tab;
        t.classList.toggle('is-active', active);
        t.setAttribute('aria-selected', active ? 'true' : 'false');
        t.setAttribute('tabindex', active ? '0' : '-1');
      });
      panels.forEach(function (p) {
        var active = p.getAttribute('data-gsf-panel') === key;
        if (active) {
          p.hidden = false;
          p.classList.add('is-active');
          animatePanel(p);
        } else {
          p.classList.remove('is-active');
          p.hidden = true;
        }
      });
      if (focus) tab.focus();
    }

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () { activate(tab, false); });
      tab.addEventListener('keydown', function (e) {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' && e.key !== 'Home' && e.key !== 'End') return;
        e.preventDefault();
        var next = index;
        if (e.key === 'ArrowRight') next = (index + 1) % tabs.length;
        if (e.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
        if (e.key === 'Home') next = 0;
        if (e.key === 'End') next = tabs.length - 1;
        activate(tabs[next], true);
      });
    });

    function activateFromHash() {
      var hash = window.location.hash.replace(/^#/, '');
      if (!hash) return;
      var key = hash.indexOf('gsf-store-') === 0 || hash === 'gsf-stores' ? 'stores' : hash.replace(/^gsf-/, '');
      var target = tabs.find(function (t) { return t.getAttribute('data-gsf-tab') === key; });
      if (target) activate(target, false);
    }
    activateFromHash();
    window.addEventListener('hashchange', activateFromHash);
  }

  function animateBrowseBody(body, startHeight) {
    if (!body || reduceMotion || !body.animate) return;
    var endHeight = body.scrollHeight;
    body.style.overflow = 'hidden';
    var animation = body.animate(
      [{ height: startHeight + 'px' }, { height: endHeight + 'px' }],
      { duration: 220, easing: 'cubic-bezier(.2,.7,.2,1)' }
    );
    animation.onfinish = function () { body.style.overflow = ''; };
  }

  function initLoadMore(root) {
    var endpoint = root.getAttribute('data-gsf-terms-endpoint');
    if (!endpoint) return;

    root.querySelectorAll('[data-gsf-load-more]').forEach(function (button) {
      button.addEventListener('click', function () {
        if (button.disabled) return;
        var body = button.closest('.gsf__browse-body');
        if (!body) return;
        var chips = body.querySelector('[data-gsf-chip-list]');
        if (!chips) return;

        var taxonomy = button.getAttribute('data-taxonomy');
        var offset = parseInt(button.getAttribute('data-offset') || '0', 10);
        var limit = parseInt(button.getAttribute('data-limit') || '18', 10);
        var label = button.querySelector('.gsf__show-more-label');
        var startHeight = body.getBoundingClientRect().height;

        button.disabled = true;
        button.classList.add('is-loading');
        if (label) label.textContent = 'Loading…';

        var url = new URL(endpoint, window.location.origin);
        url.searchParams.set('taxonomy', taxonomy);
        url.searchParams.set('offset', offset);
        url.searchParams.set('limit', limit);

        fetch(url.toString(), { credentials: 'same-origin' })
          .then(function (response) {
            if (!response.ok) throw new Error('Could not load terms');
            return response.json();
          })
          .then(function (data) {
            var items = data && Array.isArray(data.items) ? data.items : [];
            items.forEach(function (item) {
              var link = document.createElement('a');
              link.className = 'gsf__chip gsf__chip--new';
              link.href = item.url;
              link.textContent = item.name;
              chips.appendChild(link);
            });

            animateBrowseBody(body, startHeight);

            requestAnimationFrame(function () {
              chips.querySelectorAll('.gsf__chip--new').forEach(function (chip) {
                chip.classList.add('is-visible');
                chip.classList.remove('gsf__chip--new');
              });
            });

            button.setAttribute('data-offset', String(data.next_offset || (offset + items.length)));
            if (data.has_more) {
              button.disabled = false;
              button.classList.remove('is-loading');
              if (label) label.textContent = 'Show more';
            } else {
              button.remove();
            }
          })
          .catch(function () {
            button.disabled = false;
            button.classList.remove('is-loading');
            if (label) label.textContent = 'Try again';
          });
      });
    });
  }

  function initCompactAZ(root) {
    var endpoint = root.getAttribute('data-gsf-letter-endpoint');
    var resultBox = root.querySelector('[data-gsf-letter-results]');
    var resultList = root.querySelector('[data-gsf-results-list]');
    var title = root.querySelector('[data-gsf-results-title]');
    var status = root.querySelector('[data-gsf-results-status]');
    var more = root.querySelector('[data-gsf-letter-more]');
    var moreLabel = root.querySelector('[data-gsf-more-label]');
    var buttons = Array.prototype.slice.call(root.querySelectorAll('[data-gsf-letter]'));
    var typeButtons = Array.prototype.slice.call(root.querySelectorAll('[data-gsf-result-type]'));
    if (!endpoint || !resultBox || !resultList || !buttons.length) return;

    var state = { letter: '', postType: '', offset: 0, loading: false, limit: 20 };

    function setActive(letter) {
      buttons.forEach(function (button) {
        var active = button.getAttribute('data-gsf-letter') === letter;
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
    }

    function setActiveType(postType) {
      typeButtons.forEach(function (button) {
        var active = button.getAttribute('data-gsf-result-type') === postType;
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
    }

    function itemNode(item) {
      var li = document.createElement('li');
      var link = document.createElement('a');
      var label = document.createElement('span');
      var type = document.createElement('span');
      link.href = item.url;
      label.className = 'gsf__compact-result-title';
      label.textContent = item.title;
      type.className = 'gsf__compact-result-type';
      type.textContent = item.type;
      link.appendChild(label);
      link.appendChild(type);
      li.appendChild(link);
      return li;
    }

    function load(letter, append) {
      if (state.loading) return;
      state.loading = true;
      state.letter = letter;
      if (!append) {
        state.offset = 0;
        resultList.innerHTML = '';
        resultBox.hidden = false;
        if (title) title.textContent = 'Results beginning with ' + letter;
        if (status) status.textContent = 'Loading…';
        if (more) more.hidden = true;
        setActive(letter);
      } else if (moreLabel) {
        more.disabled = true;
        moreLabel.textContent = 'Loading…';
      }

      var url = new URL(endpoint, window.location.origin);
      url.searchParams.set('letter', letter);
      if (state.postType) url.searchParams.set('post_type', state.postType);
      url.searchParams.set('offset', String(state.offset));
      url.searchParams.set('limit', String(state.limit));

      fetch(url.toString(), { credentials: 'same-origin' })
        .then(function (response) {
          if (!response.ok) throw new Error('Could not load results');
          return response.json();
        })
        .then(function (data) {
          var items = data && Array.isArray(data.items) ? data.items : [];
          if (!append && !items.length) {
            if (status) status.textContent = 'No matching content found.';
          } else {
            if (status) status.textContent = '';
            items.forEach(function (item) { resultList.appendChild(itemNode(item)); });
          }

          state.offset = data && typeof data.next_offset !== 'undefined' ? parseInt(data.next_offset, 10) : state.offset + items.length;
          if (more) {
            more.hidden = !(data && data.has_more);
            more.disabled = false;
          }
          if (moreLabel) moreLabel.textContent = 'Show more';
          state.loading = false;
          animatePanel(resultBox);
        })
        .catch(function () {
          if (status) status.textContent = 'Could not load results. Please try again.';
          if (more) more.disabled = false;
          if (moreLabel) moreLabel.textContent = 'Try again';
          state.loading = false;
        });
    }

    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        load(button.getAttribute('data-gsf-letter'), false);
      });
    });

    typeButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        if (!state.letter || state.loading) return;
        state.postType = button.getAttribute('data-gsf-result-type') || '';
        setActiveType(state.postType);
        load(state.letter, false);
      });
    });

    if (more) {
      more.addEventListener('click', function () {
        if (state.letter) load(state.letter, true);
      });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.gsf--full').forEach(function (root) {
      initFinder(root);
      initLoadMore(root);
    });
    document.querySelectorAll('.gsf--compact').forEach(function (root) {
      initCompactAZ(root);
    });
  });
})();
