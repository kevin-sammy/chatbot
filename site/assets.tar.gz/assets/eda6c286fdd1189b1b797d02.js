$(document).ready(function() {
  $(".main-media").each(function() {
    var slideWrapper = $(this);

    // Check if it contains slides
    if (slideWrapper.find('.slide').length === 0) return;

    var iframes = slideWrapper.find('.embed-player'),
        hasPostBoxParent = slideWrapper.closest('.post-box').length > 0, // ✅ Check for ANY ancestor with .post-box
        slideNav = slideWrapper.siblings('.slider-nav'),
        numItems = slideNav.find('.slide').length,
        center_Mode = numItems > 2,
        lazyLoadOption = hasPostBoxParent ? 'progressive' : 'none',
        variableWidthOption = hasPostBoxParent, // ✅ Enable variable width if .post-box exists
        adaptiveHeightOption = !hasPostBoxParent, // ✅ Adaptive height only if .post-box is NOT found
        fadeOption = slideWrapper.closest('.blog-content').length > 0,
        SldeNum = fadeOption ? 10 : 5,
        navForOption = slideNav.length ? slideNav : null,
        isInsideBlogContent = slideNav.closest('.blog-content').length > 0; // ✅ Check if inside .blog-content

    // Function to post messages to video players
    function postMessageToPlayer(player, command) {
      if (!player || !command) return;
      player.contentWindow.postMessage(JSON.stringify(command), "*");
    }

    // Function to play or pause video
    function playPauseVideo(slick, control) {
      var currentSlide = slick.find(".slick-current"),
          slideType = currentSlide.attr("class").split(" ")[1],
          player = currentSlide.find("iframe").get(0),
          startTime = currentSlide.data("video-start");

      if (slideType === "vimeo") {
        if (control === "play") {
          if (startTime && !currentSlide.hasClass('started')) {
            currentSlide.addClass('started');
            postMessageToPlayer(player, { "method": "setCurrentTime", "value": startTime });
          }
          postMessageToPlayer(player, { "method": "play", "value": 1 });
        } else {
          postMessageToPlayer(player, { "method": "pause", "value": 1 });
        }
      } else if (slideType === "youtube") {
        postMessageToPlayer(player, { "event": "command", "func": control === "play" ? "playVideo" : "pauseVideo" });
      } else if (slideType === "video") {
        var video = currentSlide.children("video").get(0);
        if (video) {
          control === "play" ? video.play() : video.pause();
        }
      }
    }

    // Initialize Slick for main-media
    slideWrapper.on("init", function(event, slick) {
      setTimeout(function() {
        playPauseVideo(slideWrapper, "play");
      }, 1000);
    });

    slideWrapper.on("beforeChange", function(event, slick) {
      playPauseVideo(slideWrapper, "pause");
    });

    slideWrapper.on("afterChange", function(event, slick) {
      playPauseVideo(slideWrapper, "play");
    });

    slideWrapper.slick({
      fade: fadeOption,
      slidesToShow: 1,
      slidesToScroll: 1,
//      centerMode: hasPostBoxParent, /// ✅ Center mode only if .post-box exists/
      variableWidth: variableWidthOption, // ✅ Adaptive width if .post-box exists
      adaptiveHeight: adaptiveHeightOption, // ✅ Adaptive height otherwise
      centerPadding: '10px',
      infinite: false,
      autoplaySpeed: 4000,
      lazyLoad: lazyLoadOption,
      speed: 600,
      arrows: true,
      asNavFor: navForOption,
      cssEase: "cubic-bezier(0.87, 0.03, 0.41, 0.9)",
      prevArrow: '<span class="icon-arrow-left"></span>',
      nextArrow: '<span class="icon-arrow-right"></span>'
    });

    // Initialize Slick for slider-nav (if exists)
    if (slideNav.length) {
      slideNav.slick({
        slidesToShow: isInsideBlogContent ? 10 : 7, // 10 if in blog-content, else 7 (default desktop)
        slidesToScroll: 1,
        speed: 600,
        asNavFor: slideWrapper,
        infinite: true,
        dots: true,
        arrows: false,
        //centerMode: center_Mode,
        centerPadding: '20px',
        focusOnSelect: true,
        responsive: [
          {
            breakpoint: 1024, // Tablets
            settings: {
              slidesToShow: isInsideBlogContent ? 7 : 5 // 7 if in blog-content, else 5
            }
          },
          {
            breakpoint: 768, // Mobile
            settings: {
              slidesToShow: isInsideBlogContent ? 5 : 3 // 5 if in blog-content, else 3
            }
          }
        ]
      });
    }

    // Pause videos on slide change
    slideWrapper.on('beforeChange', function(event, slick, currentSlide, nextSlide) {
      slideWrapper.find("video").each(function() {
        this.pause();
      });
    });

  });
});
